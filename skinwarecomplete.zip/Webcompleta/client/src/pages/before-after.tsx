import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Chatbot } from "@/components/chatbot"
import { AnimatedSection } from "@/components/animated-section"

const results = [
  { name: "Laura M.", before: "Acné severo", after: "Piel clara y radiante", weeks: 12, improvement: "95%" },
  { name: "Sofia R.", before: "Sequedad extrema", after: "Piel hidratada y suave", weeks: 8, improvement: "88%" },
  { name: "Ana G.", before: "Manchas hiperpigmentación", after: "Tono uniforme", weeks: 16, improvement: "92%" },
  { name: "Marta L.", before: "Arrugas profundas", after: "Piel firme y elástica", weeks: 20, improvement: "85%" },
]

export default function BeforeAfterPage() {
  return (
    <>
      <Navbar />
      <main className="pt-20 min-h-screen">
        <section className="py-24 bg-gradient-to-b from-secondary/20 to-background">
          <div className="container mx-auto px-6">
            <AnimatedSection className="text-center max-w-3xl mx-auto">
              <span className="inline-block px-4 py-2 rounded-full bg-secondary text-secondary-foreground text-xs font-medium tracking-wider uppercase mb-6">
                Resultados
              </span>
              <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-foreground mb-6 text-balance">
                Resultados que hablan por sí solos
              </h1>
              <p className="text-lg text-muted-foreground text-pretty">
                Transformaciones reales de nuestros clientes con Skinware. Descubre cómo hemos mejorado la piel de cientos de personas.
              </p>
            </AnimatedSection>
          </div>
        </section>

        {/* Results Grid */}
        <section className="py-20">
          <div className="container mx-auto px-6">
            <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
              {results.map((result, i) => (
                <AnimatedSection key={i} delay={i * 100}>
                  <div className="bg-card rounded-2xl border border-border p-8 h-full hover:shadow-lg transition-all flex flex-col">
                    <div className="mb-6">
                      <h3 className="font-serif text-2xl text-foreground mb-2">{result.name}</h3>
                      <p className="text-sm text-primary font-medium">{result.weeks} semanas de transformación</p>
                    </div>
                    <div className="space-y-4 mb-6 flex-grow">
                      <div className="bg-muted/50 p-4 rounded-lg">
                        <p className="text-xs text-muted-foreground mb-1 uppercase font-medium">Antes</p>
                        <p className="text-foreground font-medium">{result.before}</p>
                      </div>
                      <div className="flex justify-center">
                        <div className="bg-primary/20 text-primary px-4 py-2 rounded-full text-sm font-medium">✓ Transformación</div>
                      </div>
                      <div className="bg-primary/10 p-4 rounded-lg">
                        <p className="text-xs text-primary mb-1 uppercase font-medium">Después</p>
                        <p className="text-foreground font-medium">{result.after}</p>
                      </div>
                    </div>
                    <div className="bg-gradient-to-r from-primary/20 to-primary/10 rounded-lg p-4 text-center border border-primary/20">
                      <p className="text-3xl font-serif text-primary font-bold">{result.improvement}</p>
                      <p className="text-xs text-muted-foreground mt-1">Mejora visible</p>
                    </div>
                  </div>
                </AnimatedSection>
              ))}
            </div>
          </div>
        </section>

        {/* Impact Stats */}
        <section className="py-20 bg-muted">
          <div className="container mx-auto px-6">
            <div className="grid grid-cols-3 gap-6 max-w-2xl mx-auto">
              <AnimatedSection className="text-center bg-card rounded-2xl p-6 border border-border">
                <p className="text-4xl md:text-5xl font-serif font-bold text-primary">500+</p>
                <p className="text-sm text-muted-foreground mt-3">Transformaciones</p>
              </AnimatedSection>
              <AnimatedSection delay={100} className="text-center bg-card rounded-2xl p-6 border border-border">
                <p className="text-4xl md:text-5xl font-serif font-bold text-primary">4.8★</p>
                <p className="text-sm text-muted-foreground mt-3">Calificación</p>
              </AnimatedSection>
              <AnimatedSection delay={200} className="text-center bg-card rounded-2xl p-6 border border-border">
                <p className="text-4xl md:text-5xl font-serif font-bold text-primary">98%</p>
                <p className="text-sm text-muted-foreground mt-3">Satisfacción</p>
              </AnimatedSection>
            </div>
          </div>
        </section>
      </main>
      <Footer />
      <Chatbot />
    </>
  )
}
