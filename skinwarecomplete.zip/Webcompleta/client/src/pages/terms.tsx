import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { AnimatedSection } from "@/components/animated-section"

export default function TerminosPage() {
  return (
    <>
      <Navbar />
      <main className="pt-20 min-h-screen">
        <div className="container mx-auto px-6 py-16">
          <AnimatedSection direction="up" className="max-w-3xl mx-auto">
            <h1 className="font-serif text-4xl md:text-5xl text-foreground mb-8">Términos de Uso</h1>

            <div className="prose prose-lg max-w-none text-muted-foreground space-y-6">
              <p className="text-sm text-muted-foreground">Última actualización: 15 de enero de 2025</p>

              <section>
                <h2 className="font-serif text-2xl text-foreground mt-8 mb-4">1. Aceptación de los términos</h2>
                <p>
                  Al acceder y utilizar el sitio web de Skinware (skinware.es), aceptas estar vinculado por estos
                  Términos de Uso. Si no estás de acuerdo con alguno de estos términos, te rogamos que no utilices
                  nuestro sitio.
                </p>
              </section>

              <section>
                <h2 className="font-serif text-2xl text-foreground mt-8 mb-4">2. Uso del servicio</h2>
                <p>Skinware ofrece una plataforma de cosmética personalizada que incluye:</p>
                <ul className="list-disc pl-6 space-y-2 mt-4">
                  <li>Diagnóstico de piel impulsado por inteligencia artificial</li>
                  <li>Recomendaciones de productos personalizadas</li>
                  <li>Venta de productos de skincare</li>
                  <li>Contenido educativo sobre cuidado de la piel</li>
                </ul>
                <p className="mt-4">
                  Te comprometes a utilizar nuestros servicios de manera responsable y de acuerdo con la legislación
                  vigente.
                </p>
              </section>

              <section>
                <h2 className="font-serif text-2xl text-foreground mt-8 mb-4">3. Diagnóstico IA</h2>
                <p>
                  Nuestro sistema de diagnóstico de piel utiliza inteligencia artificial para proporcionar
                  recomendaciones personalizadas. Es importante entender que:
                </p>
                <ul className="list-disc pl-6 space-y-2 mt-4">
                  <li>Las recomendaciones son orientativas y no sustituyen el consejo médico profesional</li>
                  <li>Los resultados se basan en la información que proporcionas</li>
                  <li>Ante cualquier condición dermatológica, consulta con un especialista</li>
                </ul>
              </section>

              <section>
                <h2 className="font-serif text-2xl text-foreground mt-8 mb-4">4. Propiedad intelectual</h2>
                <p>
                  Todo el contenido de este sitio web, incluyendo textos, imágenes, logotipos, diseños y software, es
                  propiedad de Skinware o de sus licenciantes y está protegido por las leyes de propiedad intelectual.
                </p>
              </section>

              <section>
                <h2 className="font-serif text-2xl text-foreground mt-8 mb-4">5. Compras y pagos</h2>
                <p>Al realizar una compra en Skinware, aceptas que:</p>
                <ul className="list-disc pl-6 space-y-2 mt-4">
                  <li>Los precios mostrados son en euros e incluyen IVA</li>
                  <li>Los gastos de envío se calculan según la ubicación</li>
                  <li>Tienes derecho a devolución en 14 días según la legislación vigente</li>
                  <li>Los métodos de pago aceptados se muestran en el proceso de checkout</li>
                </ul>
              </section>

              <section>
                <h2 className="font-serif text-2xl text-foreground mt-8 mb-4">6. Limitación de responsabilidad</h2>
                <p>
                  Skinware no será responsable de daños indirectos, incidentales o consecuentes derivados del uso de
                  nuestros productos o servicios, salvo en los casos previstos por la ley.
                </p>
              </section>

              <section>
                <h2 className="font-serif text-2xl text-foreground mt-8 mb-4">7. Modificaciones</h2>
                <p>
                  Nos reservamos el derecho de modificar estos términos en cualquier momento. Las modificaciones
                  entrarán en vigor desde su publicación en el sitio web.
                </p>
              </section>

              <section>
                <h2 className="font-serif text-2xl text-foreground mt-8 mb-4">8. Contacto</h2>
                <p>Para cualquier consulta sobre estos términos, contacta con nosotros en:</p>
                <p className="mt-4">
                  <strong className="text-foreground">Skinware</strong>
                  <br />
                  Email: legal@skinware.es
                  <br />
                  Dirección: Tarragona, España
                </p>
              </section>
            </div>
          </AnimatedSection>
        </div>
      </main>
      <Footer />
    </>
  )
}
