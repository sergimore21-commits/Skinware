import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { AnimatedSection } from "@/components/animated-section"
import { Link } from "wouter"

export default function CookiesPage() {
  return (
    <>
      <Navbar />
      <main className="pt-20 min-h-screen">
        <div className="container mx-auto px-6 py-16">
          <AnimatedSection direction="up" className="max-w-3xl mx-auto">
            <h1 className="font-serif text-4xl md:text-5xl text-foreground mb-8">Política de Cookies</h1>

            <div className="prose prose-lg max-w-none text-muted-foreground space-y-6">
              <p className="text-sm text-muted-foreground">Última actualización: 15 de enero de 2025</p>

              <section>
                <h2 className="font-serif text-2xl text-foreground mt-8 mb-4">¿Qué son las cookies?</h2>
                <p>
                  Las cookies son pequeños archivos de texto que se almacenan en tu dispositivo cuando visitas un sitio
                  web. Se utilizan para recordar tus preferencias, mejorar tu experiencia de navegación y
                  proporcionarnos información sobre cómo utilizas nuestro sitio.
                </p>
              </section>

              <section>
                <h2 className="font-serif text-2xl text-foreground mt-8 mb-4">Tipos de cookies que utilizamos</h2>

                <h3 className="font-medium text-lg text-foreground mt-6 mb-3">Cookies esenciales</h3>
                <p>
                  Estas cookies son necesarias para el funcionamiento básico del sitio web. Sin ellas, no podríamos
                  ofrecer servicios como el carrito de compras o el inicio de sesión.
                </p>

                <h3 className="font-medium text-lg text-foreground mt-6 mb-3">Cookies de rendimiento</h3>
                <p>
                  Nos ayudan a entender cómo los visitantes interactúan con nuestro sitio web, recopilando información
                  de forma anónima. Utilizamos Google Analytics para este propósito.
                </p>

                <h3 className="font-medium text-lg text-foreground mt-6 mb-3">Cookies de funcionalidad</h3>
                <p>Permiten recordar tus preferencias y personalizar tu experiencia, como el idioma o la región.</p>

                <h3 className="font-medium text-lg text-foreground mt-6 mb-3">Cookies de marketing</h3>
                <p>
                  Se utilizan para mostrarte anuncios relevantes basados en tus intereses. Solo las activamos con tu
                  consentimiento explícito.
                </p>
              </section>

              <section>
                <h2 className="font-serif text-2xl text-foreground mt-8 mb-4">Cookies de terceros</h2>
                <p>Utilizamos servicios de terceros que pueden establecer cookies:</p>
                <ul className="list-disc pl-6 space-y-2 mt-4">
                  <li>
                    <strong className="text-foreground">Google Analytics:</strong> Análisis de tráfico web
                  </li>
                  <li>
                    <strong className="text-foreground">Vercel Analytics:</strong> Rendimiento del sitio
                  </li>
                  <li>
                    <strong className="text-foreground">Stripe:</strong> Procesamiento de pagos (cuando aplique)
                  </li>
                </ul>
              </section>

              <section>
                <h2 className="font-serif text-2xl text-foreground mt-8 mb-4">Gestión de cookies</h2>
                <p>Puedes gestionar tus preferencias de cookies en cualquier momento:</p>
                <ul className="list-disc pl-6 space-y-2 mt-4">
                  <li>A través del banner de cookies que aparece al visitar el sitio</li>
                  <li>Modificando la configuración de tu navegador</li>
                  <li>Utilizando herramientas de opt-out de terceros</li>
                </ul>
                <p className="mt-4">
                  Ten en cuenta que desactivar ciertas cookies puede afectar la funcionalidad del sitio web.
                </p>
              </section>

              <section>
                <h2 className="font-serif text-2xl text-foreground mt-8 mb-4">Más información</h2>
                <p>
                  Si tienes preguntas sobre nuestra política de cookies, contacta con nosotros en
                  privacidad@skinware.es.
                </p>
              </section>
            </div>
          </AnimatedSection>
        </div>
      </main>
      <Footer />
    </>
  )
}
