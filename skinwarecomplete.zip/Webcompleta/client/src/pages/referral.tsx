import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { ReferralProgram } from "@/components/referral-program"

export default function ReferralPage() {
  return (
    <>
      <Navbar />
      <main className="min-h-screen">
        <ReferralProgram />
      </main>
      <Footer />
    </>
  )
}
