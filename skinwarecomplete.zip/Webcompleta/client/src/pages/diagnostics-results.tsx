import { useState, useEffect } from "react"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Link } from "wouter"
import { CheckIcon, ArrowRightIcon } from "@/components/icons"

export default function DiagnosticsResultsPage() {
  const [diagnosis, setDiagnosis] = useState<any>(null)

  useEffect(() => {
    const saved = localStorage.getItem("skinware-diagnosis")
    if (saved) {
      setDiagnosis(JSON.parse(saved))
    }
  }, [])

  if (!diagnosis) {
    return (
      <>
        <Navbar />
        <main className="pt-20 min-h-screen flex items-center justify-center">
          <div className="text-center">
            <p className="text-muted-foreground mb-4">No hay diagnóstico guardado</p>
            <Button asChild className="rounded-full">
              <Link href="/diagnostico">Hacer diagnóstico</Link>
            </Button>
          </div>
        </main>
        <Footer />
      </>
    )
  }

  const skinTypeLabel: Record<string, string> = {
    grasa: "Grasa",
    seca: "Seca",
    mixta: "Mixta",
    normal: "Normal",
    sensible: "Sensible",
  }

  return (
    <>
      <Navbar />
      <main className="pt-20 min-h-screen pb-20">
        <div className="container mx-auto px-6 max-w-3xl">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
              <CheckIcon className="w-8 h-8 text-primary" />
            </div>
            <h1 className="font-serif text-4xl md:text-5xl text-foreground mb-4">Tu diagnóstico de piel</h1>
            <p className="text-muted-foreground text-lg">
              Basado en tu análisis IA, aquí están tus recomendaciones personalizadas
            </p>
          </div>

          {/* Results Summary */}
          <div className="grid md:grid-cols-2 gap-6 mb-12">
            <div className="bg-card border border-border rounded-2xl p-6">
              <p className="text-xs text-muted-foreground uppercase font-semibold mb-2">Tipo de piel</p>
              <p className="font-serif text-2xl text-primary font-bold capitalize">
                {skinTypeLabel[diagnosis.skinType] || diagnosis.skinType}
              </p>
            </div>

            <div className="bg-card border border-border rounded-2xl p-6">
              <p className="text-xs text-muted-foreground uppercase font-semibold mb-2">Preocupaciones</p>
              <div className="flex flex-wrap gap-2">
                {diagnosis.concerns?.slice(0, 3).map((concern: string) => (
                  <span key={concern} className="bg-primary/10 text-primary text-xs px-3 py-1 rounded-full font-medium">
                    {concern}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Recommendations */}
          <div className="bg-gradient-to-br from-primary/5 to-secondary/5 rounded-2xl p-8 border border-border mb-12">
            <h2 className="font-serif text-2xl text-foreground mb-6">Recomendaciones personalizadas:</h2>
            <div className="space-y-4">
              <div className="flex gap-4">
                <div className="w-10 h-10 rounded-full bg-primary text-white flex items-center justify-center flex-shrink-0 text-sm font-bold">1</div>
                <div>
                  <p className="font-semibold text-foreground">Rutina matutina</p>
                  <p className="text-sm text-muted-foreground">Limpieza suave + sérum + crema + protector solar SPF50</p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="w-10 h-10 rounded-full bg-primary text-white flex items-center justify-center flex-shrink-0 text-sm font-bold">2</div>
                <div>
                  <p className="font-semibold text-foreground">Rutina nocturna</p>
                  <p className="text-sm text-muted-foreground">Limpieza + sérum activo + crema nutritiva</p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="w-10 h-10 rounded-full bg-primary text-white flex items-center justify-center flex-shrink-0 text-sm font-bold">3</div>
                <div>
                  <p className="font-semibold text-foreground">Tratamientos semanales</p>
                  <p className="text-sm text-muted-foreground">Exfoliación suave 1-2 veces por semana según tolerancia</p>
                </div>
              </div>
            </div>
          </div>

          {/* CTA */}
          <div className="flex gap-4 flex-col sm:flex-row justify-center">
            <Button asChild size="lg" className="rounded-full gap-2">
              <Link href="/productos">
                Ver productos recomendados
                <ArrowRightIcon className="w-4 h-4" />
              </Link>
            </Button>
            <Button asChild variant="outline" size="lg" className="rounded-full">
              <Link href="/diagnostico">Repetir diagnóstico</Link>
            </Button>
          </div>

          {/* Saved Date */}
          <p className="text-xs text-muted-foreground text-center mt-12">
            Diagnóstico guardado: {new Date(diagnosis.timestamp).toLocaleDateString("es-ES")}
          </p>
        </div>
      </main>
      <Footer />
    </>
  )
}
