import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { BeforeAfterUpload } from "@/components/before-after-upload"
import { UGCGallery } from "@/components/ugc-gallery"
import { AnimatedSection } from "@/components/animated-section"

export default function ShareTransformationPage() {
  return (
    <>
      <Navbar />
      <main className="min-h-screen bg-gradient-to-b from-background to-primary/5 pt-24 pb-12">
        <div className="container mx-auto px-6">
          {/* Header */}
          <AnimatedSection className="text-center max-w-3xl mx-auto mb-16">
            <h1 className="font-serif text-4xl md:text-5xl text-foreground mb-4">
              Comparte tu Transformación
            </h1>
            <p className="text-lg text-muted-foreground">
              Muestra tus resultados y aparece en nuestra galería de clientes verificados. Inspira a otros mientras demuestras que Skinware funciona.
            </p>
          </AnimatedSection>

          {/* Upload Form */}
          <div className="max-w-2xl mx-auto mb-16">
            <BeforeAfterUpload />
          </div>

          {/* Divider */}
          <div className="flex items-center justify-center gap-4 my-16">
            <div className="flex-1 h-px bg-border" />
            <span className="text-muted-foreground text-sm">Transformaciones ya compartidas</span>
            <div className="flex-1 h-px bg-border" />
          </div>

          {/* Gallery */}
          <UGCGallery />
        </div>
      </main>
      <Footer />
    </>
  )
}
