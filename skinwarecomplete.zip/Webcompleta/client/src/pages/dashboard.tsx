import { useState } from "react"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { UserProfileCard } from "@/components/user-profile-card"
import { OrdersHistory } from "@/components/orders-history"
import { LoyaltyPointsDashboard } from "@/components/loyalty-points-dashboard"
import { PreferencesCard } from "@/components/preferences-card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { User, ShoppingBag, Settings } from "lucide-react"

// Mock data
const userData = {
  name: "Sofia García",
  email: "sofia.garcia@example.com",
  tier: "Silver" as const,
  joinDate: "15 de marzo de 2024",
}

const ordersMock = [
  {
    id: "ORD-2024-001",
    date: "27 de noviembre de 2024",
    total: 125.50,
    status: "delivered" as const,
    items: 3,
  },
  {
    id: "ORD-2024-002",
    date: "20 de noviembre de 2024",
    total: 89.99,
    status: "shipped" as const,
    items: 2,
  },
  {
    id: "ORD-2024-003",
    date: "10 de noviembre de 2024",
    total: 156.00,
    status: "delivered" as const,
    items: 5,
  },
]

const loyaltyData = {
  currentPoints: 750,
  totalPointsEarned: 1250,
  nextMilestone: 1000,
  tier: "Silver" as const,
}

const preferencesData = {
  skinType: "Mixta",
  concerns: ["Acné", "Deshidratación", "Manchas"],
  newsletter: true,
  notifications: true,
}

export default function DashboardPage() {
  const [activeTab, setActiveTab] = useState("profile")

  return (
    <>
      <Navbar />
      <main className="min-h-screen bg-gradient-to-b from-background to-primary/5 pt-24 pb-12">
        <div className="container mx-auto px-6">
          {/* Header */}
          <div className="mb-12">
            <h1 className="font-serif text-4xl md:text-5xl text-foreground mb-2">Mi Cuenta</h1>
            <p className="text-lg text-muted-foreground">Gestiona tu perfil y acceso a tus compras</p>
          </div>

          {/* Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-3 mb-8">
              <TabsTrigger value="profile" className="rounded-full gap-2" data-testid="tab-profile">
                <User className="w-4 h-4" />
                <span className="hidden sm:inline">Perfil</span>
              </TabsTrigger>
              <TabsTrigger value="orders" className="rounded-full gap-2" data-testid="tab-orders">
                <ShoppingBag className="w-4 h-4" />
                <span className="hidden sm:inline">Compras</span>
              </TabsTrigger>
              <TabsTrigger value="settings" className="rounded-full gap-2" data-testid="tab-settings">
                <Settings className="w-4 h-4" />
                <span className="hidden sm:inline">Ajustes</span>
              </TabsTrigger>
            </TabsList>

            {/* Profile Tab */}
            <TabsContent value="profile" className="space-y-8">
              <UserProfileCard
                name={userData.name}
                email={userData.email}
                tier={userData.tier}
                joinDate={userData.joinDate}
              />
              <LoyaltyPointsDashboard
                currentPoints={loyaltyData.currentPoints}
                totalPointsEarned={loyaltyData.totalPointsEarned}
                nextMilestone={loyaltyData.nextMilestone}
                tier={loyaltyData.tier}
              />
            </TabsContent>

            {/* Orders Tab */}
            <TabsContent value="orders">
              <OrdersHistory orders={ordersMock} />
            </TabsContent>

            {/* Settings Tab */}
            <TabsContent value="settings">
              <PreferencesCard
                skinType={preferencesData.skinType}
                concerns={preferencesData.concerns}
                newsletter={preferencesData.newsletter}
                notifications={preferencesData.notifications}
              />
            </TabsContent>
          </Tabs>
        </div>
      </main>
      <Footer />
    </>
  )
}
