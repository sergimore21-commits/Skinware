import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { CheckIcon, ShoppingBagIcon, MailIcon } from "@/components/icons"
import { Link } from "wouter"

export default function CheckoutSuccessPage() {
  return (
    <>
      <Navbar />
      <main className="pt-20 min-h-screen flex items-center justify-center">
        <div className="container mx-auto px-6 py-24">
          <div className="max-w-lg mx-auto text-center">
            {/* Success Icon */}
            <div className="mb-8">
              <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <div className="w-14 h-14 rounded-full bg-primary flex items-center justify-center">
                  <CheckIcon className="w-8 h-8 text-primary-foreground" />
                </div>
              </div>
            </div>

            <h1 className="font-serif text-3xl md:text-4xl text-foreground mb-4">¡Pedido confirmado!</h1>

            <p className="text-muted-foreground text-lg mb-8">
              Gracias por tu compra. Hemos recibido tu pedido y lo estamos preparando con mucho cuidado.
            </p>

            {/* Order Info */}
            <div className="bg-card border border-border rounded-2xl p-6 mb-8 text-left space-y-4">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <MailIcon className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium text-foreground mb-1">Confirmación por email</h3>
                  <p className="text-sm text-muted-foreground">
                    Recibirás un email con los detalles de tu pedido y el número de seguimiento cuando sea enviado.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <ShoppingBagIcon className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium text-foreground mb-1">Tiempo de envío</h3>
                  <p className="text-sm text-muted-foreground">
                    Tu pedido llegará en 2-4 días laborables (Península). Baleares y Canarias pueden tardar unos días
                    más.
                  </p>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" className="rounded-full">
                <Link href="/">Volver al inicio</Link>
              </Button>
              <Button asChild variant="outline" size="lg" className="rounded-full bg-transparent">
                <Link href="/productos">Seguir comprando</Link>
              </Button>
            </div>

            {/* Support */}
            <p className="text-sm text-muted-foreground mt-8">
              ¿Tienes alguna pregunta?{" "}
              <Link href="/contacto" className="text-primary hover:underline">
                Contáctanos
              </Link>
            </p>
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}
