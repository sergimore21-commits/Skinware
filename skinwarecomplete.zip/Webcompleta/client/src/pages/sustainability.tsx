import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Chatbot } from "@/components/chatbot"
import { AnimatedSection } from "@/components/animated-section"

const initiatives = [
  { title: "Packaging Eco-friendly", description: "100% reciclable, sin plásticos innecesarios, tinta de soja", impact: "Reducción 60% residuos" },
  { title: "Producción On-Demand", description: "Solo fabricamos lo que se necesita", impact: "Reducción 40% químicos" },
  { title: "Ingredientes Sostenibles", description: "Proveedores certificados de comercio justo", impact: "Apoyo a comunidades" },
  { title: "Carbono Neutro", description: "Compensación de emisiones en transporte", impact: "2030 objetivo neto cero" },
]

export default function SustainabilityPage() {
  return (
    <>
      <Navbar />
      <main className="pt-20">
        <section className="py-24 bg-gradient-to-b from-primary/10 to-background">
          <div className="container mx-auto px-6">
            <AnimatedSection className="text-center max-w-3xl mx-auto">
              <h1 className="font-serif text-5xl text-foreground mb-4">Sostenibilidad</h1>
              <p className="text-lg text-muted-foreground">Belleza responsable con el planeta</p>
            </AnimatedSection>
          </div>
        </section>

        <section className="py-20">
          <div className="container mx-auto px-6">
            <div className="grid md:grid-cols-2 gap-8">
              {initiatives.map((init, i) => (
                <AnimatedSection key={i} delay={i * 100}>
                  <div className="bg-card border border-border rounded-2xl p-8 hover:shadow-lg transition-all">
                    <h3 className="font-serif text-xl text-foreground mb-2">{init.title}</h3>
                    <p className="text-sm text-muted-foreground mb-4">{init.description}</p>
                    <div className="bg-primary/10 rounded-lg p-3">
                      <p className="text-sm font-medium text-primary">{init.impact}</p>
                    </div>
                  </div>
                </AnimatedSection>
              ))}
            </div>
          </div>
        </section>
      </main>
      <Footer />
      <Chatbot />
    </>
  )
}
