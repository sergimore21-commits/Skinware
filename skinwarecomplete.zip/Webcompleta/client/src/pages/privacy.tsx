import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { AnimatedSection } from "@/components/animated-section"
import { Link } from "wouter"

export default function PrivacidadPage() {
  return (
    <>
      <Navbar />
      <main className="pt-20 min-h-screen">
        <div className="container mx-auto px-6 py-16">
          <AnimatedSection direction="up" className="max-w-3xl mx-auto">
            <h1 className="font-serif text-4xl md:text-5xl text-foreground mb-8">Política de Privacidad</h1>

            <div className="prose prose-lg max-w-none text-muted-foreground space-y-6">
              <p className="text-sm text-muted-foreground">Última actualización: 15 de enero de 2025</p>

              <section>
                <h2 className="font-serif text-2xl text-foreground mt-8 mb-4">1. Información que recopilamos</h2>
                <p>
                  En Skinware, nos tomamos muy en serio la privacidad de nuestros usuarios. Recopilamos información que
                  nos proporcionas directamente cuando:
                </p>
                <ul className="list-disc pl-6 space-y-2 mt-4">
                  <li>Te registras en nuestra plataforma</li>
                  <li>Realizas el diagnóstico de piel con IA</li>
                  <li>Te suscribes a nuestra newsletter</li>
                  <li>Realizas una compra</li>
                  <li>Te pones en contacto con nosotros</li>
                </ul>
              </section>

              <section>
                <h2 className="font-serif text-2xl text-foreground mt-8 mb-4">2. Uso de la información</h2>
                <p>Utilizamos la información recopilada para:</p>
                <ul className="list-disc pl-6 space-y-2 mt-4">
                  <li>Proporcionar y mejorar nuestros servicios</li>
                  <li>Personalizar tu experiencia de usuario</li>
                  <li>Procesar tus pedidos y pagos</li>
                  <li>Enviarte comunicaciones de marketing (con tu consentimiento)</li>
                  <li>Responder a tus consultas</li>
                  <li>Mejorar nuestro diagnóstico IA</li>
                </ul>
              </section>

              <section>
                <h2 className="font-serif text-2xl text-foreground mt-8 mb-4">3. Protección de datos</h2>
                <p>
                  Implementamos medidas de seguridad técnicas y organizativas para proteger tus datos personales contra
                  acceso no autorizado, pérdida o alteración. Esto incluye:
                </p>
                <ul className="list-disc pl-6 space-y-2 mt-4">
                  <li>Encriptación SSL en todas las transmisiones de datos</li>
                  <li>Acceso restringido a datos personales</li>
                  <li>Auditorías de seguridad regulares</li>
                  <li>Formación del personal en protección de datos</li>
                </ul>
              </section>

              <section>
                <h2 className="font-serif text-2xl text-foreground mt-8 mb-4">4. Tus derechos</h2>
                <p>De acuerdo con el Reglamento General de Protección de Datos (RGPD), tienes derecho a:</p>
                <ul className="list-disc pl-6 space-y-2 mt-4">
                  <li>Acceder a tus datos personales</li>
                  <li>Rectificar datos inexactos</li>
                  <li>Solicitar la eliminación de tus datos</li>
                  <li>Oponerte al tratamiento de tus datos</li>
                  <li>Portabilidad de tus datos</li>
                  <li>Retirar tu consentimiento en cualquier momento</li>
                </ul>
              </section>

              <section>
                <h2 className="font-serif text-2xl text-foreground mt-8 mb-4">5. Cookies</h2>
                <p>
                  Utilizamos cookies para mejorar tu experiencia en nuestra web. Para más información, consulta nuestra{" "}
                  <Link href="/cookies" className="text-primary hover:underline">
                    Política de Cookies
                  </Link>
                  .
                </p>
              </section>

              <section>
                <h2 className="font-serif text-2xl text-foreground mt-8 mb-4">6. Contacto</h2>
                <p>Si tienes preguntas sobre esta política de privacidad, puedes contactarnos en:</p>
                <p className="mt-4">
                  <strong className="text-foreground">Skinware</strong>
                  <br />
                  Email: privacidad@skinware.es
                  <br />
                  Dirección: Tarragona, España
                </p>
              </section>
            </div>
          </AnimatedSection>
        </div>
      </main>
      <Footer />
    </>
  )
}
