

import type React from "react"
import { useState, useRef, useEffect } from "react"
import { MessageCircleIcon, XIcon, SendIcon, SparklesIcon, Loader2Icon } from "@/components/icons"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { cn } from "@/lib/utils"

function WhatsAppIcon({ className }: { className?: string }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="currentColor"
      className={className}
    >
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
    </svg>
  )
}

interface Message {
  id: string
  role: "user" | "assistant"
  content: string
}

const WHATSAPP_NUMBER = "34977258430" // Skinware's WhatsApp Business number

export function Chatbot() {
  const [isOpen, setIsOpen] = useState(false)
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      role: "assistant",
      content:
        "¡Hola! Soy el asistente de Skinware. Estoy aquí para ayudarte a descubrir lo que tu piel necesita. ¿En qué puedo ayudarte?",
    },
  ])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  const openWhatsApp = (message?: string) => {
    const text = message || "Hola, me gustaría recibir asesoramiento personalizado sobre productos Skinware."
    const url = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(text)}`
    window.open(url, "_blank")
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim() || isLoading) return

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input,
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsLoading(true)

    // Simple response logic based on keywords
    setTimeout(() => {
      let response =
        "Gracias por tu mensaje. Nuestro equipo de expertos en skincare está disponible para ayudarte. ¿Te gustaría hacer nuestro diagnóstico de piel gratuito para obtener recomendaciones personalizadas?"

      const lowerInput = input.toLowerCase()
      if (lowerInput.includes("sérum") || lowerInput.includes("serum")) {
        response =
          "¡Excelente elección! Los sérums son fundamentales en cualquier rutina. Te recomiendo nuestro Sérum Vitamina C 15% para luminosidad, o el Sérum Ácido Hialurónico para hidratación profunda. ¿Cuál es tu principal preocupación de piel?"
      } else if (lowerInput.includes("grasa") || lowerInput.includes("graso")) {
        response =
          "Para piel grasa te recomiendo nuestra línea con Niacinamida. El Sérum Niacinamida 10% ayuda a controlar el sebo y refinar los poros. Combinado con nuestro Gel Limpiador Purificante, verás resultados en pocas semanas."
      } else if (lowerInput.includes("seca")) {
        response =
          "Para piel seca, la hidratación es clave. Te sugiero el Sérum Ácido Hialurónico seguido de nuestra Crema Nutritiva Intensa. Esta combinación proporciona hidratación en múltiples capas."
      } else if (lowerInput.includes("anti") || lowerInput.includes("arrugas") || lowerInput.includes("edad")) {
        response =
          "Para tratar signos de envejecimiento, nuestro Sérum Retinol 0.5% es ideal. Combínalo con Vitamina C por la mañana para máxima protección antioxidante. ¿Tienes experiencia con retinol?"
      } else if (lowerInput.includes("rutina")) {
        response =
          "Una rutina básica efectiva incluye: 1) Limpiador, 2) Sérum activo, 3) Hidratante, 4) Protector solar (mañana). Te invito a hacer nuestro diagnóstico IA para una rutina totalmente personalizada."
      } else if (
        lowerInput.includes("whatsapp") ||
        lowerInput.includes("hablar") ||
        lowerInput.includes("persona") ||
        lowerInput.includes("humano")
      ) {
        response =
          "¡Por supuesto! Puedes contactar directamente con nuestro equipo de expertos por WhatsApp. Haz clic en el botón de WhatsApp que aparece abajo para iniciar una conversación."
      }

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: response,
      }
      setMessages((prev) => [...prev, assistantMessage])
      setIsLoading(false)
    }, 1000)
  }

  const quickQuestions = ["¿Qué sérum me recomiendas?", "Tengo piel grasa", "Rutina anti-edad"]

  const handleQuickQuestion = (question: string) => {
    setInput(question)
    setTimeout(() => {
      const form = document.querySelector("form[data-chatbot-form]") as HTMLFormElement
      if (form) form.requestSubmit()
    }, 100)
  }

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className={cn(
          "fixed bottom-6 right-6 z-50 p-4 rounded-full bg-primary text-primary-foreground shadow-lg hover:shadow-xl transition-all duration-300",
          isOpen ? "scale-0 opacity-0" : "scale-100 opacity-100",
        )}
        aria-label="Abrir chat"
      >
        <div className="relative">
          <MessageCircleIcon className="h-6 w-6" />
          <SparklesIcon className="h-3 w-3 absolute -top-1 -right-1 text-secondary" />
        </div>
      </button>

      <div
        className={cn(
          "fixed bottom-6 right-6 z-50 w-[380px] max-w-[calc(100vw-48px)] bg-card rounded-2xl shadow-2xl border border-border transition-all duration-300 flex flex-col",
          isOpen ? "scale-100 opacity-100" : "scale-95 opacity-0 pointer-events-none",
        )}
        style={{ height: "min(600px, calc(100vh - 100px))" }}
      >
        <div className="flex items-center justify-between p-4 border-b border-border bg-muted rounded-t-2xl flex-shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-full bg-primary">
              <SparklesIcon className="h-4 w-4 text-primary-foreground" />
            </div>
            <div>
              <h3 className="font-medium text-sm text-foreground">Asistente Skinware</h3>
              <p className="text-xs text-muted-foreground flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-green-500"></span>
                Impulsado por IA
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsOpen(false)}
            className="p-1 hover:bg-accent rounded-full transition-colors"
            aria-label="Cerrar chat"
          >
            <XIcon className="h-5 w-5 text-muted-foreground" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={cn("flex", message.role === "assistant" ? "justify-start" : "justify-end")}
            >
              <div
                className={cn(
                  "max-w-[85%] p-3 rounded-2xl text-sm",
                  message.role === "assistant"
                    ? "bg-muted text-foreground rounded-bl-none"
                    : "bg-primary text-primary-foreground rounded-br-none",
                )}
              >
                {message.content}
              </div>
            </div>
          ))}

          {isLoading && (
            <div className="flex justify-start">
              <div className="bg-muted text-foreground p-3 rounded-2xl rounded-bl-none">
                <Loader2Icon className="h-4 w-4 animate-spin" />
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {messages.length <= 2 && (
          <div className="px-4 pb-2 flex-shrink-0">
            <p className="text-xs text-muted-foreground mb-2">Preguntas rápidas:</p>
            <div className="flex flex-wrap gap-2">
              {quickQuestions.map((question) => (
                <button
                  key={question}
                  onClick={() => handleQuickQuestion(question)}
                  className="text-xs px-3 py-1.5 rounded-full bg-secondary text-secondary-foreground hover:bg-secondary/80 transition-colors"
                >
                  {question}
                </button>
              ))}
            </div>
          </div>
        )}

        <div className="p-4 border-t border-border flex-shrink-0">
          <form onSubmit={handleSubmit} data-chatbot-form className="flex gap-2">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Escribe tu mensaje..."
              className="flex-1 rounded-full bg-muted border-0 focus-visible:ring-primary"
              disabled={isLoading}
            />
            <Button
              type="submit"
              size="icon"
              className="rounded-full bg-primary hover:bg-primary/90 flex-shrink-0"
              disabled={!input.trim() || isLoading}
            >
              {isLoading ? <Loader2Icon className="h-4 w-4 animate-spin" /> : <SendIcon className="h-4 w-4" />}
            </Button>
          </form>
        </div>
      </div>
    </>
  )
}
