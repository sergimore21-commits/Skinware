import { Shield, Lock, CheckCircle2 } from "lucide-react"
import { AnimatedSection } from "@/components/animated-section"

export function TrustBadges() {
  const badges = [
    {
      icon: CheckCircle2,
      title: "Garantía 30 Días",
      description: "Devolución sin preguntas si no estás satisfecho"
    },
    {
      icon: Lock,
      title: "Pago 100% Seguro",
      description: "Encriptación SSL y procesamiento seguro de datos"
    },
    {
      icon: Shield,
      title: "Certificado Dermatológico",
      description: "Fórmulas testeadas y aprobadas por especialistas"
    }
  ]

  return (
    <section className="py-12 md:py-16 border-b border-border">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-3 gap-6 md:gap-8 max-w-4xl mx-auto">
          {badges.map((badge, index) => {
            const Icon = badge.icon
            return (
              <AnimatedSection key={index} delay={index * 100}>
                <div className="flex flex-col items-center text-center p-6 rounded-xl border border-border bg-card/50 hover:bg-card hover:border-primary/50 transition-all duration-300" data-testid={`trust-badge-${index}`}>
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                    <Icon className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="font-semibold text-foreground mb-2">{badge.title}</h3>
                  <p className="text-sm text-muted-foreground">{badge.description}</p>
                </div>
              </AnimatedSection>
            )
          })}
        </div>
      </div>
    </section>
  )
}
