import { AnimatedSection } from "@/components/animated-section"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Package, ChevronRight } from "lucide-react"

interface Order {
  id: string
  date: string
  total: number
  status: "delivered" | "shipped" | "processing" | "cancelled"
  items: number
  image?: string
}

interface OrdersHistoryProps {
  orders: Order[]
}

const statusColors = {
  delivered: "bg-green-500/20 text-green-700",
  shipped: "bg-blue-500/20 text-blue-700",
  processing: "bg-yellow-500/20 text-yellow-700",
  cancelled: "bg-red-500/20 text-red-700",
}

const statusLabels = {
  delivered: "Entregado",
  shipped: "En camino",
  processing: "Procesando",
  cancelled: "Cancelado",
}

export function OrdersHistory({ orders }: OrdersHistoryProps) {
  return (
    <AnimatedSection>
      <div className="bg-card rounded-2xl border border-border p-8">
        <h3 className="font-serif text-2xl text-foreground mb-6">Historial de Compras</h3>

        {orders.length === 0 ? (
          <div className="text-center py-12">
            <Package className="w-16 h-16 text-muted-foreground mx-auto mb-4 opacity-50" />
            <p className="text-muted-foreground mb-4">Aún no tienes compras</p>
            <Button className="rounded-full">Ver Productos</Button>
          </div>
        ) : (
          <div className="space-y-4">
            {orders.map((order, index) => (
              <AnimatedSection key={order.id} direction="up" delay={index * 50}>
                <div className="border border-border rounded-xl p-4 hover:border-primary/50 transition-all cursor-pointer group" data-testid={`order-${order.id}`}>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <span className="font-mono text-sm font-semibold text-primary">#{order.id}</span>
                        <Badge className={statusColors[order.status]}>
                          {statusLabels[order.status]}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">{order.date}</p>
                      <p className="text-sm text-foreground">{order.items} producto{order.items > 1 ? "s" : ""}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-foreground mb-2">{order.total} EUR</p>
                      <ChevronRight className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors" />
                    </div>
                  </div>
                </div>
              </AnimatedSection>
            ))}
          </div>
        )}

        <Button variant="outline" className="w-full rounded-full mt-6">
          Ver todas las compras
        </Button>
      </div>
    </AnimatedSection>
  )
}
