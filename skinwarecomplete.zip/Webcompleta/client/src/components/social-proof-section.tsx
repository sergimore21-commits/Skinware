import { useEffect, useState } from "react"
import { AnimatedSection } from "@/components/animated-section"
import { StarIcon, ChevronLeftIcon, ChevronRightIcon } from "lucide-react"

const testimonials = [
  {
    name: "María García",
    role: "Barcelona, España",
    rating: 5,
    text: "Mi piel transformó completamente en 6 semanas. Pasé de tener brotes constantes a una piel radiante. Los resultados son increíbles y superaron mis expectativas.",
    initials: "MG",
    color: "from-pink-500 to-rose-500",
    result: "Redujo brotes en 90%"
  },
  {
    name: "Sofia López",
    role: "Madrid, España",
    rating: 5,
    text: "Finalmente encontré una solución personalizada que funciona para mi tipo de piel. El diagnóstico IA fue tan preciso que pedí un segundo producto.",
    initials: "SL",
    color: "from-blue-500 to-cyan-500",
    result: "Hidratación óptima conseguida"
  },
  {
    name: "Laura Martínez",
    role: "Valencia, España",
    rating: 5,
    text: "Excelente atención y productos de calidad premium. Lo recomiendo a todas mis amigas. Es la mejor inversión que he hecho en skincare.",
    initials: "LM",
    color: "from-purple-500 to-indigo-500",
    result: "Reversió líneas de expresión"
  },
  {
    name: "Alejandra Ruiz",
    role: "Sevilla, España",
    rating: 5,
    text: "Como dermatóloga, estoy impresionada con la personalización. Recomiendo Skinware a mis pacientes con confianza.",
    initials: "AR",
    color: "from-green-500 to-emerald-500",
    result: "Recomendado por profesionales"
  },
  {
    name: "Carla Sánchez",
    role: "Bilbao, España",
    rating: 5,
    text: "Piel sensible por fin controlada. No esperaba tanto de un producto, pero Skinware entendió exactamente qué necesitaba mi piel.",
    initials: "CS",
    color: "from-orange-500 to-amber-500",
    result: "Piel sensible controlada"
  },
]

const newCustomers = [
  { name: "Ana", initials: "A" },
  { name: "Rosa", initials: "R" },
  { name: "Marta", initials: "M" },
  { name: "Elena", initials: "E" },
]

export function SocialProofSection() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [autoPlay, setAutoPlay] = useState(true)
  const [displayedCount, setDisplayedCount] = useState(0)

  useEffect(() => {
    if (!autoPlay) return
    const timer = setInterval(() => {
      setCurrentIndex(prev => (prev + 1) % testimonials.length)
    }, 5000)
    return () => clearInterval(timer)
  }, [autoPlay])

  useEffect(() => {
    const timer = setInterval(() => {
      setDisplayedCount(prev => (prev + 1) % 15)
    }, 2000)
    return () => clearInterval(timer)
  }, [])

  const currentTestimonial = testimonials[currentIndex]

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length)
    setAutoPlay(false)
  }

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length)
    setAutoPlay(false)
  }

  return (
    <section className="py-20 bg-gradient-to-r from-primary/5 via-secondary/5 to-primary/5 border-y border-border/30">
      <div className="container mx-auto px-6">
        <AnimatedSection className="text-center mb-16">
          <h2 className="font-serif text-4xl md:text-5xl text-foreground mb-4">
            Lo que nuestros clientes logran
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Miles de personas han transformado su piel con nuestro diagnóstico IA personalizado
          </p>
        </AnimatedSection>

        <div className="grid lg:grid-cols-2 gap-12 items-center max-w-6xl mx-auto">
          {/* Carrusel de Testimonios */}
          <AnimatedSection>
            <div
              className="relative bg-card rounded-2xl p-8 border border-border shadow-lg min-h-96 flex flex-col justify-between"
              onMouseEnter={() => setAutoPlay(false)}
              onMouseLeave={() => setAutoPlay(true)}
            >
              {/* Stars */}
              <div className="flex gap-1 mb-4">
                {Array.from({ length: currentTestimonial.rating }).map((_, i) => (
                  <StarIcon key={i} className="w-5 h-5 fill-primary text-primary" />
                ))}
              </div>

              {/* Testimonial Text */}
              <div className="flex-1">
                <p className="text-lg text-foreground font-medium mb-2 leading-relaxed">
                  "{currentTestimonial.text}"
                </p>
                <div className="mt-4 p-3 bg-primary/5 rounded-lg border border-primary/20">
                  <p className="text-sm font-semibold text-primary">
                    ✓ {currentTestimonial.result}
                  </p>
                </div>
              </div>

              {/* Author */}
              <div className="flex items-center gap-4 mt-6 pt-6 border-t border-border w-full">
                <div className={`w-14 h-14 rounded-full bg-gradient-to-br ${currentTestimonial.color} flex items-center justify-center text-white font-bold text-lg shadow-lg ring-2 ring-primary/20 flex-shrink-0`}>
                  {currentTestimonial.initials}
                </div>
                <div className="flex-1">
                  <p className="font-serif font-bold text-foreground">{currentTestimonial.name}</p>
                  <p className="text-xs text-muted-foreground">{currentTestimonial.role}</p>
                </div>
                <div className="bg-green-100 text-green-700 px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap flex-shrink-0">✓ Verificado</div>
              </div>

              {/* Navigation Arrows */}
              <div className="absolute top-1/2 -translate-y-1/2 left-0 right-0 flex justify-between px-4 pointer-events-none">
                <button
                  onClick={prevSlide}
                  className="pointer-events-auto bg-primary/90 hover:bg-primary text-white p-2 rounded-full transition-all hover:scale-110 shadow-lg"
                  aria-label="Testimonial anterior"
                >
                  <ChevronLeftIcon className="w-5 h-5" />
                </button>
                <button
                  onClick={nextSlide}
                  className="pointer-events-auto bg-primary/90 hover:bg-primary text-white p-2 rounded-full transition-all hover:scale-110 shadow-lg"
                  aria-label="Siguiente testimonial"
                >
                  <ChevronRightIcon className="w-5 h-5" />
                </button>
              </div>

              {/* Dots Indicator */}
              <div className="flex gap-2 justify-center mt-6">
                {testimonials.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => {
                      setCurrentIndex(index)
                      setAutoPlay(false)
                    }}
                    className={`h-2 rounded-full transition-all cursor-pointer ${
                      index === currentIndex
                        ? "bg-primary w-6"
                        : "bg-border w-2 hover:bg-primary/50"
                    }`}
                    aria-label={`Ver testimonio ${index + 1}`}
                    data-testid={`testimonial-dot-${index}`}
                  />
                ))}
              </div>
            </div>
          </AnimatedSection>

          {/* Stats & Social Proof */}
          <AnimatedSection delay={100}>
            <div className="space-y-6">
              {/* New Customers */}
              <div className="bg-gradient-to-br from-primary/10 to-secondary/10 rounded-2xl p-6 border border-primary/20">
                <p className="text-xs text-muted-foreground uppercase tracking-wide mb-4 font-bold">
                  🚀 Se unieron hoy
                </p>
                <div className="flex items-center gap-3 mb-4">
                  <div className="flex -space-x-2">
                    {newCustomers.map((customer, i) => (
                      <div
                        key={i}
                        className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white text-xs font-bold border-2 border-background hover:scale-110 transition-transform"
                        title={customer.name}
                        data-testid={`new-customer-avatar-${i}`}
                      >
                        {customer.initials}
                      </div>
                    ))}
                  </div>
                  <span className="text-lg font-bold text-foreground">+{displayedCount} esta hora</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  Miles transforman su piel cada semana
                </p>
              </div>

              {/* Stats Grid */}
              <div className="space-y-4">
                <div className="flex items-center gap-4 p-4 bg-card rounded-xl border border-border hover:border-primary/50 transition-all">
                  <div className="text-4xl font-serif font-bold text-primary">98%</div>
                  <div className="text-sm">
                    <p className="font-semibold text-foreground mb-1">Satisfacción</p>
                    <p className="text-muted-foreground">La recomendarían</p>
                  </div>
                </div>
                <div className="flex items-center gap-4 p-4 bg-card rounded-xl border border-border hover:border-primary/50 transition-all">
                  <div className="text-4xl font-serif font-bold text-primary">4.8⭐</div>
                  <div className="text-sm">
                    <p className="font-semibold text-foreground mb-1">Rating promedio</p>
                    <p className="text-muted-foreground">Basado en 2,400+ opiniones</p>
                  </div>
                </div>
                <div className="flex items-center gap-4 p-4 bg-card rounded-xl border border-border hover:border-primary/50 transition-all">
                  <div className="text-4xl font-serif font-bold text-primary">14 días</div>
                  <div className="text-sm">
                    <p className="font-semibold text-foreground mb-1">Resultados garantizados</p>
                    <p className="text-muted-foreground">O dinero de vuelta</p>
                  </div>
                </div>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </div>
    </section>
  )
}
