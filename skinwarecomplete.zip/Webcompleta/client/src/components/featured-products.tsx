import { AnimatedSection } from "@/components/animated-section"
import { StarIcon, ShoppingBagIcon, ArrowRightIcon } from "@/components/icons"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { BlackFridayTimerBadge } from "@/components/black-friday-timer-badge"
import { Link } from "wouter"
import gelLimpiadorImg from "@assets/generated_images/skinware_gel_limpiador_purificante_bottle.png"
import serumVitaminaCImg from "@assets/generated_images/skinware_sérum_vitamina_c_bottle.png"
import serumHialuronicoImg from "@assets/generated_images/skinware_sérum_ácido_hialurónico_bottle.png"

const featuredProducts = [
  {
    id: "1",
    name: "Skinware Gel Limpiador Purificante",
    price: 26,
    rating: 4.8,
    reviews: 124,
    image: gelLimpiadorImg,
    badge: "Bestseller",
    description: "Limpieza profunda que elimina impurezas sin resecar.",
    stock: 4,
  },
  {
    id: "3",
    name: "Skinware Sérum Vitamina C 15%",
    price: 54,
    rating: 4.9,
    reviews: 256,
    image: serumVitaminaCImg,
    badge: "Favorito",
    description: "Antioxidante potente para luminosidad.",
    stock: 8,
  },
  {
    id: "4",
    name: "Skinware Sérum Ácido Hialurónico",
    price: 45,
    rating: 4.7,
    reviews: 189,
    image: serumHialuronicoImg,
    description: "Hidratación profunda multinivel.",
    stock: 3,
  },
]

export function FeaturedProducts() {
  return (
    <section id="black-friday-products" className="py-16 md:py-20">
      <div className="container mx-auto px-6">
        <AnimatedSection className="text-center mb-12 md:mb-16">
          <div className="flex justify-center mb-4">
            <BlackFridayTimerBadge />
          </div>
          <span className="inline-block px-4 py-2 rounded-full bg-secondary text-secondary-foreground text-xs font-medium tracking-wider uppercase mb-4">
            Bestsellers
          </span>
          <h2 className="font-serif text-3xl md:text-4xl text-foreground mb-3 md:mb-4 text-balance">
            Nuestros productos más amados
          </h2>
          <p className="text-muted-foreground text-sm md:text-base max-w-2xl mx-auto">
            Los favoritos de nuestros clientes. Fórmulas personalizadas que transforman la piel.
          </p>
        </AnimatedSection>

        <div className="grid md:grid-cols-3 gap-6 md:gap-8 max-w-5xl mx-auto">
          {featuredProducts.map((product, index) => (
            <AnimatedSection key={product.id} delay={index * 100}>
              <Link href={`/productos/${product.id}`}>
                <div className="group bg-card border border-border rounded-2xl overflow-hidden hover:shadow-2xl transition-all duration-300 cursor-pointer h-full flex flex-col hover:border-primary/50 hover:scale-105 relative hover:-translate-y-1">
                  {/* Gradient overlay on hover */}
                  <div className="absolute inset-0 bg-gradient-to-br from-primary/0 to-primary/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300 z-10 pointer-events-none" />
                  
                  {/* Product Image */}
                  <div className="aspect-square overflow-hidden bg-gradient-to-br from-muted to-muted/50 relative">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-contain p-4 group-hover:scale-125 transition-transform duration-700"
                    />
                    {product.badge && (
                      <div className="absolute top-3 right-3 z-20">
                        <div className={`px-3 py-1.5 rounded-full font-bold text-xs tracking-wider uppercase ${
                          product.badge === "Bestseller" 
                            ? "bg-red-500 text-white shadow-lg shadow-red-500/50" 
                            : "bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-lg shadow-amber-500/50"
                        }`}>
                          ⭐ {product.badge}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Product Info */}
                  <div className="p-5 md:p-6 flex flex-col flex-grow">
                    <h3 className="font-serif text-lg text-foreground mb-2 group-hover:text-primary transition-colors line-clamp-2">
                      {product.name}
                    </h3>
                    <p className="text-sm text-muted-foreground mb-4 flex-grow">{product.description}</p>

                    {/* Rating */}
                    <div className="flex items-center gap-2 mb-4">
                      <div className="flex gap-0.5">
                        {[...Array(5)].map((_, i) => (
                          <StarIcon
                            key={i}
                            className={`w-4 h-4 ${i < Math.floor(product.rating) ? "fill-primary text-primary" : "text-muted-foreground"}`}
                          />
                        ))}
                      </div>
                      <span className="text-xs text-muted-foreground">({product.reviews})</span>
                    </div>

                    {/* Stock Alert */}
                    {product.stock && product.stock <= 5 && (
                      <div className={`mb-3 px-3 py-2 rounded-lg text-center font-semibold text-xs uppercase tracking-wider ${
                        product.stock <= 3
                          ? "bg-red-500/20 text-red-600 border border-red-300/50"
                          : "bg-orange-500/20 text-orange-600 border border-orange-300/50"
                      }`}>
                        {product.stock <= 1 ? "⚠️ Última unidad" : `⏰ Solo ${product.stock} disponibles`}
                      </div>
                    )}

                    {/* Price and CTA */}
                    <div className="flex flex-col gap-3 pt-4 border-t border-border">
                      <div className="flex items-center justify-between">
                        <p className="font-serif text-2xl text-primary font-bold">{product.price}€</p>
                        <span className="text-xs text-muted-foreground uppercase tracking-wider">Entrega 3-5 días</span>
                      </div>
                      <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground rounded-full group transition-all duration-300 hover:scale-105 hover:shadow-lg font-semibold">
                        <ShoppingBagIcon className="w-4 h-4 mr-2 group-hover:scale-110 transition-transform" />
                        Agregar al carrito
                      </Button>
                    </div>
                  </div>
                </div>
              </Link>
            </AnimatedSection>
          ))}
        </div>

        <AnimatedSection delay={300} className="text-center mt-12">
          <Link href="/productos">
            <button className="px-8 py-3 border border-primary text-primary rounded-full hover:bg-primary hover:text-primary-foreground transition-colors font-medium">
              Ver todos los productos
            </button>
          </Link>
        </AnimatedSection>
      </div>
    </section>
  )
}
