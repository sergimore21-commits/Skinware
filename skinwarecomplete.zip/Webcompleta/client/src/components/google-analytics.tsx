import { useEffect } from "react"

// Reemplaza con tu ID de medición de Google Analytics
const GA_MEASUREMENT_ID = "G-XXXXXXXXXX"

export function GoogleAnalytics() {
  // Mock implementation for now
  return null
}

// Función helper para enviar eventos personalizados
export function trackEvent(action: string, category: string, label?: string, value?: number) {
  console.log("GA Event:", { action, category, label, value })
}

// Declaración de tipos para gtag
declare global {
  interface Window {
    gtag: (command: "config" | "event" | "js", targetId: string | Date, config?: Record<string, unknown>) => void
    dataLayer: unknown[]
  }
}
