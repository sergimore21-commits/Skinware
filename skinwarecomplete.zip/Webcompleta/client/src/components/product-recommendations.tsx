import { Link } from "wouter"
import { AnimatedSection } from "@/components/animated-section"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import gelLimpiadorImg from "@assets/generated_images/skinware_gel_limpiador_purificante_bottle.png"
import serumVitaminaCImg from "@assets/generated_images/skinware_sérum_vitamina_c_bottle.png"
import serumHialuronicoImg from "@assets/generated_images/skinware_sérum_ácido_hialurónico_bottle.png"

const recommended = [
  {
    id: "1",
    name: "Skinware Gel Limpiador Purificante",
    category: "Base",
    image: gelLimpiadorImg,
  },
  {
    id: "3",
    name: "Skinware Sérum Vitamina C 15%",
    category: "Activo",
    image: serumVitaminaCImg,
  },
  {
    id: "4",
    name: "Skinware Sérum Ácido Hialurónico",
    category: "Hidratación",
    image: serumHialuronicoImg,
  },
]

export function ProductRecommendations() {
  return (
    <section className="py-16 bg-muted/30">
      <div className="container mx-auto px-6">
        <AnimatedSection direction="up" className="text-center mb-12">
          <h2 className="font-serif text-3xl md:text-4xl text-foreground mb-4">Completa tu rutina</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Estos productos funcionan perfectamente juntos para una rutina integral
          </p>
        </AnimatedSection>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto mb-8">
          {recommended.map((product, index) => (
            <AnimatedSection key={product.id} direction="up" delay={index * 100}>
              <Link href={`/productos/${product.id}`} className="group block">
                <div className="bg-card rounded-2xl border border-border overflow-hidden hover:shadow-lg transition-all">
                  <div className="aspect-square overflow-hidden bg-muted relative">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <Badge className="absolute top-3 left-3 bg-primary/20 text-primary border-primary/30">
                      {product.category}
                    </Badge>
                  </div>
                  <div className="p-4">
                    <p className="font-medium text-foreground group-hover:text-primary transition-colors">{product.name}</p>
                  </div>
                </div>
              </Link>
            </AnimatedSection>
          ))}
        </div>

        <AnimatedSection direction="up" className="text-center">
          <Button asChild size="lg" className="rounded-full bg-primary text-primary-foreground hover:bg-primary/90">
            <Link href="/productos">Ver todos los productos</Link>
          </Button>
        </AnimatedSection>
      </div>
    </section>
  )
}
