import { useRef, useState, useEffect } from "react"
import { PlayIcon, PauseIcon, VolumeXIcon, Volume2Icon } from "lucide-react"
import { AnimatedSection } from "@/components/animated-section"
import aiSkinAnalysisVideo from "@assets/generated_videos/ultra_smooth_continuous_skin_analysis_visual.mp4"

export function VideoHeroSection() {
  const videoRef = useRef<HTMLVideoElement>(null)
  const [isPlaying, setIsPlaying] = useState(true)
  const [isMuted, setIsMuted] = useState(true)

  useEffect(() => {
    const video = videoRef.current
    if (!video) return
    
    // Auto-play en mute
    video.play().catch(() => {
      // Si falla, mantener pausado
    })
  }, [])

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause()
        setIsPlaying(false)
      } else {
        videoRef.current.play()
        setIsPlaying(true)
      }
    }
  }

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted
      setIsMuted(!isMuted)
    }
  }


  return (
    <section className="py-20 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-background to-secondary/10" />
      <div className="absolute top-0 left-1/3 w-96 h-96 bg-primary/20 rounded-full blur-3xl animate-pulse" />
      <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-secondary/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: "1s" }} />

      <div className="container mx-auto px-6 relative z-10">
        <AnimatedSection direction="up" className="max-w-5xl mx-auto">
          {/* Video Container */}
          <div className="relative rounded-3xl overflow-hidden border border-primary/30 shadow-2xl group bg-black w-full">
            <video
              ref={videoRef}
              className="w-full h-auto bg-black display-block"
              poster="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1920 1080'%3E%3Crect fill='%23000' width='1920' height='1080'/%3E%3C/svg%3E"
              autoPlay
              muted
              loop
              playsInline
              data-testid="hero-video"
            >
              <source src={aiSkinAnalysisVideo} type="video/mp4" />
              Tu navegador no soporta vídeos HTML5
            </video>

            {/* Play Button Overlay - Simple */}
            {!isPlaying && (
              <div
                className="absolute inset-0 bg-black/40 flex items-center justify-center cursor-pointer group-hover:bg-black/50 transition-all"
                onClick={togglePlay}
                data-testid="video-play-button"
              >
                <div className="w-20 h-20 rounded-full bg-white/90 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <PlayIcon className="w-10 h-10 text-black ml-1" />
                </div>
              </div>
            )}
          </div>

          {/* Text Content */}
          <div className="text-center mt-12">
            <span className="inline-block px-4 py-2 rounded-full bg-primary/15 text-primary text-xs font-bold tracking-widest uppercase mb-6 border border-primary/30">
              🔬 Ciencia Visual en Acción
            </span>
            <h2 className="font-serif text-4xl md:text-5xl text-foreground mb-6 text-balance leading-tight">
              Descubre cómo nuestro algoritmo IA
              <br />
              <span className="text-primary">transforma tu rutina</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-balance mb-8 leading-relaxed">
              En este video ves exactamente cómo funciona: desde el análisis de tus necesidades hasta la creación de tu fórmula personalizada. Todo en minutos.
            </p>

            {/* Key Points */}
            <div className="grid md:grid-cols-3 gap-4 max-w-2xl mx-auto mb-8">
              <div className="bg-card/50 border border-border rounded-lg p-4 backdrop-blur-sm">
                <p className="text-2xl font-bold text-primary mb-1">47</p>
                <p className="text-xs text-muted-foreground font-medium">Parámetros analizados</p>
              </div>
              <div className="bg-card/50 border border-border rounded-lg p-4 backdrop-blur-sm">
                <p className="text-2xl font-bold text-primary mb-1">2 min</p>
                <p className="text-xs text-muted-foreground font-medium">Diagnóstico completo</p>
              </div>
              <div className="bg-card/50 border border-border rounded-lg p-4 backdrop-blur-sm">
                <p className="text-2xl font-bold text-primary mb-1">∞</p>
                <p className="text-xs text-muted-foreground font-medium">Fórmulas únicas</p>
              </div>
            </div>
          </div>
        </AnimatedSection>
      </div>
    </section>
  )
}
