import { useState, useEffect } from "react"
import { ShoppingBag, Eye } from "lucide-react"

const purchases = [
  "Ana García compró Rutina Completa",
  "María López compró Sérum Revitalizante",
  "Carmen Rodríguez compró Kit Diagnóstico",
  "Sofía Martínez compró Tratamiento Intensivo",
  "Elena Fernández compró Crema Nutritiva",
  "Isabel Sánchez compró Mascarilla Regeneradora",
  "Rosa Gómez compró Limpiador Facial",
  "Laura Moreno compró Sérum Hidratante",
]

export function LiveNotificationsBar() {
  const [notifications, setNotifications] = useState<
    Array<{ id: string; type: "purchase" | "viewing"; text: string }>
  >([])

  useEffect(() => {
    // Initial notifications
    const initialNotifications = [
      {
        id: "1",
        type: "purchase" as const,
        text: purchases[Math.floor(Math.random() * purchases.length)],
      },
      {
        id: "2",
        type: "viewing" as const,
        text: `${Math.floor(Math.random() * 8) + 12} personas viendo esto ahora`,
      },
      {
        id: "3",
        type: "purchase" as const,
        text: purchases[Math.floor(Math.random() * purchases.length)],
      },
    ]
    setNotifications(initialNotifications)

    // Add new notifications every 5 seconds
    const interval = setInterval(() => {
      setNotifications((prev) => {
        const isViewingNext = Math.random() > 0.6
        const newNotification = {
          id: Date.now().toString(),
          type: (isViewingNext ? "viewing" : "purchase") as const,
          text: isViewingNext
            ? `${Math.floor(Math.random() * 8) + 12} personas viendo esto ahora`
            : purchases[Math.floor(Math.random() * purchases.length)],
        }

        // Keep max 3 notifications, remove oldest
        return [...prev.slice(-2), newNotification]
      })
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="fixed bottom-6 left-6 z-40 max-w-sm space-y-3 pointer-events-none">
      {notifications.map((notification) => (
        <div
          key={notification.id}
          className="bg-white rounded-lg shadow-lg border border-gray-200 p-3 flex items-center gap-3 pointer-events-auto animate-in slide-in-from-bottom-4 duration-300"
        >
          {notification.type === "purchase" ? (
            <>
              <ShoppingBag className="w-4 h-4 text-green-600 flex-shrink-0" />
              <p className="text-sm text-gray-800">
                <span className="font-semibold">✓</span> {notification.text}
              </p>
            </>
          ) : (
            <>
              <Eye className="w-4 h-4 text-blue-600 flex-shrink-0 animate-pulse" />
              <p className="text-sm text-gray-800">{notification.text}</p>
            </>
          )}
        </div>
      ))}
    </div>
  )
}
