"use client"

import type * as React from "react"
import * as TogglePrimitive from "@radix-ui/react-toggle"
import { cn } from "@/lib/utils"

const variantStyles = {
  default: "bg-transparent",
  outline: "border border-input bg-transparent shadow-xs hover:bg-accent hover:text-accent-foreground",
}

const sizeStyles = {
  default: "h-9 px-2 min-w-9",
  sm: "h-8 px-1.5 min-w-8",
  lg: "h-10 px-2.5 min-w-10",
}

export interface ToggleProps extends React.ComponentProps<typeof TogglePrimitive.Root> {
  variant?: keyof typeof variantStyles
  size?: keyof typeof sizeStyles
}

function Toggle({ className, variant = "default", size = "default", ...props }: ToggleProps) {
  return (
    <TogglePrimitive.Root
      data-slot="toggle"
      className={cn(
        "inline-flex items-center justify-center gap-2 rounded-md text-sm font-medium hover:bg-muted hover:text-muted-foreground disabled:pointer-events-none disabled:opacity-50 data-[state=on]:bg-accent data-[state=on]:text-accent-foreground [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 outline-none transition-colors whitespace-nowrap",
        variantStyles[variant],
        sizeStyles[size],
        className,
      )}
      {...props}
    />
  )
}

function toggleVariants({
  variant = "default",
  size = "default",
  className = "",
}: { variant?: keyof typeof variantStyles; size?: keyof typeof sizeStyles; className?: string } = {}) {
  return cn(
    "inline-flex items-center justify-center gap-2 rounded-md text-sm font-medium hover:bg-muted hover:text-muted-foreground disabled:pointer-events-none disabled:opacity-50 data-[state=on]:bg-accent data-[state=on]:text-accent-foreground [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 outline-none transition-colors whitespace-nowrap",
    variantStyles[variant],
    sizeStyles[size],
    className,
  )
}

export { Toggle, toggleVariants }
