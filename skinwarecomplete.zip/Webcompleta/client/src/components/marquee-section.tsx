

const keywords = [
  "Clean Beauty",
  "Data Science",
  "Personalización",
  "Tecnología",
  "Innovación",
  "Skincare Inteligente",
  "Diagnóstico IA",
  "Belleza Consciente",
  "Ciencia Avanzada",
  "Resultados Reales",
]

export function MarqueeSection() {
  return (
    <section className="py-8 bg-primary/5 overflow-hidden border-y border-border">
      <div className="relative flex">
        {/* First marquee track */}
        <div className="animate-marquee flex items-center gap-8 whitespace-nowrap">
          {keywords.map((keyword, index) => (
            <div key={index} className="flex items-center gap-8">
              <span className="text-lg md:text-xl font-serif text-foreground/80">{keyword}</span>
              <span className="text-primary text-2xl">✦</span>
            </div>
          ))}
        </div>

        {/* Duplicate for seamless loop */}
        <div className="animate-marquee flex items-center gap-8 whitespace-nowrap" aria-hidden="true">
          {keywords.map((keyword, index) => (
            <div key={index} className="flex items-center gap-8">
              <span className="text-lg md:text-xl font-serif text-foreground/80">{keyword}</span>
              <span className="text-primary text-2xl">✦</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
