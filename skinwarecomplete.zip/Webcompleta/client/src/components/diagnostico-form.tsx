

import { useState } from "react"
import { ArrowRightIcon, ArrowLeftIcon, SparklesIcon, CheckIcon, Loader2Icon } from "@/components/icons"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { AnimatedSection } from "@/components/animated-section"
import { cn } from "@/lib/utils"
import { Link } from "wouter"
import gelLimpiadorImg from "@assets/generated_images/skinware_gel_limpiador_purificante_bottle.png"
import lecheLimpiadoraImg from "@assets/generated_images/skinware_leche_limpiadora_nutritiva_bottle.png"
import serumVitaminaCImg from "@assets/generated_images/skinware_sérum_vitamina_c_bottle.png"
import serumHialuronicoImg from "@assets/generated_images/skinware_sérum_ácido_hialurónico_bottle.png"
import serumRetinolImg from "@assets/generated_images/skinware_sérum_retinol_bottle.png"
import serumNiacinamidaImg from "@assets/generated_images/skinware_sérum_niacinamida_bottle.png"
import protectorSolarImg from "@assets/generated_images/skinware_protector_solar_spf50_tube.png"
import cremaHidratanteImg from "@assets/generated_images/skinware_crema_hidratante_ligera_jar.png"

const productImages: { [key: string]: string } = {
  "cleanser-purifying": gelLimpiadorImg,
  "serum-niacinamide": serumNiacinamidaImg,
  "cleanser-nourishing": lecheLimpiadoraImg,
  "serum-hyaluronic": serumHialuronicoImg,
  "cleanser-gentle": gelLimpiadorImg,
  "serum-retinol": serumRetinolImg,
  "serum-vitc": serumVitaminaCImg,
  "moisturizer": cremaHidratanteImg,
  "sunscreen": protectorSolarImg,
}

type SkinType = "grasa" | "seca" | "mixta" | "normal" | "sensible" | null
type SkinConcern = "acne" | "arrugas" | "manchas" | "rojeces" | "poros" | "opacidad"
type Lifestyle = "estres_alto" | "poco_sueno" | "exposicion_sol" | "contaminacion" | "ejercicio" | "dieta_sana"

interface FormData {
  skinType: SkinType
  concerns: SkinConcern[]
  age: string
  lifestyle: Lifestyle[]
  currentRoutine: string
  goals: string
}

const initialFormData: FormData = {
  skinType: null,
  concerns: [],
  age: "",
  lifestyle: [],
  currentRoutine: "",
  goals: "",
}

const skinTypeOptions = [
  { value: "grasa", label: "Grasa", description: "Brillos, poros visibles, tendencia a impurezas" },
  { value: "seca", label: "Seca", description: "Tirantez, descamación, falta de luminosidad" },
  { value: "mixta", label: "Mixta", description: "Zona T grasa, mejillas secas o normales" },
  { value: "normal", label: "Normal", description: "Equilibrada, sin problemas evidentes" },
  { value: "sensible", label: "Sensible", description: "Reacciona fácilmente, rojeces frecuentes" },
]

const concernOptions = [
  { value: "acne", label: "Acné y granitos" },
  { value: "arrugas", label: "Arrugas y líneas finas" },
  { value: "manchas", label: "Manchas e hiperpigmentación" },
  { value: "rojeces", label: "Rojeces e irritación" },
  { value: "poros", label: "Poros dilatados" },
  { value: "opacidad", label: "Falta de luminosidad" },
]

const ageOptions = [
  { value: "18-25", label: "18-25 años" },
  { value: "26-35", label: "26-35 años" },
  { value: "36-45", label: "36-45 años" },
  { value: "46-55", label: "46-55 años" },
  { value: "55+", label: "55+ años" },
]

const lifestyleOptions = [
  { value: "estres_alto", label: "Estrés alto" },
  { value: "poco_sueno", label: "Menos de 7h de sueño" },
  { value: "exposicion_sol", label: "Exposición solar frecuente" },
  { value: "contaminacion", label: "Vivo en ciudad contaminada" },
  { value: "ejercicio", label: "Ejercicio regular" },
  { value: "dieta_sana", label: "Dieta equilibrada" },
]

const routineOptions = [
  { value: "ninguna", label: "No tengo rutina definida" },
  { value: "basica", label: "Básica (limpieza + hidratante)" },
  { value: "intermedia", label: "Intermedia (+ sérum o protector solar)" },
  { value: "completa", label: "Completa (varios pasos, activos específicos)" },
]

const goalOptions = [
  { value: "antienvejecimiento", label: "Prevenir/tratar signos de envejecimiento" },
  { value: "claridad", label: "Piel más clara y uniforme" },
  { value: "hidratacion", label: "Hidratación profunda" },
  { value: "control", label: "Controlar grasa y brillos" },
  { value: "calmar", label: "Calmar y reducir rojeces" },
  { value: "luminosidad", label: "Más luminosidad y glow" },
]

export function DiagnosticoForm() {
  const [step, setStep] = useState(0)
  const [formData, setFormData] = useState<FormData>(initialFormData)
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [results, setResults] = useState<any>(null)

  const totalSteps = 6
  const progress = ((step + 1) / totalSteps) * 100

  const canProceed = () => {
    switch (step) {
      case 0:
        return formData.skinType !== null
      case 1:
        return formData.concerns.length > 0
      case 2:
        return formData.age !== ""
      case 3:
        return formData.lifestyle.length > 0
      case 4:
        return formData.currentRoutine !== ""
      case 5:
        return formData.goals !== ""
      default:
        return false
    }
  }

  const handleNext = () => {
    if (step < totalSteps - 1) {
      setStep(step + 1)
    } else {
      analyzeResults()
    }
  }

  const saveDiagnosisResults = (resultData: any) => {
    const savedDiagnosis = {
      timestamp: new Date().toISOString(),
      ...formData,
      recommendations: resultData,
    }
    localStorage.setItem("skinware-diagnosis", JSON.stringify(savedDiagnosis))
    window.location.href = "/diagnostico/resultados"
  }

  const handleBack = () => {
    if (step > 0) setStep(step - 1)
  }

  const analyzeResults = async () => {
    setIsAnalyzing(true)
    await new Promise((resolve) => setTimeout(resolve, 2000))
    const recommendations = generateRecommendations(formData)
    setResults(recommendations)
    saveDiagnosisResults(recommendations)
    setIsAnalyzing(false)
  }

  const toggleConcern = (concern: SkinConcern) => {
    setFormData((prev) => ({
      ...prev,
      concerns: prev.concerns.includes(concern)
        ? prev.concerns.filter((c) => c !== concern)
        : [...prev.concerns, concern],
    }))
  }

  const toggleLifestyle = (lifestyle: Lifestyle) => {
    setFormData((prev) => ({
      ...prev,
      lifestyle: prev.lifestyle.includes(lifestyle)
        ? prev.lifestyle.filter((l) => l !== lifestyle)
        : [...prev.lifestyle, lifestyle],
    }))
  }

  const generateRecommendations = (data: FormData) => {
    const products = []
    const routine = { morning: [] as string[], night: [] as string[] }

    if (data.skinType === "grasa" || data.skinType === "mixta") {
      products.push({
        name: "Skinware Gel Limpiador Purificante",
        description: "Limpieza profunda que elimina impurezas sin resecar.",
        key: "cleanser-purifying",
      })
      products.push({
        name: "Skinware Sérum Niacinamida 10%",
        description: "Control de sebo y poros refinados.",
        key: "serum-niacinamide",
      })
    } else if (data.skinType === "seca") {
      products.push({
        name: "Skinware Leche Limpiadora Nutritiva",
        description: "Limpieza suave que nutre e hidrata.",
        key: "cleanser-nourishing",
      })
      products.push({
        name: "Skinware Sérum Ácido Hialurónico",
        description: "Hidratación profunda multinivel.",
        key: "serum-hyaluronic",
      })
    } else {
      products.push({
        name: "Skinware Gel Limpiador Purificante",
        description: "Limpieza profunda que elimina impurezas sin resecar.",
        key: "cleanser-gentle",
      })
    }

    if (data.concerns.includes("arrugas")) {
      products.push({ name: "Skinware Sérum Retinol 0.5%", description: "Renovación celular y anti-edad.", key: "serum-retinol" })
    }
    if (data.concerns.includes("manchas")) {
      products.push({ name: "Skinware Sérum Vitamina C 15%", description: "Antioxidante potente para luminosidad.", key: "serum-vitc" })
    }

    products.push({
      name: "Skinware Crema Hidratante Ligera",
      description: "Hidratación equilibrada con acabado mate para pieles mixtas y grasas.",
      key: "moisturizer",
    })
    products.push({
      name: "Skinware Protector Solar SPF50",
      description: "Protección invisible de amplio espectro.",
      key: "sunscreen",
    })

    routine.morning = ["Limpieza suave", "Sérum vitamina C", "Crema hidratante", "Protector solar SPF50"]
    routine.night = ["Doble limpieza", "Tónico equilibrante", "Sérum tratamiento", "Crema nutritiva"]

    return {
      skinProfile: { type: data.skinType, concerns: data.concerns, age: data.age },
      products,
      routine,
      tips: [
        "Mantén una rutina constante durante al menos 4 semanas para ver resultados",
        "Introduce nuevos activos de uno en uno",
        "Nunca olvides el protector solar, incluso en días nublados",
      ],
    }
  }

  if (isAnalyzing) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center container mx-auto px-6 py-20">
        <div className="max-w-xl mx-auto text-center">
          <AnimatedSection direction="up">
            <div className="w-20 h-20 mx-auto mb-8 rounded-full bg-primary/10 flex items-center justify-center">
              <Loader2Icon className="w-10 h-10 text-primary animate-spin" />
            </div>
            <h2 className="font-serif text-3xl text-foreground mb-4">Analizando tu perfil de piel...</h2>
            <p className="text-muted-foreground">
              Nuestra IA está procesando tus respuestas para crear una rutina personalizada perfecta para ti.
            </p>
          </AnimatedSection>
        </div>
      </div>
    )
  }

  if (results) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center container mx-auto px-6 py-20">
        <div className="max-w-4xl mx-auto w-full">
          <AnimatedSection direction="up" className="text-center mb-12">
            <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-primary/10 flex items-center justify-center">
              <SparklesIcon className="w-10 h-10 text-primary" />
            </div>
            <h1 className="font-serif text-4xl md:text-5xl text-foreground mb-4">Tu Rutina Personalizada</h1>
            <p className="text-muted-foreground text-lg">
              Basada en tu perfil de piel {results.skinProfile.type}, hemos creado esta rutina especialmente para ti.
            </p>
          </AnimatedSection>

          <AnimatedSection direction="up" delay={200}>
            <h2 className="font-serif text-2xl text-foreground mb-6">Productos Recomendados</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
              {results.products.map((product: any) => (
                <div
                  key={product.key}
                  className="bg-card rounded-2xl p-6 border border-border hover:border-primary/50 transition-all"
                >
                  <div className="w-full aspect-square rounded-xl bg-muted mb-4 overflow-hidden">
                    <img
                      src={productImages[product.key] || gelLimpiadorImg}
                      alt={product.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <h3 className="font-medium text-foreground">{product.name}</h3>
                  <p className="text-sm text-muted-foreground mt-1">{product.description}</p>
                </div>
              ))}
            </div>
          </AnimatedSection>

          <AnimatedSection direction="up" delay={300}>
            <h2 className="font-serif text-2xl text-foreground mb-6">Tu Rutina Diaria</h2>
            <div className="grid md:grid-cols-2 gap-6 mb-12">
              <div className="bg-card rounded-2xl p-6 border border-border">
                <h3 className="font-medium text-foreground mb-4 flex items-center gap-2">
                  <span className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center text-xs">AM</span>
                  Rutina de Mañana
                </h3>
                <ul className="space-y-3">
                  {results.routine.morning.map((s: string, index: number) => (
                    <li key={index} className="flex items-center gap-3 text-muted-foreground">
                      <span className="w-6 h-6 rounded-full bg-primary/10 text-primary text-xs flex items-center justify-center">
                        {index + 1}
                      </span>
                      {s}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="bg-card rounded-2xl p-6 border border-border">
                <h3 className="font-medium text-foreground mb-4 flex items-center gap-2">
                  <span className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-xs">
                    PM
                  </span>
                  Rutina de Noche
                </h3>
                <ul className="space-y-3">
                  {results.routine.night.map((s: string, index: number) => (
                    <li key={index} className="flex items-center gap-3 text-muted-foreground">
                      <span className="w-6 h-6 rounded-full bg-primary/10 text-primary text-xs flex items-center justify-center">
                        {index + 1}
                      </span>
                      {s}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </AnimatedSection>

          <AnimatedSection direction="up" delay={400}>
            <div className="bg-primary/5 rounded-2xl p-6 mb-8">
              <h3 className="font-medium text-foreground mb-4">Consejos para ti</h3>
              <ul className="space-y-2">
                {results.tips.map((tip: string, index: number) => (
                  <li key={index} className="flex items-start gap-3 text-muted-foreground text-sm">
                    <CheckIcon className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                    {tip}
                  </li>
                ))}
              </ul>
            </div>
          </AnimatedSection>

          <div className="flex justify-center gap-4">
            <Button
              variant="outline"
              onClick={() => {
                setResults(null)
                setStep(0)
                setFormData(initialFormData)
              }}
              className="rounded-full px-8"
            >
              Repetir diagnóstico
            </Button>
            <Button className="rounded-full px-8" asChild>
              <Link href="/productos">Ver productos recomendados</Link>
            </Button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center container mx-auto px-6 py-12">
      <div className="max-w-2xl mx-auto w-full">
        <AnimatedSection direction="up" className="text-center mb-8">
          <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full mb-4">
            <SparklesIcon className="w-4 h-4" />
            <span className="text-sm font-medium">Diagnóstico IA</span>
          </div>
          <h1 className="font-serif text-3xl md:text-4xl text-foreground mb-2">Descubre tu piel perfecta</h1>
          <p className="text-muted-foreground">Responde unas preguntas y nuestra IA creará tu rutina personalizada.</p>
        </AnimatedSection>

        <div className="mb-8">
          <div className="flex justify-between text-sm text-muted-foreground mb-2">
            <span>
              Paso {step + 1} de {totalSteps}
            </span>
            <span>{Math.round(progress)}%</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        <div className="bg-card rounded-2xl p-6 md:p-8 border border-border shadow-sm min-h-[400px]">
          {step === 0 && (
            <AnimatedSection direction="up" key="step-0">
              <h2 className="font-serif text-xl md:text-2xl text-foreground mb-6">¿Cuál es tu tipo de piel?</h2>
              <div className="grid gap-3">
                {skinTypeOptions.map((option) => (
                  <button
                    key={option.value}
                    onClick={() => setFormData({ ...formData, skinType: option.value as SkinType })}
                    className={cn(
                      "w-full p-4 rounded-xl border text-left transition-all",
                      formData.skinType === option.value
                        ? "border-primary bg-primary/5"
                        : "border-border hover:border-primary/50",
                    )}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium text-foreground">{option.label}</p>
                        <p className="text-sm text-muted-foreground">{option.description}</p>
                      </div>
                      {formData.skinType === option.value && <CheckIcon className="w-5 h-5 text-primary" />}
                    </div>
                  </button>
                ))}
              </div>
            </AnimatedSection>
          )}

          {step === 1 && (
            <AnimatedSection direction="up" key="step-1">
              <h2 className="font-serif text-xl md:text-2xl text-foreground mb-2">¿Qué preocupaciones tienes?</h2>
              <p className="text-muted-foreground text-sm mb-6">Selecciona todas las que apliquen.</p>
              <div className="grid grid-cols-2 gap-3">
                {concernOptions.map((option) => (
                  <button
                    key={option.value}
                    onClick={() => toggleConcern(option.value as SkinConcern)}
                    className={cn(
                      "p-4 rounded-xl border text-left transition-all",
                      formData.concerns.includes(option.value as SkinConcern)
                        ? "border-primary bg-primary/5"
                        : "border-border hover:border-primary/50",
                    )}
                  >
                    <div className="flex items-center justify-between">
                      <p className="font-medium text-foreground text-sm">{option.label}</p>
                      {formData.concerns.includes(option.value as SkinConcern) && (
                        <CheckIcon className="w-4 h-4 text-primary" />
                      )}
                    </div>
                  </button>
                ))}
              </div>
            </AnimatedSection>
          )}

          {step === 2 && (
            <AnimatedSection direction="up" key="step-2">
              <h2 className="font-serif text-xl md:text-2xl text-foreground mb-6">¿Cuál es tu rango de edad?</h2>
              <div className="grid gap-3">
                {ageOptions.map((option) => (
                  <button
                    key={option.value}
                    onClick={() => setFormData({ ...formData, age: option.value })}
                    className={cn(
                      "w-full p-4 rounded-xl border text-left transition-all",
                      formData.age === option.value
                        ? "border-primary bg-primary/5"
                        : "border-border hover:border-primary/50",
                    )}
                  >
                    <div className="flex items-center justify-between">
                      <p className="font-medium text-foreground">{option.label}</p>
                      {formData.age === option.value && <CheckIcon className="w-5 h-5 text-primary" />}
                    </div>
                  </button>
                ))}
              </div>
            </AnimatedSection>
          )}

          {step === 3 && (
            <AnimatedSection direction="up" key="step-3">
              <h2 className="font-serif text-xl md:text-2xl text-foreground mb-2">Cuéntanos sobre tu estilo de vida</h2>
              <p className="text-muted-foreground text-sm mb-6">Selecciona los factores que te aplican.</p>
              <div className="grid grid-cols-2 gap-3">
                {lifestyleOptions.map((option) => (
                  <button
                    key={option.value}
                    onClick={() => toggleLifestyle(option.value as Lifestyle)}
                    className={cn(
                      "p-4 rounded-xl border text-left transition-all",
                      formData.lifestyle.includes(option.value as Lifestyle)
                        ? "border-primary bg-primary/5"
                        : "border-border hover:border-primary/50",
                    )}
                  >
                    <div className="flex items-center justify-between">
                      <p className="font-medium text-foreground text-sm">{option.label}</p>
                      {formData.lifestyle.includes(option.value as Lifestyle) && (
                        <CheckIcon className="w-4 h-4 text-primary" />
                      )}
                    </div>
                  </button>
                ))}
              </div>
            </AnimatedSection>
          )}

          {step === 4 && (
            <AnimatedSection direction="up" key="step-4">
              <h2 className="font-serif text-xl md:text-2xl text-foreground mb-6">¿Cómo es tu rutina actual?</h2>
              <div className="grid gap-3">
                {routineOptions.map((option) => (
                  <button
                    key={option.value}
                    onClick={() => setFormData({ ...formData, currentRoutine: option.value })}
                    className={cn(
                      "w-full p-4 rounded-xl border text-left transition-all",
                      formData.currentRoutine === option.value
                        ? "border-primary bg-primary/5"
                        : "border-border hover:border-primary/50",
                    )}
                  >
                    <div className="flex items-center justify-between">
                      <p className="font-medium text-foreground">{option.label}</p>
                      {formData.currentRoutine === option.value && <CheckIcon className="w-5 h-5 text-primary" />}
                    </div>
                  </button>
                ))}
              </div>
            </AnimatedSection>
          )}

          {step === 5 && (
            <AnimatedSection direction="up" key="step-5">
              <h2 className="font-serif text-xl md:text-2xl text-foreground mb-6">¿Cuál es tu objetivo principal?</h2>
              <div className="grid gap-3">
                {goalOptions.map((option) => (
                  <button
                    key={option.value}
                    onClick={() => setFormData({ ...formData, goals: option.value })}
                    className={cn(
                      "w-full p-4 rounded-xl border text-left transition-all",
                      formData.goals === option.value
                        ? "border-primary bg-primary/5"
                        : "border-border hover:border-primary/50",
                    )}
                  >
                    <div className="flex items-center justify-between">
                      <p className="font-medium text-foreground">{option.label}</p>
                      {formData.goals === option.value && <CheckIcon className="w-5 h-5 text-primary" />}
                    </div>
                  </button>
                ))}
              </div>
            </AnimatedSection>
          )}
        </div>

        <div className="flex justify-between mt-6">
          <Button
            variant="outline"
            onClick={handleBack}
            disabled={step === 0}
            className="rounded-full px-6 gap-2 bg-transparent"
          >
            <ArrowLeftIcon className="w-4 h-4" /> Anterior
          </Button>
          <Button onClick={handleNext} disabled={!canProceed()} className="rounded-full px-6 gap-2">
            {step === totalSteps - 1 ? "Analizar" : "Siguiente"} <ArrowRightIcon className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  )
}
