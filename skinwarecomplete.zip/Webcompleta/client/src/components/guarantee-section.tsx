import { AnimatedSection } from "@/components/animated-section"
import { Shield, Calendar, ArrowRight, CheckCircle2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Link } from "wouter"

export function GuaranteeSection() {
  return (
    <section className="py-20 bg-gradient-to-r from-primary/10 via-secondary/10 to-primary/10 border-y border-primary/20">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          <AnimatedSection className="relative bg-gradient-to-br from-card to-card/50 rounded-3xl p-12 border-2 border-primary/30 shadow-2xl overflow-hidden">
            {/* Background Decoration */}
            <div className="absolute top-0 right-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
            
            <div className="relative z-10">
              <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-8">
                {/* Left side - Main message */}
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="p-2 bg-primary/20 rounded-lg">
                      <Shield className="w-6 h-6 text-primary" />
                    </div>
                    <span className="text-xs font-bold text-primary uppercase tracking-widest">
                      Compra sin riesgo
                    </span>
                  </div>

                  <h2 className="font-serif text-4xl md:text-5xl text-foreground mb-4 leading-tight">
                    Garantía <span className="text-primary">14 Días</span>
                    <br />
                    o tu dinero de vuelta
                  </h2>

                  <p className="text-lg text-muted-foreground mb-6 max-w-xl">
                    Si en 14 días no ves resultados visibles en tu piel, te devolvemos el 100% sin preguntas. Tu satisfacción es nuestra prioridad.
                  </p>

                  {/* Benefits List */}
                  <div className="space-y-3 mb-8">
                    {[
                      "Reembolso completo en 24-48 horas",
                      "No necesitas justificación",
                      "Garantía en TODOS los productos",
                      "Atención al cliente en español"
                    ].map((benefit, index) => (
                      <div key={index} className="flex items-center gap-3">
                        <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0" />
                        <span className="text-foreground font-medium">{benefit}</span>
                      </div>
                    ))}
                  </div>

                  <Button
                    size="lg"
                    asChild
                    className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-full px-8 group transition-all duration-300 font-semibold h-14"
                  >
                    <Link href="/productos" className="flex items-center gap-2">
                      Compra ahora con confianza
                      <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                    </Link>
                  </Button>
                </div>

                {/* Right side - Visual Confidence Indicators */}
                <div className="flex-1 flex flex-col gap-4">
                  {/* 14 Days Icon */}
                  <div className="text-center p-8 bg-gradient-to-br from-primary/10 to-secondary/10 rounded-2xl border border-primary/20">
                    <Calendar className="w-12 h-12 text-primary mx-auto mb-3" />
                    <div className="text-5xl font-bold text-primary mb-2">14</div>
                    <p className="text-sm text-muted-foreground font-semibold">Días garantía</p>
                  </div>

                  {/* Trust Stats */}
                  <div className="grid grid-cols-2 gap-3">
                    <div className="p-4 bg-card rounded-lg border border-border text-center">
                      <p className="text-2xl font-bold text-primary">99.2%</p>
                      <p className="text-xs text-muted-foreground mt-1">Clientes satisfechos</p>
                    </div>
                    <div className="p-4 bg-card rounded-lg border border-border text-center">
                      <p className="text-2xl font-bold text-primary">0%</p>
                      <p className="text-xs text-muted-foreground mt-1">Riesgos ocultos</p>
                    </div>
                  </div>

                  {/* Small text */}
                  <p className="text-xs text-muted-foreground text-center italic">
                    Respaldado por nuestra confianza en la ciencia y tus resultados.
                  </p>
                </div>
              </div>
            </div>
          </AnimatedSection>

          {/* Bottom reassurance text */}
          <AnimatedSection delay={100} className="text-center mt-8">
            <p className="text-sm text-muted-foreground">
              <span className="font-semibold text-foreground">Garantía transferible:</span> Incluso si la compra es para regalar, el beneficiario tiene 14 días desde la entrega.
            </p>
          </AnimatedSection>
        </div>
      </div>
    </section>
  )
}
