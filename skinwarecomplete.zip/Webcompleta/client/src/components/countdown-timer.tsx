import { useState, useEffect } from "react"

interface CountdownTimerProps {
  endDate: Date
  onExpired?: () => void
  className?: string
}

interface TimeLeft {
  days: number
  hours: number
  minutes: number
  seconds: number
  expired: boolean
}

export function CountdownTimer({ endDate, onExpired, className = "" }: CountdownTimerProps) {
  const [timeLeft, setTimeLeft] = useState<TimeLeft>({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
    expired: false,
  })

  useEffect(() => {
    const updateTimer = () => {
      const now = new Date()
      const diff = endDate.getTime() - now.getTime()

      if (diff <= 0) {
        setTimeLeft({
          days: 0,
          hours: 0,
          minutes: 0,
          seconds: 0,
          expired: true,
        })
        onExpired?.()
        return
      }

      const days = Math.floor(diff / (1000 * 60 * 60 * 24))
      const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))
      const seconds = Math.floor((diff % (1000 * 60)) / 1000)

      setTimeLeft({
        days,
        hours,
        minutes,
        seconds,
        expired: false,
      })
    }

    updateTimer()
    const interval = setInterval(updateTimer, 1000)
    return () => clearInterval(interval)
  }, [endDate, onExpired])

  if (timeLeft.expired) {
    return <span className={className}>Oferta finalizada</span>
  }

  return (
    <div className={`flex gap-2 ${className}`} data-testid="countdown-timer">
      <div className="flex flex-col items-center">
        <span className="text-3xl font-bold text-primary-foreground">{String(timeLeft.days).padStart(2, "0")}</span>
        <span className="text-xs text-primary-foreground/70">Días</span>
      </div>
      <span className="text-3xl font-bold text-primary-foreground/60">:</span>
      <div className="flex flex-col items-center">
        <span className="text-3xl font-bold text-primary-foreground">{String(timeLeft.hours).padStart(2, "0")}</span>
        <span className="text-xs text-primary-foreground/70">Horas</span>
      </div>
      <span className="text-3xl font-bold text-primary-foreground/60">:</span>
      <div className="flex flex-col items-center">
        <span className="text-3xl font-bold text-primary-foreground">{String(timeLeft.minutes).padStart(2, "0")}</span>
        <span className="text-xs text-primary-foreground/70">Min</span>
      </div>
      <span className="text-3xl font-bold text-primary-foreground/60">:</span>
      <div className="flex flex-col items-center">
        <span className={`text-3xl font-bold ${timeLeft.seconds < 10 ? "text-primary-foreground animate-pulse" : "text-primary-foreground"}`}>
          {String(timeLeft.seconds).padStart(2, "0")}
        </span>
        <span className="text-xs text-primary-foreground/70">Seg</span>
      </div>
    </div>
  )
}
