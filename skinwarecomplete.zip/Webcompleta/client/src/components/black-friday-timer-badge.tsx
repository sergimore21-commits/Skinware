import { useState, useEffect } from "react"
import { Zap } from "lucide-react"

export function BlackFridayTimerBadge() {
  const [timeLeft, setTimeLeft] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0 })
  const [isActive, setIsActive] = useState(true)

  useEffect(() => {
    const calculateTimeLeft = () => {
      // Calcula el endTime como 3 días desde las 20:00h de hoy
      const now = new Date()
      const endTime = new Date(now)
      endTime.setHours(20, 0, 0, 0) // Hoy a las 20:00h
      endTime.setDate(endTime.getDate() + 3) // + 3 días

      const difference = endTime.getTime() - now.getTime()

      if (difference > 0) {
        setIsActive(true)
        const days = Math.floor(difference / (1000 * 60 * 60 * 24))
        const hours = Math.floor((difference / (1000 * 60 * 60)) % 24)
        const minutes = Math.floor((difference / 1000 / 60) % 60)
        const seconds = Math.floor((difference / 1000) % 60)
        setTimeLeft({ days, hours, minutes, seconds })
      } else {
        setIsActive(false)
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 })
      }
    }

    calculateTimeLeft()
    const timer = setInterval(calculateTimeLeft, 1000)
    return () => clearInterval(timer)
  }, [])

  if (!isActive) {
    return null
  }

  return (
    <div className="inline-flex items-center gap-2 bg-gradient-to-r from-red-600 to-red-700 text-white px-4 py-2 rounded-full text-sm font-bold shadow-lg shadow-red-600/50 animate-pulse">
      <Zap className="w-4 h-4" />
      <span>
        Termina en: {String(timeLeft.days).padStart(2, "0")}d {String(timeLeft.hours).padStart(2, "0")}h {String(timeLeft.minutes).padStart(2, "0")}m
      </span>
    </div>
  )
}
