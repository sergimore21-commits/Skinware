import { AnimatedSection } from "@/components/animated-section"
import { Button } from "@/components/ui/button"
import { Link } from "wouter"
import { ArrowRight, Sparkles, Shield, Zap } from "lucide-react"

export function ConversionOptimizedCTA() {
  return (
    <section className="py-24 bg-gradient-to-r from-primary via-primary/90 to-primary/80 relative overflow-hidden">
      {/* Background Decoration */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-white/10 rounded-full blur-3xl" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-white/5 rounded-full blur-3xl" />

      <div className="container mx-auto px-6 relative z-10">
        <AnimatedSection className="text-center max-w-3xl mx-auto">
          <h2 className="font-serif text-4xl md:text-5xl lg:text-6xl text-white mb-6 leading-tight">
            Tu piel transformada en
            <br />
            <span className="text-yellow-200">14 días</span>
          </h2>

          <p className="text-lg md:text-xl text-white/90 mb-8 max-w-2xl mx-auto font-medium">
            O te devolvemos tu dinero. Ciencia personalizada + garantía 100%.
          </p>

          {/* Trust Indicators */}
          <div className="grid md:grid-cols-3 gap-4 mb-10 text-white/90">
            <div className="flex items-center justify-center gap-2">
              <Shield className="w-5 h-5" />
              <span className="text-sm font-medium">Garantía 14 días</span>
            </div>
            <div className="flex items-center justify-center gap-2">
              <Zap className="w-5 h-5" />
              <span className="text-sm font-medium">IA 98.7% precisa</span>
            </div>
            <div className="flex items-center justify-center gap-2">
              <Sparkles className="w-5 h-5" />
              <span className="text-sm font-medium">100% personalizado</span>
            </div>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
            <Button
              size="lg"
              asChild
              className="bg-white text-primary hover:bg-white/90 rounded-full px-8 group transition-all font-bold text-lg h-16"
            >
              <Link href="/diagnostico" className="flex items-center justify-center gap-2">
                Hacer Diagnóstico Gratis
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Link>
            </Button>
            <Button
              size="lg"
              asChild
              className="border-2 border-white bg-transparent text-white hover:bg-white/20 rounded-full px-8 font-bold text-lg h-16 transition-all"
            >
              <Link href="/productos" className="flex items-center justify-center">
                Ver Productos
              </Link>
            </Button>
          </div>

          {/* Reassurance */}
          <p className="text-white/70 text-sm">
            ✓ Envío gratis en pedidos +50€  •  ✓ Entrega en 24-48h  •  ✓ Atención 24/7
          </p>
        </AnimatedSection>
      </div>
    </section>
  )
}
