
import { useEffect, useState, useRef } from "react"
import { AnimatedSection } from "@/components/animated-section"
interface StatItemProps {
  value: number
  suffix?: string
  label: string
}

function StatItem({ value, suffix = "", label }: StatItemProps) {
  const [count, setCount] = useState(0)
  const ref = useRef<HTMLDivElement>(null)
  const [hasAnimated, setHasAnimated] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !hasAnimated) {
          setHasAnimated(true)
          const duration = 2000
          const steps = 60
          const increment = value / steps
          let current = 0
          const timer = setInterval(() => {
            current += increment
            if (current >= value) {
              setCount(value)
              clearInterval(timer)
            } else {
              setCount(Math.floor(current))
            }
          }, duration / steps)
        }
      },
      { threshold: 0.5 },
    )

    if (ref.current) {
      observer.observe(ref.current)
    }

    return () => observer.disconnect()
  }, [value, hasAnimated])

  return (
    <div ref={ref} className="text-center flex justify-center">
      <div className="bg-gradient-to-br from-card via-card to-primary/5 p-8 rounded-2xl border border-primary/20 h-40 w-full flex flex-col items-center justify-center shadow-lg hover:shadow-xl hover:border-primary/40 transition-all duration-300 relative overflow-hidden">
        {/* Animated background gradient */}
        <div className="absolute inset-0 bg-gradient-to-r from-primary/0 via-primary/5 to-primary/0 opacity-0 hover:opacity-100 transition-opacity duration-500" />
        
        <div className="relative z-10 font-serif text-4xl md:text-5xl lg:text-6xl font-bold mb-2">
          <span className="bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent">
            {count.toLocaleString()}
          </span>
          <span className="text-primary ml-1">{suffix}</span>
        </div>
        <p className="text-muted-foreground text-xs md:text-sm font-medium tracking-wide">{label}</p>
      </div>
    </div>
  )
}

export function StatsSection() {
  const stats = [
    { value: 15000, suffix: "+", label: "Clientes satisfechos" },
    { value: 98, suffix: "%", label: "Tasa de satisfacción" },
    { value: 50, suffix: "+", label: "Fórmulas personalizadas" },
    { value: 12, suffix: "", label: "Premios de innovación" },
  ]

  return (
    <section className="py-20 bg-muted/50">
      <div className="container mx-auto px-6">
        <AnimatedSection direction="up" className="text-center mb-12">
          <h2 className="font-serif text-3xl md:text-4xl text-foreground">Resultados que hablan por sí solos</h2>
        </AnimatedSection>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-16">
          {stats.map((stat, index) => (
            <AnimatedSection key={stat.label} direction="up" delay={index * 100}>
              <StatItem {...stat} />
            </AnimatedSection>
          ))}
        </div>
      </div>
    </section>
  )
}
