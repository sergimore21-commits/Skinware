import { AnimatedSection } from "@/components/animated-section"
import { Package, Clock, CheckCircle, FileText, Truck, RotateCw } from "lucide-react"

const steps = [
  {
    icon: Clock,
    title: "Ventana de 14 días",
    description: "Tienes 14 días desde la entrega para solicitar la devolución. Sin excepciones."
  },
  {
    icon: FileText,
    title: "Contacta soporte",
    description: "Envía un email a support@skinware.es con tu número de pedido. Respuesta en 2 horas."
  },
  {
    icon: Package,
    title: "Prepara tu devolución",
    description: "Empaca el producto (abierto o sin abrir) con la etiqueta de envío que te enviaremos."
  },
  {
    icon: Truck,
    title: "Envía gratis",
    description: "Usa la etiqueta prepagada. No pagues nada por el envío de devolución."
  },
  {
    icon: CheckCircle,
    title: "Recibimos y verificamos",
    description: "Confirmamos la recepción en 24 horas. Verificamos condiciones del producto."
  },
  {
    icon: RotateCw,
    title: "Reembolso procesado",
    description: "Tu dinero se devuelve en 3-5 días hábiles. 100% sin retenciones."
  }
]

const faqItems = [
  {
    q: "¿Necesito el empaque original?",
    a: "No es obligatorio, pero ayuda. Empaca el producto de forma segura."
  },
  {
    q: "¿Puedo devolver productos abiertos?",
    a: "Sí. Si abierto o sin abrir, no importa. Solo debe estar en buen estado."
  },
  {
    q: "¿Y si usé todo el producto?",
    a: "Aceptamos devoluciones incluso si lo probaste. La garantía es por resultados, no por uso."
  },
  {
    q: "¿Qué pasa con regalos?",
    a: "Si fue regalo, el receptor tiene 14 días desde la entrega para devolver."
  },
  {
    q: "¿Hay cargos ocultos?",
    a: "Ninguno. Ni envío de devolución, ni comisiones. Solo reembolso limpio."
  },
  {
    q: "¿Puedo cambiar por otro producto?",
    a: "Sí. Devuelve el tuyo y usamos el dinero para otro producto de igual o menor valor."
  }
]

export function ReturnPolicySection() {
  return (
    <section className="py-20 bg-gradient-to-b from-background to-secondary/5">
      <div className="container mx-auto px-6">
        {/* Header */}
        <AnimatedSection className="text-center mb-16">
          <h2 className="font-serif text-4xl md:text-5xl text-foreground mb-4">
            Política de Devoluciones Transparente
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Porque tu confianza es lo más importante. Sin sorpresas, sin complicaciones.
          </p>
        </AnimatedSection>

        {/* Process Steps */}
        <div className="mb-20">
          <h3 className="font-serif text-2xl text-foreground mb-12 text-center">
            Proceso paso a paso
          </h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
            {steps.map((step, index) => {
              const Icon = step.icon
              return (
                <AnimatedSection key={index} direction="up" delay={index * 80}>
                  <div className="relative">
                    {/* Step Number */}
                    <div className="absolute -top-4 -left-4 w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-bold text-sm shadow-lg">
                      {index + 1}
                    </div>

                    {/* Card */}
                    <div className="bg-card rounded-xl p-6 border border-border hover:border-primary/50 transition-all h-full">
                      <div className="mb-3 p-2 bg-primary/10 w-fit rounded-lg">
                        <Icon className="w-5 h-5 text-primary" />
                      </div>
                      <h4 className="font-semibold text-foreground mb-2">{step.title}</h4>
                      <p className="text-sm text-muted-foreground">{step.description}</p>
                    </div>
                  </div>
                </AnimatedSection>
              )
            })}
          </div>
        </div>

        {/* Key Points */}
        <AnimatedSection className="max-w-4xl mx-auto mb-20 bg-gradient-to-r from-primary/5 to-secondary/5 rounded-2xl p-8 border border-primary/20">
          <h3 className="font-serif text-2xl text-foreground mb-6">Lo que debes saber</h3>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold text-foreground mb-3 flex items-center gap-2">
                <span className="text-primary font-bold">✓</span> Envío de devolución
              </h4>
              <p className="text-sm text-muted-foreground">
                Nosotros pagamos. Tú no gastas un euro en devolver el producto. Te enviamos la etiqueta gratis.
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-3 flex items-center gap-2">
                <span className="text-primary font-bold">✓</span> Sin justificaciones
              </h4>
              <p className="text-sm text-muted-foreground">
                No necesitas explicar por qué devuelves. Solo solicítalo dentro de 14 días y listo.
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-3 flex items-center gap-2">
                <span className="text-primary font-bold">✓</span> Reembolso 100%
              </h4>
              <p className="text-sm text-muted-foreground">
                Devolvemos el precio completo. Sin descuentos, sin retenciones, sin letra pequeña.
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-3 flex items-center gap-2">
                <span className="text-primary font-bold">✓</span> Rápido
              </h4>
              <p className="text-sm text-muted-foreground">
                Tu dinero llega en 3-5 días hábiles desde que verificamos tu devolución.
              </p>
            </div>
          </div>
        </AnimatedSection>

        {/* FAQ */}
        <div className="max-w-3xl mx-auto">
          <h3 className="font-serif text-2xl text-foreground mb-8 text-center">
            Preguntas frecuentes
          </h3>
          <div className="space-y-4">
            {faqItems.map((item, index) => (
              <AnimatedSection key={index} delay={index * 50}>
                <details className="group bg-card rounded-lg border border-border hover:border-primary/50 transition-all overflow-hidden">
                  <summary className="flex items-center justify-between p-4 cursor-pointer">
                    <h4 className="font-semibold text-foreground pr-4">{item.q}</h4>
                    <span className="text-primary text-xl group-open:rotate-180 transition-transform flex-shrink-0">
                      +
                    </span>
                  </summary>
                  <div className="px-4 pb-4 pt-0 text-sm text-muted-foreground border-t border-border">
                    {item.a}
                  </div>
                </details>
              </AnimatedSection>
            ))}
          </div>
        </div>

        {/* Bottom CTA */}
        <AnimatedSection className="text-center mt-16">
          <div className="bg-gradient-to-r from-primary/5 to-secondary/5 rounded-2xl p-8 border border-primary/20">
            <p className="text-lg text-foreground font-semibold mb-2">
              ¿Preguntas sobre devoluciones?
            </p>
            <p className="text-muted-foreground mb-4">
              Nuestro equipo está disponible 24/7 en support@skinware.es
            </p>
            <p className="text-sm text-muted-foreground">
              Respuesta garantizada en menos de 2 horas
            </p>
          </div>
        </AnimatedSection>
      </div>
    </section>
  )
}
