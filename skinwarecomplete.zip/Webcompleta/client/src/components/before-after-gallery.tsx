import { useState } from "react"
import { AnimatedSection } from "@/components/animated-section"
import beforeImage1 from "@assets/generated_images/before:_dehydrated_dull_skin.png"
import afterImage1 from "@assets/generated_images/after:_improved_hydrated_glowing_skin.png"
import beforeImage2 from "@assets/generated_images/before:_severe_acne_breakout.png"
import afterImage2 from "@assets/generated_images/after:_cleared_acne_skin.png"
import beforeImage3 from "@assets/generated_images/before:_wrinkled_aged_skin.png"
import afterImage3 from "@assets/generated_images/after:_improved_firm_skin.png"

const transformations = [
  {
    id: 1,
    title: "Piel deshidratada a radiante",
    description: "Transformación completa en 8 semanas",
    before: beforeImage1,
    after: afterImage1,
    skinType: "Piel sensible",
    duration: "8 semanas"
  },
  {
    id: 2,
    title: "Acné y poros dilatados",
    description: "Control total del sebo y claridad",
    before: beforeImage2,
    after: afterImage2,
    skinType: "Piel grasa",
    duration: "10 semanas"
  },
  {
    id: 3,
    title: "Arrugas y flacidez",
    description: "Restauración de elasticidad y firmeza",
    before: beforeImage3,
    after: afterImage3,
    skinType: "Piel madura",
    duration: "12 semanas"
  }
]

export function BeforeAfterGallery() {
  const [activeIndex, setActiveIndex] = useState(0)

  return (
    <section className="py-24 bg-gradient-to-b from-background via-primary/5 to-background">
      <div className="container mx-auto px-6">
        <AnimatedSection className="text-center mb-16">
          <span className="inline-block px-4 py-2 rounded-full bg-secondary text-secondary-foreground text-xs font-medium tracking-wider uppercase mb-4">
            Transformaciones reales
          </span>
          <h2 className="font-serif text-3xl md:text-5xl text-foreground mb-4 text-balance">
            Resultados que inspiran
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Descubre cómo Skinware ha transformado la piel de cientos de clientes en semanas
          </p>
        </AnimatedSection>

        {/* Gallery */}
        <div className="grid lg:grid-cols-3 gap-8 mb-8">
          {transformations.map((item, index) => (
            <AnimatedSection key={item.id} delay={index * 100}>
              <div
                onClick={() => setActiveIndex(index)}
                className={`cursor-pointer group relative rounded-2xl overflow-hidden border-2 transition-all duration-300 ${
                  activeIndex === index
                    ? "border-primary shadow-2xl scale-105"
                    : "border-border hover:border-primary/50"
                }`}
                data-testid={`before-after-card-${item.id}`}
              >
                <div className="grid grid-cols-2 gap-2 h-72">
                  <img
                    src={item.before}
                    alt="Antes"
                    className="w-full h-full object-cover rounded-l-lg"
                  />
                  <img
                    src={item.after}
                    alt="Después"
                    className="w-full h-full object-cover rounded-r-lg"
                  />
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex flex-col justify-end p-6">
                  <h3 className="font-serif text-xl text-white font-bold mb-2">{item.title}</h3>
                  <p className="text-white/80 text-sm mb-3">{item.description}</p>
                  <div className="flex gap-4 text-xs text-white/70">
                    <span className="bg-white/20 px-3 py-1 rounded-full">{item.skinType}</span>
                    <span className="bg-primary/40 px-3 py-1 rounded-full font-medium">{item.duration}</span>
                  </div>
                </div>
              </div>
            </AnimatedSection>
          ))}
        </div>

        {/* Selected Image with Before/After */}
        <AnimatedSection className="max-w-4xl mx-auto">
          <div className="rounded-3xl overflow-hidden border border-border shadow-2xl bg-card p-4">
            <div className="grid grid-cols-2 gap-4 rounded-2xl overflow-hidden">
              {/* ANTES */}
              <div>
                <img
                  src={transformations[activeIndex].before}
                  alt="Antes"
                  className="w-full h-96 object-cover rounded-lg"
                  data-testid="before-after-before-image"
                />
                <p className="text-center mt-3 font-semibold text-muted-foreground uppercase tracking-wider text-sm">Antes</p>
              </div>
              
              {/* DESPUÉS */}
              <div>
                <img
                  src={transformations[activeIndex].after}
                  alt="Después"
                  className="w-full h-96 object-cover rounded-lg"
                  data-testid="before-after-after-image"
                />
                <p className="text-center mt-3 font-semibold text-primary uppercase tracking-wider text-sm">Después</p>
              </div>
            </div>
            <div className="mt-8 text-center">
              <h3 className="font-serif text-2xl md:text-3xl text-foreground mb-2">
                {transformations[activeIndex].title}
              </h3>
              <p className="text-lg text-muted-foreground mb-6">
                {transformations[activeIndex].description}
              </p>
              <div className="inline-block bg-gradient-to-r from-primary/20 to-primary/10 rounded-2xl p-6 border border-primary/30">
                <p className="text-xs text-muted-foreground mb-1 uppercase font-bold tracking-wide">
                  Tiempo de transformación
                </p>
                <p className="text-3xl font-serif font-bold text-primary">
                  {transformations[activeIndex].duration}
                </p>
              </div>
            </div>
          </div>
        </AnimatedSection>
      </div>
    </section>
  )
}
