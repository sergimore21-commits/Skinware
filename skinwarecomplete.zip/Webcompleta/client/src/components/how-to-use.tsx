import { AnimatedSection } from "@/components/animated-section"

const steps = [
  {
    step: "1",
    title: "Limpia",
    description: "Usa nuestro gel o leche limpiadora según tu tipo de piel",
  },
  {
    step: "2",
    title: "Tonifica",
    description: "Aplica un tónico para equilibrar el pH de tu piel",
  },
  {
    step: "3",
    title: "Trata",
    description: "Usa sérums activos: Vitamina C, Retinol o Ácido Hialurónico",
  },
  {
    step: "4",
    title: "Hidrata",
    description: "Aplica tu hidratante favorito para sellar la rutina",
  },
]

export function HowToUse() {
  return (
    <section className="py-20 bg-gradient-to-b from-muted/30 to-background">
      <div className="container mx-auto px-6">
        <AnimatedSection direction="up" className="text-center mb-16">
          <h2 className="font-serif text-3xl md:text-4xl text-foreground mb-4">Tu rutina paso a paso</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            El orden importa: mañana y noche, estos 4 pasos transforman tu piel
          </p>
        </AnimatedSection>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {steps.map((item, index) => (
            <AnimatedSection key={item.step} direction="up" delay={index * 100}>
              <div className="relative">
                <div className="bg-card border border-primary/20 rounded-2xl p-8 text-center hover:border-primary/50 hover:shadow-lg transition-all h-full flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-center bg-primary text-primary-foreground rounded-full w-10 h-10 font-semibold mb-4 mx-auto">
                      {item.step}
                    </div>
                    <h3 className="font-serif text-xl text-foreground mb-3">{item.title}</h3>
                    <p className="text-muted-foreground text-sm">{item.description}</p>
                  </div>
                </div>
                {index < steps.length - 1 && (
                  <div className="hidden lg:block absolute top-1/2 -right-3 w-6 h-0.5 bg-gradient-to-r from-primary to-transparent" />
                )}
              </div>
            </AnimatedSection>
          ))}
        </div>
      </div>
    </section>
  )
}
