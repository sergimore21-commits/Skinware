import { AnimatedSection } from "@/components/animated-section"
import { Sparkles, ShieldCheck, Zap, Brain } from "lucide-react"

const differentiators = [
  {
    icon: Brain,
    title: "Diagnóstico IA Científico",
    description: "Analiza tu piel con 47 parámetros de forma precisa. Sin sesgos, solo ciencia.",
    highlight: "Precisión 98.7%"
  },
  {
    icon: Sparkles,
    title: "100% Personalizado",
    description: "Cada producto se formula exclusivamente para tu tipo de piel y necesidades específicas.",
    highlight: "Tu fórmula única"
  },
  {
    icon: ShieldCheck,
    title: "Garantía 14 Días",
    description: "Si no ves resultados en 2 semanas, te devolvemos tu dinero. Sin preguntas.",
    highlight: "100% garantizado"
  },
  {
    icon: Zap,
    title: "Ingredientes Premium",
    description: "Solo activos científicamente probados. Libre de rellenos, sin parabenos ni sulfatos.",
    highlight: "Clean Beauty"
  }
]

export function WhyChooseSkinware() {
  return (
    <section className="py-20 bg-gradient-to-b from-background to-secondary/5">
      <div className="container mx-auto px-6">
        <AnimatedSection className="text-center mb-16">
          <h2 className="font-serif text-4xl md:text-5xl text-foreground mb-4">
            Por qué elegir <span className="text-primary">Skinware</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            No es solo belleza. Es ciencia aplicada a tu piel.
          </p>
        </AnimatedSection>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-7xl mx-auto">
          {differentiators.map((item, index) => {
            const Icon = item.icon
            return (
              <AnimatedSection 
                key={index} 
                direction="up" 
                delay={index * 100}
                className="group"
              >
                <div className="relative h-full bg-card rounded-2xl p-6 border border-border hover:border-primary/50 transition-all duration-300 hover:shadow-lg overflow-hidden">
                  {/* Gradient Background on Hover */}
                  <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-secondary/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  
                  {/* Content */}
                  <div className="relative z-10">
                    {/* Icon */}
                    <div className="mb-4 inline-block p-3 bg-primary/10 rounded-xl group-hover:bg-primary/20 transition-colors">
                      <Icon className="w-6 h-6 text-primary" />
                    </div>

                    {/* Title */}
                    <h3 className="font-semibold text-lg text-foreground mb-3 group-hover:text-primary transition-colors">
                      {item.title}
                    </h3>

                    {/* Description */}
                    <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
                      {item.description}
                    </p>

                    {/* Highlight Badge */}
                    <div className="inline-block px-3 py-1 bg-primary/10 text-primary text-xs font-bold rounded-full border border-primary/30">
                      ✓ {item.highlight}
                    </div>
                  </div>
                </div>
              </AnimatedSection>
            )
          })}
        </div>

        {/* Bottom CTA */}
        <AnimatedSection className="text-center mt-16">
          <p className="text-muted-foreground max-w-2xl mx-auto mb-6">
            Cada componente de Skinware está diseñado para máxima eficacia. 
            <br />
            <span className="font-semibold text-foreground">Confía en la ciencia, confía en tu piel.</span>
          </p>
        </AnimatedSection>
      </div>
    </section>
  )
}
