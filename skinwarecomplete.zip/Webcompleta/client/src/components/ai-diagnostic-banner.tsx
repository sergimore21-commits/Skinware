import { Link } from "wouter"
import { ArrowRightIcon } from "@/components/icons"
import { Zap } from "lucide-react"
import { Button } from "@/components/ui/button"
import { AnimatedSection } from "@/components/animated-section"

export function AIDiagnosticBanner() {
  return (
    <section className="py-12 bg-gradient-to-r from-primary/15 via-primary/10 to-secondary/10 border-y border-primary/20">
      <div className="container mx-auto px-6">
        <AnimatedSection direction="up" className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-start gap-4 flex-1">
            <div className="flex-shrink-0 w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center">
              <Zap className="w-6 h-6 text-primary" strokeWidth={2.5} />
            </div>
            <div>
              <h3 className="font-semibold text-lg text-foreground mb-1">
                Diagnóstico IA Personalizado
              </h3>
              <p className="text-muted-foreground text-sm">
                Descubre exactamente qué necesita tu piel. Análisis en tiempo real con inteligencia artificial.
              </p>
            </div>
          </div>
          
          <Button
            asChild
            className="rounded-full px-6 bg-primary hover:bg-primary/90 group whitespace-nowrap flex-shrink-0"
          >
            <Link href="/diagnostico">
              Iniciar Diagnóstico
              <ArrowRightIcon className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </Link>
          </Button>
        </AnimatedSection>
      </div>
    </section>
  )
}
