import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import HomePage from "@/pages/home";
import ProductsPage from "@/pages/products";
import ProductPage from "@/pages/product-details";
import BlogPage from "@/pages/blog";
import BlogPostPage from "@/pages/blog-post";
import CheckoutSuccessPage from "@/pages/checkout-success";
import ContactoPage from "@/pages/contact";
import CookiesPage from "@/pages/cookies";
import DiagnosticoPage from "@/pages/diagnostics";
import FAQPage from "@/pages/faq";
import NosotrosPage from "@/pages/about";
import PrivacidadPage from "@/pages/privacy";
import TerminosPage from "@/pages/terms";
import BeforeAfterPage from "@/pages/before-after";
import LoyaltyPage from "@/pages/loyalty";
import SubscriptionPage from "@/pages/subscription";
import IngredientsGuidePage from "@/pages/ingredients-guide";
import SustainabilityPage from "@/pages/sustainability";
import TestimonialsPage from "@/pages/testimonials";
import SkinQuizPage from "@/pages/skin-quiz";
import ComparatorPage from "@/pages/product-comparator";
import FAQCategoriesPage from "@/pages/faq-categories";
import { ThemeProvider } from "@/components/theme-provider";
import { CartProvider } from "@/components/cart-provider";
import { CartDrawer } from "@/components/cart-drawer";
import { CookieBanner } from "@/components/cookie-banner";
import { GoogleAnalytics } from "@/components/google-analytics";
import { ScrollToTop } from "@/components/scroll-to-top";

function Router() {
  return (
    <>
      <ScrollToTop />
      <Switch>
        <Route path="/" component={HomePage} />
        <Route path="/productos" component={ProductsPage} />
        <Route path="/productos/:id" component={ProductPage} />
        <Route path="/blog" component={BlogPage} />
        <Route path="/blog/:slug" component={BlogPostPage} />
        <Route path="/checkout/success" component={CheckoutSuccessPage} />
        <Route path="/contacto" component={ContactoPage} />
        <Route path="/cookies" component={CookiesPage} />
        <Route path="/diagnostico" component={DiagnosticoPage} />
        <Route path="/faq" component={FAQPage} />
        <Route path="/faq-categorias" component={FAQCategoriesPage} />
        <Route path="/nosotros" component={NosotrosPage} />
        <Route path="/privacidad" component={PrivacidadPage} />
        <Route path="/terminos" component={TerminosPage} />
        <Route path="/resultados" component={BeforeAfterPage} />
        <Route path="/fidelizacion" component={LoyaltyPage} />
        <Route path="/suscripcion" component={SubscriptionPage} />
        <Route path="/ingredientes" component={IngredientsGuidePage} />
        <Route path="/sostenibilidad" component={SustainabilityPage} />
        <Route path="/testimonios" component={TestimonialsPage} />
        <Route path="/test-piel" component={SkinQuizPage} />
        <Route path="/comparador" component={ComparatorPage} />
        <Route component={NotFound} />
      </Switch>
    </>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider attribute="class" defaultTheme="system" enableSystem disableTransitionOnChange>
        <CartProvider>
          <TooltipProvider>
            <Toaster />
            <GoogleAnalytics />
            <Router />
            <CartDrawer />
            <CookieBanner />
          </TooltipProvider>
        </CartProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
