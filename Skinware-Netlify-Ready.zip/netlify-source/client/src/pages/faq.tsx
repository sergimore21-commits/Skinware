import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { AnimatedSection } from "@/components/animated-section"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Button } from "@/components/ui/button"
import { Link } from "wouter"

const faqCategories = [
  {
    title: "Productos y Fórmulas",
    faqs: [
      {
        question: "¿Los productos Skinware son aptos para todo tipo de pieles?",
        answer:
          "Sí, en Skinware desarrollamos productos específicos para cada tipo de piel: grasa, seca, mixta, sensible y normal. Nuestro diagnóstico IA te ayuda a identificar tu tipo de piel y te recomienda los productos más adecuados para ti.",
      },
      {
        question: "¿Son veganos y cruelty-free?",
        answer:
          "Absolutamente. Todos nuestros productos son 100% veganos y nunca testamos en animales. Además, trabajamos solo con proveedores que comparten nuestros valores éticos.",
      },
      {
        question: "¿Qué significa que sean 'formulados con IA'?",
        answer:
          "Utilizamos inteligencia artificial para analizar miles de estudios científicos y optimizar nuestras fórmulas. La IA nos ayuda a encontrar las combinaciones de ingredientes más efectivas y a personalizar recomendaciones según el perfil de cada cliente.",
      },
      {
        question: "¿Cuánto duran los productos una vez abiertos?",
        answer:
          "La mayoría de nuestros productos tienen una vida útil de 12 meses después de abiertos (PAO 12M). Los sérums con vitamina C tienen 6 meses. Siempre encontrarás el símbolo PAO en el envase.",
      },
      {
        question: "¿Puedo usar varios sérums a la vez?",
        answer:
          "Sí, pero recomendamos no usar más de 2-3 sérums por rutina. Aplícalos de más ligero a más denso. Consulta nuestro blog para guías de combinación de ingredientes.",
      },
    ],
  },
  {
    title: "Pedidos y Envíos",
    faqs: [
      {
        question: "¿Cuánto cuesta el envío?",
        answer:
          "El envío estándar cuesta 4,95€ para pedidos inferiores a 40€. Para pedidos de 40€ o más, el envío es GRATIS. Enviamos a toda España peninsular, Baleares y Canarias.",
      },
      {
        question: "¿Cuánto tarda en llegar mi pedido?",
        answer:
          "Los pedidos se procesan en 24-48h laborables. El envío estándar tarda 2-4 días laborables en península, 4-6 días en Baleares y 5-7 días en Canarias.",
      },
      {
        question: "¿Puedo hacer seguimiento de mi pedido?",
        answer:
          "Sí, una vez que tu pedido sea enviado, recibirás un email con el número de seguimiento para rastrear tu paquete en tiempo real.",
      },
      {
        question: "¿Hacéis envíos internacionales?",
        answer:
          "Actualmente solo enviamos a España. Estamos trabajando para expandir nuestros envíos a Portugal y resto de la UE próximamente.",
      },
    ],
  },
  {
    title: "Devoluciones y Garantía",
    faqs: [
      {
        question: "¿Cuál es la política de devoluciones?",
        answer:
          "Tienes 30 días desde la recepción para devolver cualquier producto sin abrir en su embalaje original. Para productos abiertos, ofrecemos nuestra 'Garantía de Satisfacción' durante los primeros 14 días.",
      },
      {
        question: "¿Qué es la 'Garantía de Satisfacción'?",
        answer:
          "Si un producto no funciona para tu piel durante los primeros 14 días de uso, te lo cambiamos por otro o te devolvemos el dinero. Solo tienes que contactarnos con tu experiencia.",
      },
      {
        question: "¿Cómo inicio una devolución?",
        answer:
          "Contacta con nuestro equipo a través del formulario de contacto o envíanos un email a info@skinware.es. Te enviaremos una etiqueta de devolución prepagada.",
      },
    ],
  },
  {
    title: "Diagnóstico IA",
    faqs: [
      {
        question: "¿Cómo funciona el diagnóstico de piel con IA?",
        answer:
          "Nuestro diagnóstico utiliza un cuestionario detallado sobre tu tipo de piel, preocupaciones, estilo de vida y preferencias. La IA analiza tus respuestas y las compara con miles de perfiles para recomendarte la rutina perfecta.",
      },
      {
        question: "¿Es fiable el diagnóstico?",
        answer:
          "Nuestro algoritmo ha sido entrenado con datos de dermatólogos y miles de casos reales. Tiene una precisión del 94% en la identificación del tipo de piel. Sin embargo, siempre recomendamos consultar con un dermatólogo para condiciones específicas.",
      },
      {
        question: "¿Puedo repetir el diagnóstico?",
        answer:
          "¡Por supuesto! Tu piel cambia con las estaciones, la edad y el estilo de vida. Recomendamos hacer el diagnóstico cada 3-6 meses o cuando notes cambios en tu piel.",
      },
      {
        question: "¿El diagnóstico tiene algún coste?",
        answer:
          "No, el diagnóstico IA es completamente gratuito y sin compromiso. Puedes hacerlo tantas veces como quieras.",
      },
    ],
  },
  {
    title: "Cuenta y Pagos",
    faqs: [
      {
        question: "¿Qué métodos de pago aceptáis?",
        answer:
          "Aceptamos tarjetas de crédito/débito (Visa, Mastercard, American Express), PayPal, Apple Pay, Google Pay y Bizum.",
      },
      {
        question: "¿Es seguro comprar en vuestra web?",
        answer:
          "Sí, nuestra web utiliza encriptación SSL de 256 bits y cumplimos con todos los estándares de seguridad PCI DSS. Nunca almacenamos datos completos de tarjetas.",
      },
      {
        question: "¿Tenéis programa de fidelidad?",
        answer:
          "¡Próximamente! Estamos desarrollando un programa de puntos donde podrás acumular recompensas con cada compra. Suscríbete a nuestra newsletter para ser el primero en enterarte.",
      },
    ],
  },
]

import { useState } from "react"
import { SearchIcon } from "@/components/icons"
import { Input } from "@/components/ui/input"

export default function FAQPage() {
  const [search, setSearch] = useState("")

  const filteredCategories = faqCategories.map(cat => ({
    ...cat,
    faqs: cat.faqs.filter(faq => 
      faq.question.toLowerCase().includes(search.toLowerCase()) ||
      faq.answer.toLowerCase().includes(search.toLowerCase())
    )
  })).filter(cat => cat.faqs.length > 0)

  return (
    <>
      <Navbar />
      <main className="pt-20 min-h-screen">
        {/* Header */}
        <section className="bg-gradient-to-b from-primary/5 to-background py-16">
          <div className="container mx-auto px-6">
            <AnimatedSection direction="up" className="text-center max-w-3xl mx-auto">
              <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-foreground mb-4">Preguntas Frecuentes</h1>
              <p className="text-muted-foreground text-lg mb-6">
                Encuentra respuestas a las dudas más comunes sobre nuestros productos, envíos y el diagnóstico IA.
              </p>
              <div className="relative max-w-md mx-auto">
                <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Busca tus preguntas..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-12 h-12 rounded-full border-border"
                />
              </div>
            </AnimatedSection>
          </div>
        </section>

        {/* FAQ Content */}
        <section className="py-16">
          <div className="container mx-auto px-6 max-w-4xl">
            {search && filteredCategories.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-muted-foreground">No encontramos preguntas que coincidan con "{search}"</p>
              </div>
            ) : null}
            {(search ? filteredCategories : faqCategories).map((category, categoryIndex) => (
              <AnimatedSection key={category.title} direction="up" delay={categoryIndex * 100} className="mb-12">
                <h2 className="font-serif text-2xl text-foreground mb-6">{category.title}</h2>
                <Accordion type="single" collapsible className="space-y-3">
                  {category.faqs.map((faq, faqIndex) => (
                    <AccordionItem
                      key={faqIndex}
                      value={`${categoryIndex}-${faqIndex}`}
                      className="bg-card border border-border rounded-xl px-6 data-[state=open]:border-primary/50"
                    >
                      <AccordionTrigger className="text-left hover:no-underline py-4">
                        <span className="font-medium text-foreground">{faq.question}</span>
                      </AccordionTrigger>
                      <AccordionContent className="text-muted-foreground pb-4">{faq.answer}</AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </AnimatedSection>
            ))}

            {/* Contact CTA */}
            <AnimatedSection direction="up" className="mt-16">
              <div className="bg-primary/5 rounded-2xl p-8 text-center">
                <h3 className="font-serif text-2xl text-foreground mb-4">¿No encuentras lo que buscas?</h3>
                <p className="text-muted-foreground mb-6 max-w-md mx-auto">
                  Nuestro equipo está aquí para ayudarte. Contáctanos y te responderemos en menos de 24 horas.
                </p>
                <Button asChild size="lg" className="rounded-full px-8">
                  <Link href="/contacto">Contactar</Link>
                </Button>
              </div>
            </AnimatedSection>
          </div>
        </section>
      </main>
      <Footer />
    </>
  )
}
