import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Chatbot } from "@/components/chatbot"
import { HeroSection } from "@/components/hero-section"
import { FeaturesSection } from "@/components/features-section"
import { HowItWorksSection } from "@/components/how-it-works-section"
import { MarqueeSection } from "@/components/marquee-section"
import { TestimonialsSection } from "@/components/testimonials-section"
import { CTASection } from "@/components/cta-section"
import { StatsSection } from "@/components/stats-section"
import { IngredientsSection } from "@/components/ingredients-section"
import { FAQSection } from "@/components/faq-section"
import { ShippingGuarantees } from "@/components/shipping-guarantees"
import { IngredientsShowcase } from "@/components/ingredients-showcase"
import { HowToUse } from "@/components/how-to-use"
import { ProductRecommendations } from "@/components/product-recommendations"
import { FeaturedProducts } from "@/components/featured-products"
import { BenefitsSection } from "@/components/benefits-section"

export default function HomePage() {
  return (
    <>
      <Navbar />
      <main>
        <HeroSection />
        <FeaturedProducts />
        <BenefitsSection />
        <MarqueeSection />
        <StatsSection />
        <IngredientsShowcase />
        <HowToUse />
        <FeaturesSection />
        <HowItWorksSection />
        <ShippingGuarantees />
        <TestimonialsSection />
        <FAQSection />
        <CTASection />
      </main>
      <Footer />
      <Chatbot />
    </>
  )
}
