import { AnimatedSection } from "./animated-section"
import { ScanIcon, BrainIcon, SparklesIcon } from "@/components/icons"
import { Link } from "wouter"
import { Button } from "@/components/ui/button"

const steps = [
  {
    title: "Análisis",
    description:
      "Responde unas preguntas sobre tu piel, estilo de vida y objetivos. Nuestro sistema recopila datos clave para entenderte.",
    icon: ScanIcon,
  },
  {
    title: "Diagnóstico IA",
    description:
      "Nuestra inteligencia artificial procesa tu información y genera un perfil dermatológico único basado en ciencia de datos.",
    icon: BrainIcon,
  },
  {
    title: "Rutina Personalizada",
    description:
      "Recibe recomendaciones de productos y una rutina diseñada específicamente para las necesidades de tu piel.",
    icon: SparklesIcon,
  },
]

export function HowItWorksSection() {
  return (
    <section className="py-24 bg-muted/30">
      <div className="container mx-auto px-4">
        <AnimatedSection direction="up" className="text-center mb-16">
          <span className="text-primary font-medium tracking-widest uppercase text-sm">Proceso</span>
          <h2 className="font-serif text-4xl md:text-5xl mt-4 text-foreground">Cómo Funciona</h2>
          <p className="text-muted-foreground mt-4 max-w-2xl mx-auto">
            Tres simples pasos para descubrir la rutina perfecta para tu piel
          </p>
        </AnimatedSection>

        <div className="grid md:grid-cols-3 gap-8">
          {steps.map((step, index) => (
            <AnimatedSection key={index} delay={index * 100}>
              <div className="group bg-card p-8 rounded-2xl border border-border hover:border-primary/50 hover:shadow-xl transition-all duration-300 hover:-translate-y-1 h-full">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center mb-6 group-hover:from-primary group-hover:to-primary/80 transition-all duration-300 group-hover:scale-110">
                  <step.icon className="h-7 w-7 text-primary group-hover:text-primary-foreground transition-colors" />
                </div>
                <h3 className="font-serif text-xl mb-3 text-foreground group-hover:text-primary transition-colors">{step.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{step.description}</p>
              </div>
            </AnimatedSection>
          ))}
        </div>

        <AnimatedSection direction="up" delay={500} className="text-center mt-12">
          <Button asChild className="bg-primary text-primary-foreground px-8 py-6 rounded-full font-medium hover:bg-primary/90 transition-colors text-lg h-auto">
            <Link href="/diagnostico">Comenzar Mi Diagnóstico</Link>
          </Button>
        </AnimatedSection>
      </div>
    </section>
  )
}
