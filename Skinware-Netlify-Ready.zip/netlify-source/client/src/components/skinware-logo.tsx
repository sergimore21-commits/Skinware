import { cn } from "@/lib/utils"

interface SkinwareLogoProps {
  className?: string
}

export function SkinwareLogo({ className }: SkinwareLogoProps) {
  return (
    <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" className={cn("text-black dark:text-white", className)}>
      {/* Hexágono exterior - representa la tecnología y la ciencia */}
      <path d="M50 5L90 27.5V72.5L50 95L10 72.5V27.5L50 5Z" stroke="currentColor" strokeWidth="2" fill="none" />

      {/* Hexágono interior */}
      <path
        d="M50 20L75 35V65L50 80L25 65V35L50 20Z"
        stroke="currentColor"
        strokeWidth="1.5"
        fill="none"
        opacity="0.6"
      />

      {/* Gota central - representa el cuidado de la piel */}
      <path
        d="M50 35C50 35 38 50 38 58C38 64.627 43.373 70 50 70C56.627 70 62 64.627 62 58C62 50 50 35 50 35Z"
        fill="currentColor"
        opacity="0.9"
      />

      {/* Puntos de conexión - representan la IA y los datos */}
      <circle cx="50" cy="5" r="3" fill="currentColor" />
      <circle cx="90" cy="27.5" r="3" fill="currentColor" />
      <circle cx="90" cy="72.5" r="3" fill="currentColor" />
      <circle cx="50" cy="95" r="3" fill="currentColor" />
      <circle cx="10" cy="72.5" r="3" fill="currentColor" />
      <circle cx="10" cy="27.5" r="3" fill="currentColor" />

      {/* Líneas de conexión internas - representan algoritmos */}
      <line x1="50" y1="20" x2="50" y2="5" stroke="currentColor" strokeWidth="0.5" opacity="0.4" />
      <line x1="75" y1="35" x2="90" y2="27.5" stroke="currentColor" strokeWidth="0.5" opacity="0.4" />
      <line x1="75" y1="65" x2="90" y2="72.5" stroke="currentColor" strokeWidth="0.5" opacity="0.4" />
      <line x1="50" y1="80" x2="50" y2="95" stroke="currentColor" strokeWidth="0.5" opacity="0.4" />
      <line x1="25" y1="65" x2="10" y2="72.5" stroke="currentColor" strokeWidth="0.5" opacity="0.4" />
      <line x1="25" y1="35" x2="10" y2="27.5" stroke="currentColor" strokeWidth="0.5" opacity="0.4" />
    </svg>
  )
}
