

import { AnimatedSection } from "@/components/animated-section"

const ingredients = [
  {
    name: "Ácido Hialurónico",
    description: "Hidratación profunda y retención de humedad",
    image: "/hyaluronic-acid-ingredient.jpg",
  },
  {
    name: "Vitamina C",
    description: "Antioxidante potente para luminosidad",
    image: "/vitamin-c-ingredient.jpg",
  },
  {
    name: "Retinol",
    description: "Renovación celular y anti-edad",
    image: "/retinol-ingredient.jpg",
  },
  {
    name: "Niacinamida",
    description: "Equilibra y minimiza poros",
    image: "/niacinamide-ingredient.jpg",
  },
  {
    name: "Bakuchiol",
    description: "Alternativa natural al retinol",
    image: "/bakuchiol-ingredient.jpg",
  },
  {
    name: "Péptidos",
    description: "Firmeza y elasticidad de la piel",
    image: "/peptide-ingredient.jpg",
  },
]

export function IngredientsSection() {
  return (
    <section className="py-20">
      <div className="container mx-auto px-6">
        <AnimatedSection direction="up" className="text-center mb-12">
          <span className="inline-block px-4 py-2 rounded-full bg-secondary text-secondary-foreground text-xs font-medium tracking-wider uppercase mb-4">
            Ciencia Natural
          </span>
          <h2 className="font-serif text-3xl md:text-4xl lg:text-5xl text-foreground text-balance">
            Ingredientes de alta eficacia
          </h2>
          <p className="mt-4 text-muted-foreground max-w-2xl mx-auto">
            Seleccionamos solo los activos más potentes respaldados por ciencia, combinados en fórmulas personalizadas
            para tu tipo de piel.
          </p>
        </AnimatedSection>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
          {ingredients.map((ingredient, index) => (
            <AnimatedSection key={ingredient.name} direction="up" delay={index * 100} className="group h-full">
              <div className="bg-card rounded-2xl p-4 border border-border hover:border-primary/50 transition-all duration-300 hover:shadow-lg h-full flex flex-col">
                <div className="aspect-square rounded-xl overflow-hidden mb-2 bg-muted">
                  <img
                    src={ingredient.image || "/placeholder.svg"}
                    alt={ingredient.name}
                    loading="lazy"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <div className="flex flex-col justify-center items-center">
                  <h3 className="font-medium text-sm text-foreground text-center">{ingredient.name}</h3>
                  <p className="text-xs text-muted-foreground mt-1 text-center">{ingredient.description}</p>
                </div>
              </div>
            </AnimatedSection>
          ))}
        </div>
      </div>
    </section>
  )
}
