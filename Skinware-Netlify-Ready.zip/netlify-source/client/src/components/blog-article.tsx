

import { Link } from "wouter"
import { ArrowLeft, Clock, Calendar, Twitter, Linkedin, Facebook } from "@/components/icons"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { AnimatedSection } from "@/components/animated-section"
import vitaminCImg from "@assets/generated_images/vitamin_c_guide_blog_header.png"
import retinolImg from "@assets/generated_images/retinol_vs_bakuchiol_blog_header.png"
import oilySkinImg from "@assets/generated_images/oily_skin_routine_blog_header.png"
import minimalistImg from "@assets/generated_images/minimalist_skincare_blog_header.png"
import hyaluronicImg from "@assets/generated_images/hyaluronic_acid_myths_blog_header.png"
import niacinamideImg from "@assets/generated_images/niacinamide_skincare_benefits_header.png"
import sunscreenImg from "@assets/generated_images/winter_sunscreen_protection_blog_header.png"
import doubleCleansingImg from "@assets/generated_images/double_cleansing_routine_blog_header.png"
import mariaGarciaImg from "@assets/generated_images/dr._maría_garcía_dermatologist_headshot.png"
import carlosMartinezImg from "@assets/generated_images/dr._carlos_martínez_dermatologist_headshot.png"
import anaLopezImg from "@assets/generated_images/dra._ana_lópez_dermatologist_headshot.png"
import lauraFernandezImg from "@assets/generated_images/laura_fernández_skincare_specialist_headshot.png"

interface BlogArticleProps {
  slug: string
}

const articles: Record<string, any> = {
  "guia-completa-vitamina-c": {
    title: "Guía Completa: Todo lo que necesitas saber sobre la Vitamina C",
    excerpt: "Descubre por qué la vitamina C es el antioxidante estrella en skincare.",
    category: "ingredientes",
    image: vitaminCImg,
    readTime: 8,
    date: "2025-01-15",
    author: "Dra. María García",
    authorImage: mariaGarciaImg,
    content: `
<h2>¿Por qué la Vitamina C es tan importante?</h2>

<p>La vitamina C, también conocida como ácido ascórbico, es uno de los antioxidantes más estudiados y efectivos en el mundo del skincare. Su capacidad para neutralizar los radicales libres la convierte en un ingrediente esencial para prevenir el envejecimiento prematuro.</p>

<h3>Beneficios principales</h3>

<ul>
<li><strong>Acción antioxidante:</strong> Protege la piel del daño causado por los rayos UV y la contaminación.</li>
<li><strong>Estimula el colágeno:</strong> Esencial para mantener la firmeza y elasticidad de la piel.</li>
<li><strong>Ilumina el tono:</strong> Reduce la hiperpigmentación y las manchas oscuras.</li>
<li><strong>Efecto antiinflamatorio:</strong> Ayuda a calmar rojeces e irritaciones.</li>
</ul>

<h3>¿Qué concentración elegir?</h3>

<p>Para principiantes, recomendamos empezar con concentraciones del 10-15%. Una vez que tu piel se haya acostumbrado, puedes aumentar gradualmente hasta el 20%.</p>

<blockquote>Tip de experto: La vitamina C es más estable cuando se combina con vitamina E y ácido ferúlico. Esta combinación se conoce como la "fórmula Skinceuticals" y potencia la eficacia antioxidante.</blockquote>

<h3>Cómo incorporarla en tu rutina</h3>

<p>La vitamina C funciona mejor por la mañana, ya que potencia la protección solar. Aplícala después de limpiar y tonificar, antes de tu hidratante y SPF.</p>

<h3>Precauciones importantes</h3>

<ul>
<li>Guarda tu sérum de vitamina C en un lugar fresco y oscuro</li>
<li>Si notas que se vuelve marrón, ha oxidado y debes reemplazarlo</li>
<li>Introduce el producto gradualmente para evitar irritaciones</li>
<li>Siempre usa protector solar, ya que la vitamina C puede aumentar la fotosensibilidad</li>
</ul>
    `,
  },
  "retinol-vs-bakuchiol": {
    title: "Retinol vs Bakuchiol: ¿Cuál es mejor para ti?",
    excerpt: "Analizamos las diferencias entre estos dos activos anti-edad y te ayudamos a elegir.",
    category: "ingredientes",
    image: retinolImg,
    readTime: 6,
    date: "2025-01-12",
    author: "Dr. Carlos Martínez",
    authorImage: carlosMartinezImg,
    content: `
<h2>El debate del anti-edad: Retinol vs Bakuchiol</h2>

<p>El retinol ha sido durante décadas el gold standard del anti-envejecimiento. Sin embargo, el bakuchiol ha emergido como una alternativa natural que promete resultados similares sin los efectos secundarios. ¿Cuál deberías elegir?</p>

<h3>¿Qué es el Retinol?</h3>

<p>El retinol es una forma de vitamina A que estimula la renovación celular, aumenta la producción de colágeno y reduce las arrugas. Es altamente efectivo pero puede causar irritación, sequedad y fotosensibilidad.</p>

<h3>¿Qué es el Bakuchiol?</h3>

<p>El bakuchiol es un extracto vegetal de la planta Psoralea corylifolia. Estudios recientes demuestran que puede ofrecer beneficios similares al retinol sin causar irritación, lo que lo hace ideal para pieles sensibles.</p>

<h3>Comparativa directa</h3>

<ul>
<li><strong>Eficacia anti-arrugas:</strong> Retinol (9/10) vs Bakuchiol (7/10)</li>
<li><strong>Tolerancia:</strong> Retinol (5/10) vs Bakuchiol (9/10)</li>
<li><strong>Uso durante el embarazo:</strong> Retinol (No) vs Bakuchiol (Sí)</li>
<li><strong>Uso diurno:</strong> Retinol (No recomendado) vs Bakuchiol (Sí)</li>
</ul>

<blockquote>Nuestra recomendación: Si tienes piel sensible, estás embarazada o buscas simplicidad en tu rutina, elige bakuchiol. Si buscas máxima potencia anti-edad y tu piel tolera bien los activos, el retinol es tu mejor opción.</blockquote>

<h3>¿Puedo usar ambos?</h3>

<p>¡Sí! De hecho, algunos estudios sugieren que usar bakuchiol junto con retinol puede potenciar los resultados mientras reduce la irritación. Puedes alternar noches o usar bakuchiol de día y retinol de noche.</p>
    `,
  },
  "rutina-perfecta-piel-grasa": {
    title: "La rutina perfecta para piel grasa: paso a paso",
    excerpt: "Control de brillos, poros minimizados y una piel equilibrada.",
    category: "rutinas",
    image: oilySkinImg,
    readTime: 7,
    date: "2025-01-10",
    author: "Dra. Ana López",
    authorImage: anaLopezImg,
    content: `
<h2>Domina el brillo: Guía definitiva para pieles grasas</h2>

<p>Tener piel grasa no significa resignarse a los brillos y los poros dilatados. Con la rutina adecuada, puedes conseguir un cutis mate, equilibrado y saludable. Te explicamos cómo paso a paso.</p>

<h3>Rutina de mañana</h3>

<ol>
<li><strong>Limpieza con gel:</strong> Usa un limpiador con ácido salicílico o niacinamida para limpiar sin resecar.</li>
<li><strong>Tónico equilibrante:</strong> Con ingredientes como hamamelis o niacinamida para refinar poros.</li>
<li><strong>Sérum de niacinamida:</strong> El ingrediente estrella para controlar el sebo.</li>
<li><strong>Hidratante ligero:</strong> Sí, las pieles grasas también necesitan hidratación. Elige texturas gel o gel-crema.</li>
<li><strong>Protector solar oil-free:</strong> Esencial y no negociable. Busca acabados mate.</li>
</ol>

<h3>Rutina de noche</h3>

<ol>
<li><strong>Doble limpieza:</strong> Aceite limpiador + gel limpiador para eliminar SPF e impurezas.</li>
<li><strong>Exfoliante (2-3x/semana):</strong> BHA (ácido salicílico) para limpiar poros en profundidad.</li>
<li><strong>Sérum tratante:</strong> Retinol o ácido azelaico según tus necesidades.</li>
<li><strong>Hidratante nocturno:</strong> Puede ser el mismo que el de día o uno ligeramente más nutritivo.</li>
</ol>

<h3>Ingredientes clave para piel grasa</h3>

<ul>
<li><strong>Niacinamida:</strong> Regula el sebo y minimiza poros</li>
<li><strong>Ácido salicílico:</strong> Limpia poros y previene acné</li>
<li><strong>Zinc:</strong> Antibacteriano y seborregulador</li>
<li><strong>Ácido hialurónico:</strong> Hidratación sin grasa</li>
</ul>

<blockquote>Error común: Usar productos agresivos pensando que "secarán" la grasa. Esto solo empeora el problema al provocar que la piel produzca más sebo como mecanismo de defensa.</blockquote>
    `,
  },
  "skincare-minimalista": {
    title: "Skincare Minimalista: Menos es más",
    excerpt: "La tendencia skinimalista llega para quedarse. Descubre cómo simplificar tu rutina.",
    category: "tendencias",
    image: minimalistImg,
    readTime: 5,
    date: "2025-01-08",
    author: "Laura Fernández",
    authorImage: lauraFernandezImg,
    content: `
<h2>El auge del skinimalismo</h2>

<p>Después de años de rutinas de 10 pasos, el movimiento skinimalista propone volver a lo esencial. La premisa es simple: menos productos, mejor elegidos, para una piel más sana y una rutina más sostenible.</p>

<h3>¿Qué es el skinimalismo?</h3>

<p>El skinimalismo es una filosofía de cuidado de la piel que prioriza la calidad sobre la cantidad. En lugar de acumular productos, se trata de identificar los esenciales que realmente necesita tu piel.</p>

<h3>Los únicos productos que realmente necesitas</h3>

<ol>
<li><strong>Limpiador suave:</strong> El fundamento de cualquier rutina.</li>
<li><strong>Hidratante:</strong> Adaptado a tu tipo de piel.</li>
<li><strong>Protector solar:</strong> El anti-aging más efectivo que existe.</li>
<li><strong>Un activo (opcional):</strong> Según tu principal preocupación (vitamina C, retinol, etc.).</li>
</ol>

<h3>Beneficios del skinimalismo</h3>

<ul>
<li><strong>Menos irritación:</strong> Menos productos = menos riesgo de reacciones.</li>
<li><strong>Ahorro económico:</strong> Inviertes en menos productos pero de mejor calidad.</li>
<li><strong>Sostenibilidad:</strong> Menos envases, menos huella ecológica.</li>
<li><strong>Consistencia:</strong> Una rutina simple es más fácil de mantener.</li>
</ul>

<blockquote>El mejor skincare es el que usas consistentemente. De nada sirve tener 15 productos si solo los usas de vez en cuando.</blockquote>

<h3>Cómo hacer la transición</h3>

<p>No tienes que tirar todos tus productos de golpe. Termina lo que tienes y, cuando vayas reponiendo, pregúntate: ¿realmente lo necesito? ¿qué función cumple? ¿podría consolidar varios productos en uno?</p>
    `,
  },
  "acido-hialuronico-mitos": {
    title: "5 mitos sobre el Ácido Hialurónico desmentidos",
    excerpt: "Separamos la realidad de la ficción sobre uno de los ingredientes más populares.",
    category: "ingredientes",
    image: hyaluronicImg,
    readTime: 4,
    date: "2025-01-05",
    author: "Dra. María García",
    authorImage: mariaGarciaImg,
    content: `
<h2>La verdad sobre el ácido hialurónico</h2>

<p>El ácido hialurónico es uno de los ingredientes más populares en skincare, pero también uno de los más malinterpretados. Vamos a desmentir los mitos más comunes.</p>

<h3>Mito 1: "El ácido hialurónico hidrata la piel"</h3>

<p><strong>Realidad:</strong> Técnicamente, el ácido hialurónico no hidrata sino que retiene agua. Para que funcione correctamente, necesitas aplicarlo sobre piel húmeda y sellar con una crema. Si lo aplicas en un ambiente muy seco, puede extraer agua de las capas profundas de tu piel.</p>

<h3>Mito 2: "Cuanta más concentración, mejor"</h3>

<p><strong>Realidad:</strong> Concentraciones muy altas (más del 2%) pueden resultar pegajosas e incluso deshidratantes. Lo ideal está entre 0.1% y 2%.</p>

<h3>Mito 3: "Solo las pieles secas lo necesitan"</h3>

<p><strong>Realidad:</strong> Todas las pieles se benefician del ácido hialurónico, incluidas las grasas. No aporta grasa, solo hidratación.</p>

<h3>Mito 4: "El de bajo peso molecular es siempre mejor"</h3>

<p><strong>Realidad:</strong> Lo ideal es una combinación de varios pesos moleculares. El de alto peso hidrata la superficie, el de bajo peso penetra más profundo.</p>

<h3>Mito 5: "Es lo mismo en crema que en sérum"</h3>

<p><strong>Realidad:</strong> El formato sérum permite concentraciones más altas y mejor penetración. En cremas, el ácido hialurónico suele ser un ingrediente secundario.</p>

<blockquote>Tip de aplicación: Aplica tu sérum de ácido hialurónico sobre piel ligeramente húmeda (después de un tónico o agua termal) y sella inmediatamente con tu hidratante.</blockquote>
    `,
  },
  "protector-solar-invierno": {
    title: "¿Por qué usar protector solar en invierno?",
    excerpt: "El SPF no es solo para verano. Te explicamos por qué la protección solar es esencial todo el año.",
    category: "consejos",
    image: sunscreenImg,
    readTime: 5,
    date: "2025-01-03",
    author: "Dr. Carlos Martínez",
    authorImage: carlosMartinezImg,
    content: `
<h2>El SPF es para todo el año</h2>

<p>Muchas personas guardan el protector solar cuando llega el otoño. Gran error. Los rayos UV están presentes los 365 días del año y son la principal causa del envejecimiento prematuro de la piel.</p>

<h3>¿Por qué necesitas SPF en invierno?</h3>

<ul>
<li><strong>Los rayos UVA atraviesan las nubes:</strong> Aunque no veas el sol, el 80% de los rayos UVA llegan a tu piel.</li>
<li><strong>La nieve refleja hasta el 80% de los rayos UV:</strong> Si vas a la montaña, la exposición es aún mayor.</li>
<li><strong>Las ventanas no bloquean los UVA:</strong> Si trabajas cerca de una ventana, estás expuesto.</li>
<li><strong>El fotoenvejecimiento es acumulativo:</strong> Cada exposición sin protección suma.</li>
</ul>

<h3>Diferencias entre rayos UVA y UVB</h3>

<p>Los <strong>UVB</strong> causan quemaduras y son más intensos en verano. Los <strong>UVA</strong> penetran más profundo, causan arrugas y manchas, y están presentes todo el año con la misma intensidad.</p>

<h3>Cómo elegir tu SPF de invierno</h3>

<ul>
<li><strong>SPF 30 mínimo:</strong> Suficiente para uso urbano en invierno.</li>
<li><strong>Amplio espectro:</strong> Que proteja tanto de UVA como UVB.</li>
<li><strong>Textura confortable:</strong> En invierno puedes permitirte texturas más ricas.</li>
<li><strong>Con antioxidantes:</strong> Potencian la protección.</li>
</ul>

<blockquote>Dato importante: El 90% del envejecimiento visible de la piel está causado por la exposición solar. El protector solar es el mejor anti-aging que existe.</blockquote>
    `,
  },
  "doble-limpieza-beneficios": {
    title: "Doble limpieza: El secreto coreano para una piel perfecta",
    excerpt: "Aprende la técnica de doble limpieza que ha revolucionado las rutinas de skincare.",
    category: "rutinas",
    image: doubleCleansingImg,
    readTime: 6,
    date: "2024-12-28",
    author: "Laura Fernández",
    authorImage: lauraFernandezImg,
    content: `
<h2>¿Qué es la doble limpieza?</h2>

<p>La doble limpieza es una técnica de origen coreano que consiste en limpiar el rostro en dos pasos: primero con un limpiador a base de aceite y después con un limpiador a base de agua.</p>

<h3>¿Por qué funciona?</h3>

<p>El principio es simple: "lo similar disuelve lo similar". El aceite disuelve el maquillaje, el protector solar y el exceso de sebo. El limpiador acuoso elimina el sudor, la suciedad y los restos del primer limpiador.</p>

<h3>Paso a paso</h3>

<ol>
<li><strong>Primer limpiador (oleoso):</strong> Aplica el aceite o bálsamo sobre la piel seca. Masajea 1-2 minutos. Emulsiona con un poco de agua y retira.</li>
<li><strong>Segundo limpiador (acuoso):</strong> Aplica tu gel, espuma o leche limpiadora sobre la piel húmeda. Masajea suavemente y enjuaga.</li>
</ol>

<h3>¿Quién debería hacer doble limpieza?</h3>

<ul>
<li>Si usas maquillaje (especialmente waterproof)</li>
<li>Si usas protector solar (sobre todo los resistentes al agua)</li>
<li>Si tienes piel grasa o propensa al acné</li>
<li>Si vives en una ciudad con mucha contaminación</li>
</ul>

<h3>¿Cuándo hacerla?</h3>

<p>La doble limpieza está pensada para la noche, cuando necesitas eliminar todo lo acumulado durante el día. Por la mañana, con un solo limpiador suave es suficiente.</p>

<blockquote>Error común: Usar un aceite comedogénico o no emulsionable. Busca aceites formulados específicamente para limpieza facial que se enjuaguen fácilmente.</blockquote>
    `,
  },
  "niacinamida-beneficios": {
    title: "Niacinamida: El ingrediente multiusos que tu piel necesita",
    excerpt: "Desde control de sebo hasta luminosidad, descubre todos los beneficios de este ingrediente versátil.",
    category: "ingredientes",
    image: niacinamideImg,
    readTime: 7,
    date: "2024-12-25",
    author: "Dra. Ana López",
    authorImage: anaLopezImg,
    content: `
<h2>El todoterreno del skincare</h2>

<p>La niacinamida (vitamina B3) es uno de esos ingredientes raros que beneficia a prácticamente todos los tipos de piel. Desde controlar el sebo hasta reducir arrugas, sus aplicaciones son casi infinitas.</p>

<h3>Beneficios comprobados de la niacinamida</h3>

<ul>
<li><strong>Regula la producción de sebo:</strong> Ideal para pieles grasas.</li>
<li><strong>Minimiza poros:</strong> Los hace visiblemente más pequeños.</li>
<li><strong>Fortalece la barrera cutánea:</strong> Aumenta la producción de ceramidas.</li>
<li><strong>Reduce rojeces:</strong> Tiene propiedades antiinflamatorias.</li>
<li><strong>Ilumina el tono:</strong> Inhibe la transferencia de melanina.</li>
<li><strong>Reduce líneas finas:</strong> Estimula la producción de colágeno.</li>
</ul>

<h3>¿Qué concentración usar?</h3>

<p>La mayoría de estudios muestran beneficios con concentraciones del 2-5%. Concentraciones más altas (10%) pueden ser efectivas para sebo y poros, pero también pueden causar irritación en pieles sensibles.</p>

<h3>¿Con qué ingredientes combina bien?</h3>

<ul>
<li><strong>Ácido hialurónico:</strong> Combinación perfecta para hidratación.</li>
<li><strong>Vitamina C:</strong> Contrario al mito, se pueden usar juntos.</li>
<li><strong>Retinol:</strong> La niacinamida reduce la irritación del retinol.</li>
<li><strong>Ácidos exfoliantes:</strong> Ayuda a calmar posibles irritaciones.</li>
</ul>

<h3>¿Con qué NO combina?</h3>

<p>Realmente no hay incompatibilidades graves. El mito de que no se puede usar con vitamina C está desmentido por múltiples estudios.</p>

<blockquote>Curiosidad: La niacinamida es uno de los pocos ingredientes que funciona tanto en concentraciones bajas como altas, aunque con diferentes beneficios. Encuentra la que mejor se adapte a tu piel.</blockquote>
    `,
  },
}

const defaultArticle = {
  title: "Artículo de Skincare",
  excerpt: "Contenido sobre skincare y cuidado de la piel.",
  category: "consejos",
  image: "/skincare-article-beauty.jpg",
  readTime: 5,
  date: "2025-01-01",
  author: "Equipo Skinware",
  content: `
<h2>Introducción</h2>

<p>Este es un artículo sobre skincare y cuidado de la piel. Aquí encontrarás consejos útiles y recomendaciones de expertos.</p>

<h3>Contenido principal</h3>

<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>

<h3>Conclusión</h3>

<p>Esperamos que este artículo te haya sido útil. No olvides consultar nuestros otros artículos para más consejos de skincare.</p>
  `,
}

export function BlogArticle({ slug }: BlogArticleProps) {
  const article = articles[slug] || defaultArticle

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("es-ES", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  return (
    <article className="min-h-screen">
      {/* Hero */}
      <div className="relative h-[50vh] min-h-[400px] overflow-hidden">
        <img src={article.image || "/placeholder.svg"} alt={article.title} className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent" />
      </div>

      <div className="container mx-auto px-6 -mt-32 relative z-10">
        <AnimatedSection direction="up" className="max-w-3xl mx-auto">
          {/* Back link */}
          <Link
            href="/blog"
            className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors mb-6"
          >
            <ArrowLeft className="w-4 h-4" />
            Volver al blog
          </Link>

          {/* Header */}
          <div className="bg-card rounded-2xl border border-border p-8 mb-8">
            <div className="flex items-center gap-3 mb-4">
              <Badge variant="secondary" className="capitalize">
                {article.category}
              </Badge>
              <span className="text-sm text-muted-foreground flex items-center gap-1">
                <Clock className="w-4 h-4" />
                {article.readTime} min de lectura
              </span>
            </div>

            <h1 className="font-serif text-3xl md:text-4xl text-foreground mb-4 text-balance">{article.title}</h1>

            <p className="text-muted-foreground text-lg mb-6">{article.excerpt}</p>

            <div className="flex items-center justify-between flex-wrap gap-4">
              <div className="flex items-center gap-4">
                {article.authorImage ? (
                  <img src={article.authorImage} alt={article.author} className="w-12 h-12 rounded-full object-cover" />
                ) : (
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                    <span className="text-primary font-medium text-sm">
                      {article.author
                        .split(" ")
                        .map((n: string) => n[0])
                        .join("")}
                    </span>
                  </div>
                )}
                <div>
                  <p className="font-medium text-sm text-foreground">{article.author}</p>
                  <p className="text-xs text-muted-foreground flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    {formatDate(article.date)}
                  </p>
                </div>
              </div>

              {/* Share buttons */}
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground mr-2">Compartir:</span>
                <Button variant="ghost" size="icon" className="rounded-full h-9 w-9">
                  <Twitter className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="icon" className="rounded-full h-9 w-9">
                  <Linkedin className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="icon" className="rounded-full h-9 w-9">
                  <Facebook className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="prose prose-lg max-w-none">
            <div
              className="text-foreground [&_h2]:font-serif [&_h2]:text-2xl [&_h2]:mt-8 [&_h2]:mb-4 [&_h3]:font-medium [&_h3]:text-xl [&_h3]:mt-6 [&_h3]:mb-3 [&_p]:text-muted-foreground [&_p]:leading-relaxed [&_p]:mb-4 [&_ul]:text-muted-foreground [&_ul]:mb-4 [&_ul]:list-disc [&_ul]:pl-6 [&_ol]:text-muted-foreground [&_ol]:mb-4 [&_ol]:list-decimal [&_ol]:pl-6 [&_li]:mb-2 [&_blockquote]:border-l-4 [&_blockquote]:border-primary [&_blockquote]:pl-4 [&_blockquote]:italic [&_blockquote]:text-muted-foreground [&_blockquote]:my-6 [&_blockquote]:bg-primary/5 [&_blockquote]:py-3 [&_blockquote]:pr-4 [&_blockquote]:rounded-r-lg [&_strong]:text-foreground [&_strong]:font-medium"
              dangerouslySetInnerHTML={{ __html: article.content }}
            />
          </div>

          {/* CTA */}
          <div className="mt-12 bg-primary/5 rounded-2xl p-8 text-center">
            <h3 className="font-serif text-2xl text-foreground mb-4">
              ¿Quieres encontrar los productos perfectos para ti?
            </h3>
            <p className="text-muted-foreground mb-6">
              Nuestro diagnóstico IA analizará tu piel y te recomendará una rutina personalizada.
            </p>
            <Button asChild size="lg" className="rounded-full px-8">
              <Link href="/diagnostico">Hacer diagnóstico gratuito</Link>
            </Button>
          </div>
        </AnimatedSection>
      </div>
    </article>
  )
}
