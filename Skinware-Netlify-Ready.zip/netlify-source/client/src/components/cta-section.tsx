

import { Link } from "wouter"
import { ArrowRightIcon, SparklesIcon } from "@/components/icons"
import { Button } from "@/components/ui/button"
import { AnimatedSection } from "@/components/animated-section"

export function CTASection() {
  return (
    <section className="py-32 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/15 via-background to-secondary/15" />
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl animate-pulse" />
      <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-secondary/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: "1s" }} />

      <div className="container mx-auto px-6 relative z-10">
        <AnimatedSection direction="up" className="max-w-4xl mx-auto">
          <div className="bg-gradient-to-br from-card via-card/95 to-card border border-primary/20 rounded-3xl p-12 md:p-16 shadow-2xl">
            {/* Heading */}
            <h2 className="font-serif text-4xl md:text-5xl lg:text-6xl text-foreground mb-6 text-center text-balance">
              Tu piel merece lo mejor
            </h2>

            {/* Subheading */}
            <p className="text-muted-foreground text-lg md:text-xl mb-8 max-w-2xl mx-auto text-center text-pretty">
              Descubre tu rutina personalizada. Nuestro algoritmo IA crea fórmulas únicas basadas en tu tipo de piel, estilo de vida y objetivos.
            </p>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6 mb-10 max-w-xl mx-auto">
              <div className="group bg-card/50 p-6 rounded-2xl border border-border hover:border-primary/50 hover:shadow-lg transition-all duration-300 hover:-translate-y-1 flex flex-col items-center justify-center">
                <p className="text-lg font-bold text-primary">40%</p>
                <p className="text-xs text-muted-foreground mt-1">Menos residuos</p>
              </div>
              <div className="group bg-card/50 p-6 rounded-2xl border border-border hover:border-primary/50 hover:shadow-lg transition-all duration-300 hover:-translate-y-1 flex flex-col items-center justify-center">
                <p className="text-lg font-bold text-primary">100%</p>
                <p className="text-xs text-muted-foreground mt-1">Natural</p>
              </div>
              <div className="group bg-card/50 p-6 rounded-2xl border border-border hover:border-primary/50 hover:shadow-lg transition-all duration-300 hover:-translate-y-1 flex flex-col items-center justify-center">
                <p className="text-lg font-bold text-primary">2 min</p>
                <p className="text-xs text-muted-foreground mt-1">Diagnóstico</p>
              </div>
            </div>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
              <Button size="lg" className="group text-base px-8 py-6 bg-primary hover:bg-primary/90 text-primary-foreground" asChild>
                <Link href="/diagnostico">
                  Descubrir mi rutina
                  <ArrowRightIcon className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" className="text-base px-8 py-6" asChild>
                <Link href="/contacto">Hablar con experto</Link>
              </Button>
            </div>

            {/* Assurance */}
            <p className="text-muted-foreground/70 text-sm text-center">
              Sin compromiso • Envío gratis • Garantía de satisfacción 100%
            </p>
          </div>
        </AnimatedSection>
      </div>
    </section>
  )
}
