
import { useCart } from "@/components/cart-provider"
import { Button } from "@/components/ui/button"
import { XIcon, Minus, Plus, ShoppingBagIcon, Truck, Heart } from "@/components/icons"
import { cn } from "@/lib/utils"
import { Link } from "wouter"
import { useState, useEffect } from "react"
import { toast } from "sonner"

export function CartDrawer() {
  const { items, isOpen, setIsOpen, removeItem, updateQuantity, totalItems, totalPrice, clearCart } = useCart()
  const [isCheckingOut, setIsCheckingOut] = useState(false)
  const [tab, setTab] = useState<"cart" | "wishlist">("cart")
  const [wishlist, setWishlist] = useState<any[]>([])

  useEffect(() => {
    const saved = localStorage.getItem("skinware-wishlist")
    if (saved) {
      setWishlist(JSON.parse(saved))
    }
  }, [isOpen])

  const removeFromWishlist = (productId: string) => {
    const updated = wishlist.filter(p => p.id !== productId)
    setWishlist(updated)
    localStorage.setItem("skinware-wishlist", JSON.stringify(updated))
  }

  const addToCart = (product: any) => {
    items.push(product)
    toast.success("Producto agregado al carrito")
  }

  const shippingThreshold = 40
  const remainingForFreeShipping = Math.max(0, shippingThreshold - totalPrice)
  const hasFreeShipping = totalPrice >= shippingThreshold

  const handleCheckout = async () => {
    setIsCheckingOut(true)

    // Simulate checkout process
    try {
      await new Promise((resolve) => setTimeout(resolve, 1500))
      toast.success("¡Compra realizada con éxito!", {
        description: "Redirigiendo...",
      })
      setIsOpen(false)
      clearCart()
      window.location.href = "/checkout/success"
    } catch (error) {
      console.error("Checkout error:", error)
      toast.error("Error al procesar el pago", {
        description: "Por favor, inténtalo de nuevo.",
      })
    } finally {
      setIsCheckingOut(false)
    }
  }

  return (
    <>
      {/* Overlay */}
      <div
        className={cn(
          "fixed inset-0 bg-foreground/20 backdrop-blur-sm z-50 transition-opacity duration-300",
          isOpen ? "opacity-100" : "opacity-0 pointer-events-none",
        )}
        onClick={() => setIsOpen(false)}
      />

      {/* Drawer */}
      <div
        className={cn(
          "fixed top-0 right-0 h-full w-full max-w-md bg-background border-l border-border z-50 shadow-2xl transition-transform duration-300 flex flex-col",
          isOpen ? "translate-x-0" : "translate-x-full",
        )}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border">
          <div className="flex items-center gap-3">
            {tab === "cart" ? (
              <>
                <ShoppingBagIcon className="w-5 h-5 text-primary" />
                <h2 className="font-serif text-xl text-foreground">Tu carrito</h2>
                {totalItems > 0 && (
                  <span className="bg-primary text-primary-foreground text-xs px-2 py-0.5 rounded-full">{totalItems}</span>
                )}
              </>
            ) : (
              <>
                <Heart className="w-5 h-5 text-primary" />
                <h2 className="font-serif text-xl text-foreground">Favoritos</h2>
                {wishlist.length > 0 && (
                  <span className="bg-primary text-primary-foreground text-xs px-2 py-0.5 rounded-full">{wishlist.length}</span>
                )}
              </>
            )}
          </div>
          <button onClick={() => setIsOpen(false)} className="p-2 hover:bg-muted rounded-full transition-colors">
            <XIcon className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-4 px-6 py-3 border-b border-border bg-muted/30">
          <button
            onClick={() => setTab("cart")}
            className={cn("text-sm font-medium pb-2 px-2 border-b-2 transition-colors", 
              tab === "cart" ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"
            )}
          >
            Carrito ({totalItems})
          </button>
          <button
            onClick={() => setTab("wishlist")}
            className={cn("text-sm font-medium pb-2 px-2 border-b-2 transition-colors",
              tab === "wishlist" ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"
            )}
          >
            Favoritos ({wishlist.length})
          </button>
        </div>

        {/* Free Shipping Progress */}
        {totalItems > 0 && (
          <div className="px-6 py-4 bg-muted/50 border-b border-border">
            {hasFreeShipping ? (
              <div className="flex items-center gap-2 text-primary">
                <Truck className="w-4 h-4" />
                <span className="text-sm font-medium">Envío gratis incluido</span>
              </div>
            ) : (
              <div>
                <div className="flex items-center justify-between text-sm mb-2">
                  <span className="text-muted-foreground">
                    Añade {remainingForFreeShipping.toFixed(2)}€ más para envío gratis
                  </span>
                  <Truck className="w-4 h-4 text-muted-foreground" />
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full bg-primary rounded-full transition-all duration-500"
                    style={{ width: `${(totalPrice / shippingThreshold) * 100}%` }}
                  />
                </div>
              </div>
            )}
          </div>
        )}

        {/* Cart/Wishlist Items */}
        <div className="flex-1 overflow-y-auto p-6">
          {tab === "cart" ? (
            <>
              {items.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-center">
                  <ShoppingBagIcon className="w-16 h-16 text-muted-foreground/30 mb-4" />
                  <h3 className="font-medium text-foreground mb-2">Tu carrito está vacío</h3>
                  <p className="text-sm text-muted-foreground mb-6">
                    Descubre nuestros productos y empieza tu rutina de skincare
                  </p>
                  <Button asChild className="rounded-full" onClick={() => setIsOpen(false)}>
                    <Link href="/productos">Ver productos</Link>
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  {items.map((item) => (
                    <div key={item.id} className="flex gap-4 bg-card border border-border rounded-xl p-4">
                      <div className="w-20 h-20 rounded-lg overflow-hidden bg-muted flex-shrink-0">
                        <img
                          src={item.image || "/placeholder.svg"}
                          alt={item.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium text-foreground text-sm line-clamp-2 mb-1">{item.name}</h4>
                        <p className="text-primary font-medium">{item.price}€</p>
                        <div className="flex items-center justify-between mt-2">
                          <div className="flex items-center border border-border rounded-full">
                            <button
                              onClick={() => updateQuantity(item.id, item.quantity - 1)}
                              className="p-1.5 hover:bg-muted transition-colors rounded-l-full"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="w-8 text-center text-sm">{item.quantity}</span>
                            <button
                              onClick={() => updateQuantity(item.id, item.quantity + 1)}
                              className="p-1.5 hover:bg-muted transition-colors rounded-r-full"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>
                          <button
                            onClick={() => removeItem(item.id)}
                            className="text-xs text-muted-foreground hover:text-destructive transition-colors"
                          >
                            Eliminar
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </>
          ) : (
            <>
              {wishlist.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-center">
                  <Heart className="w-16 h-16 text-muted-foreground/30 mb-4" />
                  <h3 className="font-medium text-foreground mb-2">No tienes favoritos aún</h3>
                  <p className="text-sm text-muted-foreground mb-6">
                    Agrega productos a tu lista de favoritos
                  </p>
                  <Button asChild className="rounded-full" onClick={() => setIsOpen(false)}>
                    <Link href="/productos">Ver productos</Link>
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  {wishlist.map((item) => (
                    <div key={item.id} className="flex gap-4 bg-card border border-border rounded-xl p-4">
                      <div className="w-20 h-20 rounded-lg overflow-hidden bg-muted flex-shrink-0">
                        <img
                          src={item.image || "/placeholder.svg"}
                          alt={item.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium text-foreground text-sm line-clamp-2 mb-1">{item.name}</h4>
                        <p className="text-primary font-medium">{item.price}€</p>
                        <div className="flex items-center justify-between mt-2">
                          <Button size="sm" className="rounded-full text-xs bg-primary text-primary-foreground hover:bg-primary/90" onClick={() => addToCart(item)}>
                            Comprar
                          </Button>
                          <button
                            onClick={() => removeFromWishlist(item.id)}
                            className="text-xs text-muted-foreground hover:text-destructive transition-colors"
                          >
                            Eliminar
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer */}
        {tab === "cart" && items.length > 0 && (
          <div className="border-t border-border p-6 space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Subtotal</span>
                <span className="text-foreground">{totalPrice.toFixed(2)}€</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Envío</span>
                <span className="text-foreground">
                  {hasFreeShipping ? <span className="text-primary">Gratis</span> : "4,95€"}
                </span>
              </div>
              <div className="flex justify-between font-medium text-lg pt-2 border-t border-border">
                <span className="text-foreground">Total</span>
                <span className="text-foreground">{(totalPrice + (hasFreeShipping ? 0 : 4.95)).toFixed(2)}€</span>
              </div>
            </div>

            <Button className="w-full rounded-full h-12" onClick={handleCheckout} disabled={isCheckingOut}>
              {isCheckingOut ? "Procesando..." : "Finalizar compra"}
            </Button>

            <button
              onClick={clearCart}
              className="w-full text-sm text-muted-foreground hover:text-foreground transition-colors"
            >
              Vaciar carrito
            </button>
          </div>
        )}
      </div>
    </>
  )
}
