

import type React from "react"

import { useState } from "react"
import { Link } from "wouter"
import { InstagramIcon, LinkedinIcon, TwitterIcon, ArrowRightIcon, CheckIcon } from "@/components/icons"
import { Button } from "@/components/ui/button"
import { SkinwareLogo } from "@/components/skinware-logo"

export function Footer() {
  const [email, setEmail] = useState("")
  const [subscribed, setSubscribed] = useState(false)
  const [loading, setLoading] = useState(false)

  const validateEmail = (email: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!email || !validateEmail(email)) return

    setLoading(true)
    await new Promise((resolve) => setTimeout(resolve, 1000))
    setSubscribed(true)
    setLoading(false)
    setEmail("")
  }

  return (
    <footer className="bg-muted/50 border-t border-border dark:bg-card">
      <div className="border-b border-border">
        <div className="container mx-auto px-6 py-12">
          <div className="max-w-2xl mx-auto text-center">
            <h3 className="font-serif text-3xl text-foreground mb-6">Únete a la revolución del skincare</h3>
            <p className="text-muted-foreground mb-6">
              Sé la primera en recibir consejos personalizados, fórmulas exclusivas, avances en IA y un <span className="font-bold text-primary">15% de descuento</span> en tu primer pedido.
            </p>

            {subscribed ? (
              <div className="flex items-center justify-center gap-2 text-primary">
                <CheckIcon className="w-5 h-5" />
                <span className="font-medium">¡Gracias por suscribirte!</span>
              </div>
            ) : (
              <>
                <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto items-center justify-center">
                  <input
                    type="email"
                    placeholder="tu@email.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="flex-1 px-4 py-3 rounded-full border border-border bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                    data-testid="newsletter-email"
                  />
                  <Button type="submit" className="rounded-full px-6 bg-primary hover:bg-primary/90" disabled={loading} data-testid="newsletter-subscribe">
                    {loading ? "Enviando..." : "Desbloquear 15%"}
                    <ArrowRightIcon className="w-4 h-4 ml-2" />
                  </Button>
                </form>
                <p className="text-xs text-muted-foreground mt-3">Sin spam. Puedes darte de baja en cualquier momento.</p>
              </>
            )}
          </div>
        </div>
      </div>

      <div className="container mx-auto px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-2">
            <Link href="/" className="inline-flex items-center gap-3">
              <SkinwareLogo className="w-10 h-10" />
              <span className="font-serif text-2xl tracking-wide text-foreground">Skinware</span>
            </Link>
            <p className="mt-4 text-sm text-muted-foreground max-w-md dark:text-opacity-100">
              Reescribiendo el código de la belleza. Fusionamos la cosmética de lujo con la ciencia de datos para
              ofrecerte productos personalizados que tu piel necesita.
            </p>
            <div className="flex gap-4 mt-6">
              <a
                href="#"
                className="p-2 rounded-full bg-accent hover:bg-primary hover:text-primary-foreground transition-colors"
                aria-label="Instagram"
              >
                <InstagramIcon className="h-5 w-5" />
              </a>
              <a
                href="#"
                className="p-2 rounded-full bg-accent hover:bg-primary hover:text-primary-foreground transition-colors"
                aria-label="LinkedIn"
              >
                <LinkedinIcon className="h-5 w-5" />
              </a>
              <a
                href="#"
                className="p-2 rounded-full bg-accent hover:bg-primary hover:text-primary-foreground transition-colors"
                aria-label="Twitter"
              >
                <TwitterIcon className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Navegación */}
          <div>
            <h4 className="font-serif text-lg mb-4 text-foreground">Navegación</h4>
            <ul className="space-y-3">
              <li>
                <Link href="/" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Inicio
                </Link>
              </li>
              <li>
                <Link href="/productos" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Productos
                </Link>
              </li>
              <li>
                <Link
                  href="/diagnostico"
                  className="text-sm text-muted-foreground hover:text-primary transition-colors"
                >
                  Diagnóstico IA
                </Link>
              </li>
              <li>
                <Link href="/test-piel" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Test de Piel
                </Link>
              </li>
              <li>
                <Link href="/fidelizacion" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Programa VIP
                </Link>
              </li>
              <li>
                <Link href="/blog" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Blog
                </Link>
              </li>
              <li>
                <Link href="/nosotros" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Quiénes Somos
                </Link>
              </li>
              <li>
                <Link href="/testimonios" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Testimonios
                </Link>
              </li>
              <li>
                <Link href="/faq" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Preguntas Frecuentes
                </Link>
              </li>
              <li>
                <Link href="/contacto" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Contacto
                </Link>
              </li>
            </ul>
          </div>

          {/* Recursos */}
          <div>
            <h4 className="font-serif text-lg mb-4 text-foreground">Recursos</h4>
            <ul className="space-y-3">
              <li>
                <Link href="/resultados" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Resultados Reales
                </Link>
              </li>
              <li>
                <Link href="/testimonios" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Testimonios
                </Link>
              </li>
              <li>
                <Link href="/ingredientes" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Guía de Ingredientes
                </Link>
              </li>
              <li>
                <Link href="/sostenibilidad" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Sostenibilidad
                </Link>
              </li>
              <li>
                <Link href="/faq-categorias" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  FAQ por Categoría
                </Link>
              </li>
            </ul>
          </div>

          {/* Contacto */}
          <div>
            <h4 className="font-serif text-lg mb-4 text-foreground">Contacto</h4>
            <ul className="space-y-3">
              <li className="text-sm text-muted-foreground">Tarragona, España</li>
              <li>
                <a
                  href="mailto:info@skinware.es"
                  className="text-sm text-muted-foreground hover:text-primary transition-colors"
                >
                  info@skinware.es
                </a>
              </li>
              <li>
                <a
                  href="tel:+34977258430"
                  className="text-sm text-muted-foreground hover:text-primary transition-colors"
                >
                  +34 977 258 430
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Derechos reservados */}
        <div className="mt-12 pt-8 border-t border-border flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-xs text-muted-foreground">
            © {new Date().getFullYear()} Skinware. Todos los derechos reservados.
          </p>
          <div className="flex gap-6">
            <Link href="/privacidad" className="text-xs text-muted-foreground hover:text-primary transition-colors">
              Política de Privacidad
            </Link>
            <Link href="/terminos" className="text-xs text-muted-foreground hover:text-primary transition-colors">
              Términos de Uso
            </Link>
            <Link href="/cookies" className="text-xs text-muted-foreground hover:text-primary transition-colors">
              Cookies
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
