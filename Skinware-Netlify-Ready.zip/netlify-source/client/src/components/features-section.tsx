import { AnimatedSection } from "@/components/animated-section"
import { SparklesIcon, DatabaseIcon, HeartIcon, LeafIcon } from "@/components/icons"

const features = [
  {
    icon: SparklesIcon,
    title: "Tecnología IA",
    description: "Algoritmos avanzados que analizan tu piel para crear fórmulas únicas.",
  },
  {
    icon: DatabaseIcon,
    title: "Ciencia de Datos",
    description: "Investigación basada en miles de análisis dermatológicos.",
  },
  {
    icon: LeafIcon,
    title: "Clean Beauty",
    description: "Ingredientes naturales y sostenibles de la más alta calidad.",
  },
  {
    icon: HeartIcon,
    title: "Personalización",
    description: "Cada producto adaptado a las necesidades únicas de tu piel.",
  },
]

export function FeaturesSection() {
  return (
    <section className="py-24 bg-muted">
      <div className="container mx-auto px-6">
        <AnimatedSection className="text-center mb-16">
          <span className="inline-block px-4 py-2 rounded-full bg-secondary text-secondary-foreground text-xs font-medium tracking-wider uppercase mb-4">
            Nuestra Filosofía
          </span>
          <h2 className="font-serif text-3xl md:text-4xl lg:text-5xl text-foreground text-balance">
            Donde la ciencia encuentra la belleza
          </h2>
        </AnimatedSection>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => {
            const icons = ["⬡", "⊞", "◇", "✧"]
            return (
              <AnimatedSection key={index} delay={index * 100}>
                <div className="group bg-card p-8 rounded-2xl border border-border hover:border-primary/50 hover:shadow-xl transition-all duration-300 hover:-translate-y-1 h-full">
                  <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center mb-6 group-hover:from-primary group-hover:to-primary/80 transition-all duration-300 group-hover:scale-110">
                    <span className="text-2xl font-bold text-primary group-hover:text-primary-foreground transition-colors">{icons[index]}</span>
                  </div>
                  <h3 className="font-serif text-xl mb-3 text-foreground group-hover:text-primary transition-colors">{feature.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{feature.description}</p>
                </div>
              </AnimatedSection>
            )
          })}
        </div>
      </div>
    </section>
  )
}
