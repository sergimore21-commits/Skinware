

import { useCart } from "@/components/cart-provider"
import { ShoppingBagIcon } from "@/components/icons"
import { Button } from "@/components/ui/button"

export function CartButton() {
  const { totalItems, setIsOpen } = useCart()

  return (
    <Button
      variant="ghost"
      size="icon"
      className="rounded-full w-9 h-9 relative"
      onClick={() => setIsOpen(true)}
      aria-label="Abrir carrito"
    >
      <ShoppingBagIcon className="w-4 h-4" />
      {totalItems > 0 && (
        <span className="absolute -top-1 -right-1 bg-primary text-primary-foreground text-xs w-5 h-5 rounded-full flex items-center justify-center font-medium">
          {totalItems > 9 ? "9+" : totalItems}
        </span>
      )}
    </Button>
  )
}
