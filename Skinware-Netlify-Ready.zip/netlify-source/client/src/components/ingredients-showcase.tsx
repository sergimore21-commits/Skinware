import { AnimatedSection } from "@/components/animated-section"
import niacinamideImg from "@assets/generated_images/niacinamide_powder_crystals.png"
import hyaluronicImg from "@assets/generated_images/hyaluronic_acid_water_droplets.png"
import vitaminCImg from "@assets/generated_images/vitamin_c_powder_ingredient.png"
import retinolImg from "@assets/generated_images/retinol_serum_in_bottle.png"

const ingredients = [
  {
    name: "Niacinamida",
    benefit: "Regula sebo",
    description: "Reduce poros y controla la producción de aceite natural",
    image: niacinamideImg,
  },
  {
    name: "Ácido Hialurónico",
    benefit: "Hidratación",
    description: "Retiene 1000x su peso en agua para piel jugosa",
    image: hyaluronicImg,
  },
  {
    name: "Vitamina C",
    benefit: "Luminosidad",
    description: "Antioxidante potente que ilumina e iguala el tono",
    image: vitaminCImg,
  },
  {
    name: "Retinol",
    benefit: "Rejuvenecimiento",
    description: "Acelera renovación celular y reduce líneas finas",
    image: retinolImg,
  },
]

export function IngredientsShowcase() {
  return (
    <section className="py-16 bg-gradient-to-b from-background to-muted/30">
      <div className="container mx-auto px-6">
        <AnimatedSection direction="up" className="text-center mb-12">
          <h2 className="font-serif text-3xl md:text-4xl text-foreground mb-4">Ingredientes que funcionan</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Cada fórmula está diseñada con ingredientes científicamente probados para resultados reales
          </p>
        </AnimatedSection>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 auto-rows-fr">
          {ingredients.map((ingredient, index) => (
            <AnimatedSection key={ingredient.name} direction="up" delay={index * 100}>
              <div className="group bg-card border border-border rounded-2xl p-6 hover:border-primary/50 hover:shadow-lg transition-all duration-300 cursor-pointer overflow-hidden h-full flex flex-col">
                <div className="w-full h-40 mb-4 rounded-lg overflow-hidden bg-muted flex items-center justify-center group-hover:scale-105 transition-transform duration-300 flex-shrink-0">
                  <img 
                    src={ingredient.image} 
                    alt={ingredient.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <h3 className="font-serif text-xl text-foreground mb-1 group-hover:text-primary transition-colors flex-shrink-0">
                  {ingredient.name}
                </h3>
                <p className="text-primary font-semibold text-sm mb-3 flex-shrink-0">{ingredient.benefit}</p>
                <p className="text-muted-foreground text-sm leading-relaxed flex-grow">{ingredient.description}</p>
              </div>
            </AnimatedSection>
          ))}
        </div>
      </div>
    </section>
  )
}
