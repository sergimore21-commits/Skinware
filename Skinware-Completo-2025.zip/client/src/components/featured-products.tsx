import { AnimatedSection } from "@/components/animated-section"
import { StarIcon, ShoppingBagIcon } from "@/components/icons"
import { Badge } from "@/components/ui/badge"
import { Link } from "wouter"
import gelLimpiadorImg from "@assets/generated_images/skinware_gel_limpiador_purificante_bottle.png"
import serumVitaminaCImg from "@assets/generated_images/skinware_sérum_vitamina_c_bottle.png"
import serumHialuronicoImg from "@assets/generated_images/skinware_sérum_ácido_hialurónico_bottle.png"

const featuredProducts = [
  {
    id: "1",
    name: "Skinware Gel Limpiador Purificante",
    price: 26,
    rating: 4.8,
    reviews: 124,
    image: gelLimpiadorImg,
    badge: "Bestseller",
    description: "Limpieza profunda que elimina impurezas sin resecar.",
  },
  {
    id: "3",
    name: "Skinware Sérum Vitamina C 15%",
    price: 54,
    rating: 4.9,
    reviews: 256,
    image: serumVitaminaCImg,
    badge: "Favorito",
    description: "Antioxidante potente para luminosidad.",
  },
  {
    id: "4",
    name: "Skinware Sérum Ácido Hialurónico",
    price: 45,
    rating: 4.7,
    reviews: 189,
    image: serumHialuronicoImg,
    description: "Hidratación profunda multinivel.",
  },
]

export function FeaturedProducts() {
  return (
    <section className="py-20">
      <div className="container mx-auto px-6">
        <AnimatedSection className="text-center mb-16">
          <span className="inline-block px-4 py-2 rounded-full bg-secondary text-secondary-foreground text-xs font-medium tracking-wider uppercase mb-4">
            Bestsellers
          </span>
          <h2 className="font-serif text-3xl md:text-4xl text-foreground mb-4 text-balance">
            Nuestros productos más amados
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Los favoritos de nuestros clientes. Fórmulas personalizadas que transforman la piel.
          </p>
        </AnimatedSection>

        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {featuredProducts.map((product, index) => (
            <AnimatedSection key={product.id} delay={index * 100}>
              <Link href={`/productos/${product.id}`}>
                <div className="group bg-card border border-border rounded-2xl overflow-hidden hover:shadow-xl transition-all duration-300 cursor-pointer h-full flex flex-col">
                  {/* Product Image */}
                  <div className="aspect-square overflow-hidden bg-muted relative">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-contain p-4 group-hover:scale-110 transition-transform duration-500"
                    />
                    {product.badge && (
                      <div className="absolute top-3 right-3">
                        <Badge className="bg-primary text-primary-foreground">{product.badge}</Badge>
                      </div>
                    )}
                  </div>

                  {/* Product Info */}
                  <div className="p-6 flex flex-col flex-grow">
                    <h3 className="font-serif text-lg text-foreground mb-2 group-hover:text-primary transition-colors line-clamp-2">
                      {product.name}
                    </h3>
                    <p className="text-sm text-muted-foreground mb-4 flex-grow">{product.description}</p>

                    {/* Rating */}
                    <div className="flex items-center gap-2 mb-4">
                      <div className="flex gap-0.5">
                        {[...Array(5)].map((_, i) => (
                          <StarIcon
                            key={i}
                            className={`w-4 h-4 ${i < Math.floor(product.rating) ? "fill-primary text-primary" : "text-muted-foreground"}`}
                          />
                        ))}
                      </div>
                      <span className="text-xs text-muted-foreground">({product.reviews})</span>
                    </div>

                    {/* Price and CTA */}
                    <div className="flex items-center justify-between pt-4 border-t border-border">
                      <p className="font-serif text-xl text-primary font-bold">{product.price}€</p>
                      <button className="p-2 rounded-full bg-primary/10 text-primary hover:bg-primary hover:text-primary-foreground transition-colors">
                        <ShoppingBagIcon className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              </Link>
            </AnimatedSection>
          ))}
        </div>

        <AnimatedSection delay={300} className="text-center mt-12">
          <Link href="/productos">
            <button className="px-8 py-3 border border-primary text-primary rounded-full hover:bg-primary hover:text-primary-foreground transition-colors font-medium">
              Ver todos los productos
            </button>
          </Link>
        </AnimatedSection>
      </div>
    </section>
  )
}
