
import { useState, useEffect } from "react"
import { AnimatedSection } from "@/components/animated-section"
import { StarIcon, ChevronLeftIcon, ChevronRightIcon } from "@/components/icons"

const testimonials = [
  {
    name: "María García",
    role: "Empresaria",
    image: "/professional-woman-portrait.jpg",
    rating: 5,
    text: "Skinware ha revolucionado mi rutina de skincare. El diagnóstico con IA fue increíblemente preciso y los productos recomendados han transformado mi piel en solo 8 semanas.",
  },
  {
    name: "Carlos Mendez",
    role: "Director Creativo",
    image: "/professional-man-portrait.jpg",
    rating: 5,
    text: "Como escéptico de la tecnología en belleza, Skinware me sorprendió. La combinación de ciencia de datos y clean beauty es exactamente lo que el mercado necesitaba.",
  },
  {
    name: "Laura Fernández",
    role: "Dermatóloga",
    image: "/female-doctor-portrait.jpg",
    rating: 5,
    text: "Recomiendo Skinware a mis pacientes. Su enfoque basado en datos complementa perfectamente el tratamiento dermatológico tradicional. Innovación real.",
  },
  {
    name: "Andrea Ruiz",
    role: "Influencer de Belleza",
    image: "/young-woman-influencer-portrait.jpg",
    rating: 5,
    text: "He probado cientos de marcas y Skinware destaca por su transparencia y efectividad. La personalización basada en IA es un game changer absoluto.",
  },
]

export function TestimonialsSection() {
  const [currentSlide, setCurrentSlide] = useState(0)
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768)

  useEffect(() => {
    const handleResize = () => setIsMobile(window.innerWidth < 768)
    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [])

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % testimonials.length)
  }

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + testimonials.length) % testimonials.length)
  }

  return (
    <section className="py-24 bg-muted/30">
      <div className="container mx-auto px-4">
        <AnimatedSection direction="up" className="text-center mb-16">
          <span className="text-primary font-medium tracking-widest text-sm uppercase">Testimonios</span>
          <h2 className="font-serif text-4xl md:text-5xl text-foreground mt-3 mb-4">Lo que dicen nuestros clientes</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            Historias reales de personas que han transformado su piel con nuestra tecnología
          </p>
        </AnimatedSection>

        {isMobile ? (
          <div className="max-w-md mx-auto relative">
            <div className="overflow-hidden rounded-2xl">
              <div className="flex transition-transform duration-500" style={{ transform: `translateX(-${currentSlide * 100}%)` }}>
                {testimonials.map((testimonial) => (
                  <div key={testimonial.name} className="min-w-full">
                    <div className="bg-card p-8 rounded-2xl border border-border h-full flex flex-col">
                      <div className="flex gap-1 mb-4">
                        {[...Array(testimonial.rating)].map((_, i) => (
                          <StarIcon key={i} className="w-5 h-5 fill-primary text-primary" />
                        ))}
                      </div>
                      <p className="text-foreground/80 leading-relaxed mb-6 flex-grow italic">&quot;{testimonial.text}&quot;</p>
                      <div className="flex items-center gap-4 pt-4 border-t border-border">
                        <img
                          src={testimonial.image || "/placeholder.svg"}
                          alt={testimonial.name}
                          className="w-12 h-12 rounded-full object-cover"
                        />
                        <div>
                          <p className="font-medium text-foreground">{testimonial.name}</p>
                          <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <button onClick={prevSlide} className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-12 p-2 rounded-full bg-primary/10 hover:bg-primary hover:text-white transition-all">
              <ChevronLeftIcon className="w-6 h-6" />
            </button>
            <button onClick={nextSlide} className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-12 p-2 rounded-full bg-primary/10 hover:bg-primary hover:text-white transition-all">
              <ChevronRightIcon className="w-6 h-6" />
            </button>
            <div className="flex justify-center gap-2 mt-6">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentSlide(index)}
                  className={`w-2 h-2 rounded-full transition-all ${index === currentSlide ? "bg-primary w-6" : "bg-muted"}`}
                />
              ))}
            </div>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 gap-6 max-w-5xl mx-auto">
            {testimonials.map((testimonial, index) => (
              <AnimatedSection key={testimonial.name} direction={index % 2 === 0 ? "left" : "right"} delay={index * 100} className="group">
                <div className="bg-card p-8 rounded-2xl border border-border hover:border-primary/50 hover:shadow-xl transition-all duration-300 h-full flex flex-col hover:-translate-y-1">
                  <div className="flex gap-1 mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <StarIcon key={i} className="w-5 h-5 fill-primary text-primary" />
                    ))}
                  </div>
                  <p className="text-foreground/80 leading-relaxed mb-6 flex-grow italic">&quot;{testimonial.text}&quot;</p>
                  <div className="flex items-center gap-4 pt-4 border-t border-border">
                    <img
                      src={testimonial.image || "/placeholder.svg"}
                      alt={testimonial.name}
                      className="w-12 h-12 rounded-full object-cover group-hover:ring-2 ring-primary transition-all"
                    />
                    <div>
                      <p className="font-medium text-foreground">{testimonial.name}</p>
                      <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                    </div>
                  </div>
                </div>
              </AnimatedSection>
            ))}
          </div>
        )}
      </div>
    </section>
  )
}
