

import { AnimatedSection } from "@/components/animated-section"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

const faqs = [
  {
    question: "¿Cómo funciona el diagnóstico de piel con IA?",
    answer:
      "Nuestro sistema de IA analiza las respuestas de un cuestionario detallado sobre tu tipo de piel, estilo de vida, preocupaciones específicas y objetivos. Con estos datos, genera recomendaciones personalizadas de productos y rutinas adaptadas a tus necesidades únicas.",
  },
  {
    question: "¿Los productos son aptos para pieles sensibles?",
    answer:
      "Sí, todos nuestros productos están dermatológicamente testados y formulados para ser suaves. Además, nuestro diagnóstico IA tiene en cuenta la sensibilidad de tu piel para recomendarte productos específicos que no causen irritación.",
  },
  {
    question: "¿Cuánto tiempo tarda en verse resultados?",
    answer:
      "Los primeros resultados visibles suelen aparecer entre 2 y 4 semanas de uso constante. Para resultados óptimos en textura, tono y líneas finas, recomendamos un uso mínimo de 8-12 semanas siguiendo la rutina personalizada.",
  },
  {
    question: "¿Los ingredientes son naturales y sostenibles?",
    answer:
      "Combinamos lo mejor de la naturaleza con la ciencia. Utilizamos ingredientes naturales de alta eficacia junto con activos biotecnológicos seguros. Todos nuestros envases son reciclables y estamos comprometidos con prácticas de producción sostenibles.",
  },
  {
    question: "¿Puedo cambiar mi rutina personalizada?",
    answer:
      "Por supuesto. Tu piel cambia con las estaciones, el estrés y otros factores. Puedes realizar el diagnóstico IA en cualquier momento para actualizar tu rutina. También ofrecemos seguimiento personalizado con nuestros expertos.",
  },
  {
    question: "¿Hacen envíos internacionales?",
    answer:
      "Actualmente realizamos envíos a toda España y Portugal. Estamos trabajando para expandir nuestro alcance a más países de Europa. Suscríbete a nuestra newsletter para ser el primero en enterarte de las novedades.",
  },
]

export function FAQSection() {
  return (
    <section className="py-20 bg-muted/30">
      <div className="container mx-auto px-6">
        <AnimatedSection direction="up" className="text-center mb-12">
          <span className="inline-block px-4 py-2 rounded-full bg-primary/10 text-primary text-xs font-medium tracking-wider uppercase mb-4">
            FAQ
          </span>
          <h2 className="font-serif text-3xl md:text-4xl lg:text-5xl text-foreground text-balance">
            Preguntas frecuentes
          </h2>
          <p className="mt-4 text-muted-foreground max-w-2xl mx-auto">
            Resolvemos tus dudas sobre nuestros productos y servicios personalizados.
          </p>
        </AnimatedSection>

        <AnimatedSection direction="up" delay={100} className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`} className="border-border">
                <AccordionTrigger className="text-left font-medium hover:text-primary">{faq.question}</AccordionTrigger>
                <AccordionContent className="text-muted-foreground">{faq.answer}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </AnimatedSection>
      </div>
    </section>
  )
}
