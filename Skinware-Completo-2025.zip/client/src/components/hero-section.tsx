

import { useState, useEffect } from "react"
import { Link } from "wouter"
import { ArrowRightIcon } from "@/components/icons"
import { Button } from "@/components/ui/button"
import { AnimatedSection } from "@/components/animated-section"
import skinwareProductsImg from "@assets/generated_images/skinware_cosmetics_with_black_text_branding.png"

export function HeroSection() {
  const [scrollY, setScrollY] = useState(0)

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY)
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-secondary/30 via-background to-background" style={{ transform: `translateY(${scrollY * 0.5}px)` }} />
      <div className="absolute top-1/4 right-1/4 w-64 h-64 bg-primary/5 rounded-full blur-3xl" style={{ transform: `translateY(${scrollY * 0.3}px)` }} />
      <div className="absolute bottom-1/4 left-1/4 w-96 h-96 bg-secondary/20 rounded-full blur-3xl" style={{ transform: `translateY(${scrollY * 0.2}px)` }} />

      <div className="container mx-auto px-6 relative z-10">
        <AnimatedSection direction="up" className="text-center mb-8">
          <div className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-4 py-2 rounded-full text-sm font-medium animate-pulse shadow-lg">
            <span className="w-2 h-2 rounded-full bg-primary-foreground"></span>
            ⭐ 20% OFF en tu primera compra. Usa: SKINCARE20
          </div>
        </AnimatedSection>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <AnimatedSection direction="up" className="text-center lg:text-left">
            <span className="inline-block px-4 py-2 rounded-full bg-secondary text-secondary-foreground text-xs font-medium tracking-wider uppercase mb-6">
              Clean Beauty & Technology
            </span>

            <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl xl:text-7xl leading-tight text-foreground text-balance">
              Reescribiendo el código de la <span className="text-primary italic">belleza</span>
            </h1>

            <p className="mt-6 text-lg text-muted-foreground max-w-xl mx-auto lg:mx-0 text-pretty">
              Fusionamos la cosmética de lujo con la ciencia de datos para crear productos personalizados que tu piel
              realmente necesita.
            </p>

            <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                className="bg-primary text-primary-foreground hover:bg-primary/90 hover:shadow-lg hover:scale-105 rounded-full px-8 group transition-all duration-300"
                asChild
              >
                <Link href="/diagnostico">
                  Inicia tu diagnóstico
                  <ArrowRightIcon className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                </Link>
              </Button>
              <Button
                size="lg"
                asChild
                className="bg-primary text-primary-foreground hover:bg-primary/90 hover:shadow-lg hover:scale-105 rounded-full px-8 group transition-all duration-300"
              >
                <Link href="/productos">Descubre nuestra tienda</Link>
              </Button>
            </div>

            <div className="mt-4 flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                asChild
                className="bg-primary text-primary-foreground hover:bg-primary/90 hover:shadow-lg hover:scale-105 rounded-full px-8 transition-all duration-300"
              >
                <Link href="/test-piel">Test de Piel Rápido</Link>
              </Button>
              <Button
                size="lg"
                asChild
                className="bg-primary text-primary-foreground hover:bg-primary/90 hover:shadow-lg hover:scale-105 rounded-full px-8 transition-all duration-300"
              >
                <Link href="/comparador">Comparar Productos</Link>
              </Button>
            </div>
          </AnimatedSection>

          <AnimatedSection direction="right" delay={200} className="relative pb-8 lg:pb-0">
            <div className="aspect-[4/5] relative rounded-3xl overflow-hidden shadow-2xl">
              <img
                src={skinwareProductsImg}
                alt="Productos Skinware de cosmética de lujo"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background/20 to-transparent" />
            </div>

            <AnimatedSection
              direction="up"
              delay={500}
              className="absolute bottom-12 left-4 lg:bottom-4 lg:left-4 hidden lg:block"
            >
              <div className="bg-card/95 backdrop-blur-sm p-4 rounded-xl shadow-xl border border-border max-w-[220px]">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                    <span className="text-primary font-serif text-sm">AI</span>
                  </div>
                  <div>
                    <p className="font-medium text-xs text-foreground">Diagnóstico Inteligente</p>
                    <p className="text-[10px] text-muted-foreground">Análisis personalizado</p>
                  </div>
                </div>
                <p className="text-[10px] text-muted-foreground leading-relaxed">
                  Nuestra IA analiza tu piel para recomendarte los productos perfectos.
                </p>
              </div>
            </AnimatedSection>
          </AnimatedSection>
        </div>
      </div>
    </section>
  )
}
