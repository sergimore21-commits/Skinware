

import type React from "react"

import { useState } from "react"
import { StarIcon, ThumbsUpIcon, UserIcon } from "@/components/icons"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { AnimatedSection } from "@/components/animated-section"
import { cn } from "@/lib/utils"

interface Review {
  id: string
  author: string
  rating: number
  date: string
  title: string
  content: string
  helpful: number
  verified: boolean
  skinType?: string
}

interface ProductReviewsProps {
  productId: string
  productName: string
  averageRating: number
  totalReviews: number
}

// Mock reviews data - in production this would come from a database
const reviewsData: Record<string, Review[]> = {
  "1": [
    {
      id: "r1",
      author: "María García",
      rating: 5,
      date: "2024-11-15",
      title: "Mi piel nunca estuvo mejor",
      content:
        "Llevo usando este gel limpiador 3 meses y los resultados son increíbles. Mis poros se ven más pequeños y el exceso de grasa ha disminuido notablemente. La textura es muy agradable y no deja la piel tirante.",
      helpful: 24,
      verified: true,
      skinType: "Grasa",
    },
    {
      id: "r2",
      author: "Carlos Ruiz",
      rating: 4,
      date: "2024-11-10",
      title: "Buen producto, cumple su función",
      content:
        "Me gusta cómo limpia sin resecar. El único pero es que el envase podría ser más grande para el precio. Aun así, repetiré compra.",
      helpful: 12,
      verified: true,
      skinType: "Mixta",
    },
    {
      id: "r3",
      author: "Ana Martínez",
      rating: 5,
      date: "2024-11-05",
      title: "Adiós a los brillos",
      content:
        "Por fin encontré un limpiador que controla mis brillos sin irritarme. Lo uso mañana y noche y mi piel está más equilibrada que nunca.",
      helpful: 18,
      verified: true,
      skinType: "Grasa",
    },
  ],
  "3": [
    {
      id: "r4",
      author: "Laura Sánchez",
      rating: 5,
      date: "2024-11-18",
      title: "Vitamina C que realmente funciona",
      content:
        "He probado muchos sérums de vitamina C y este es el mejor. Se absorbe rápido, no deja residuo pegajoso y mi piel está mucho más luminosa. Las manchas del sol han mejorado visiblemente.",
      helpful: 45,
      verified: true,
      skinType: "Normal",
    },
    {
      id: "r5",
      author: "Pedro López",
      rating: 5,
      date: "2024-11-12",
      title: "Resultados visibles en 2 semanas",
      content:
        "Noté diferencia en mi piel desde la segunda semana. El tono es más uniforme y la textura más suave. Vale cada euro.",
      helpful: 32,
      verified: true,
      skinType: "Mixta",
    },
  ],
}

// Generate default reviews for products without specific reviews
const generateDefaultReviews = (productId: string): Review[] => [
  {
    id: `def1-${productId}`,
    author: "Cliente Verificado",
    rating: 5,
    date: "2024-11-20",
    title: "Excelente producto",
    content:
      "Superó mis expectativas. La calidad es notable y los resultados se ven desde las primeras aplicaciones. Muy recomendable para quien busque productos de calidad.",
    helpful: 15,
    verified: true,
  },
  {
    id: `def2-${productId}`,
    author: "Usuario Skinware",
    rating: 4,
    date: "2024-11-15",
    title: "Muy buena compra",
    content:
      "Producto de alta calidad. Se nota que está formulado con ingredientes premium. Mi piel ha mejorado notablemente.",
    helpful: 8,
    verified: true,
  },
]

function StarRating({
  rating,
  size = "sm",
  interactive = false,
  onRate,
}: {
  rating: number
  size?: "sm" | "md" | "lg"
  interactive?: boolean
  onRate?: (rating: number) => void
}) {
  const [hovered, setHovered] = useState(0)

  const sizeClasses = {
    sm: "w-4 h-4",
    md: "w-5 h-5",
    lg: "w-6 h-6",
  }

  return (
    <div className="flex gap-0.5">
      {[1, 2, 3, 4, 5].map((star) => (
        <button
          key={star}
          type="button"
          disabled={!interactive}
          className={cn("transition-colors", interactive && "cursor-pointer hover:scale-110")}
          onMouseEnter={() => interactive && setHovered(star)}
          onMouseLeave={() => interactive && setHovered(0)}
          onClick={() => interactive && onRate?.(star)}
        >
          <StarIcon
            className={cn(
              sizeClasses[size],
              (interactive ? hovered >= star : rating >= star)
                ? "fill-primary text-primary"
                : rating >= star - 0.5
                  ? "fill-primary/50 text-primary"
                  : "fill-muted text-muted",
            )}
          />
        </button>
      ))}
    </div>
  )
}

function RatingBreakdown({ reviews }: { reviews: Review[] }) {
  const breakdown = [5, 4, 3, 2, 1].map((stars) => ({
    stars,
    count: reviews.filter((r) => r.rating === stars).length,
    percentage: reviews.length > 0 ? (reviews.filter((r) => r.rating === stars).length / reviews.length) * 100 : 0,
  }))

  return (
    <div className="space-y-2">
      {breakdown.map(({ stars, count, percentage }) => (
        <div key={stars} className="flex items-center gap-3">
          <span className="text-sm text-muted-foreground w-12">{stars} est.</span>
          <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
            <div
              className="h-full bg-primary rounded-full transition-all duration-500"
              style={{ width: `${percentage}%` }}
            />
          </div>
          <span className="text-sm text-muted-foreground w-8">{count}</span>
        </div>
      ))}
    </div>
  )
}

export function ProductReviews({ productId, productName, averageRating, totalReviews }: ProductReviewsProps) {
  const [showForm, setShowForm] = useState(false)
  const [newReview, setNewReview] = useState({ name: "", title: "", content: "", rating: 0 })
  const [helpfulClicked, setHelpfulClicked] = useState<Set<string>>(new Set())

  const reviews = reviewsData[productId] || generateDefaultReviews(productId)

  const handleHelpful = (reviewId: string) => {
    setHelpfulClicked((prev) => new Set([...prev, reviewId]))
  }

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault()
    // In production, this would send to an API
    alert("¡Gracias por tu reseña! Será publicada tras ser moderada.")
    setShowForm(false)
    setNewReview({ name: "", title: "", content: "", rating: 0 })
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("es-ES", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  return (
    <section className="mt-16 border-t border-border pt-16">
      <AnimatedSection direction="up">
        <div className="flex flex-col lg:flex-row gap-12">
          {/* Rating Summary */}
          <div className="lg:w-1/3">
            <h2 className="font-serif text-2xl text-foreground mb-6">Opiniones de clientes</h2>

            <div className="bg-muted/50 rounded-2xl p-6">
              <div className="flex items-center gap-4 mb-6">
                <span className="font-serif text-5xl text-foreground">{averageRating.toFixed(1)}</span>
                <div>
                  <StarRating rating={averageRating} size="md" />
                  <p className="text-sm text-muted-foreground mt-1">Basado en {totalReviews} reseñas</p>
                </div>
              </div>

              <RatingBreakdown reviews={reviews} />

              <Button
                onClick={() => setShowForm(!showForm)}
                className="w-full mt-6 rounded-full"
                variant={showForm ? "outline" : "default"}
              >
                {showForm ? "Cancelar" : "Escribir una reseña"}
              </Button>
            </div>
          </div>

          {/* Reviews List */}
          <div className="lg:w-2/3">
            {/* Review Form */}
            {showForm && (
              <AnimatedSection direction="up" className="mb-8">
                <form onSubmit={handleSubmitReview} className="bg-card border border-border rounded-2xl p-6">
                  <h3 className="font-medium text-foreground mb-4">Tu opinión sobre {productName}</h3>

                  <div className="mb-4">
                    <label className="text-sm text-muted-foreground mb-2 block">Tu puntuación</label>
                    <StarRating
                      rating={newReview.rating}
                      size="lg"
                      interactive
                      onRate={(rating) => setNewReview((prev) => ({ ...prev, rating }))}
                    />
                  </div>

                  <div className="grid sm:grid-cols-2 gap-4 mb-4">
                    <div>
                      <label className="text-sm text-muted-foreground mb-2 block">Tu nombre</label>
                      <Input
                        value={newReview.name}
                        onChange={(e) => setNewReview((prev) => ({ ...prev, name: e.target.value }))}
                        placeholder="Nombre"
                        required
                        className="rounded-xl"
                      />
                    </div>
                    <div>
                      <label className="text-sm text-muted-foreground mb-2 block">Título de tu reseña</label>
                      <Input
                        value={newReview.title}
                        onChange={(e) => setNewReview((prev) => ({ ...prev, title: e.target.value }))}
                        placeholder="Resumen de tu experiencia"
                        required
                        className="rounded-xl"
                      />
                    </div>
                  </div>

                  <div className="mb-4">
                    <label className="text-sm text-muted-foreground mb-2 block">Tu experiencia</label>
                    <Textarea
                      value={newReview.content}
                      onChange={(e) => setNewReview((prev) => ({ ...prev, content: e.target.value }))}
                      placeholder="Cuéntanos qué te ha parecido el producto..."
                      required
                      className="rounded-xl min-h-[120px]"
                    />
                  </div>

                  <Button type="submit" className="rounded-full" disabled={newReview.rating === 0}>
                    Enviar reseña
                  </Button>
                </form>
              </AnimatedSection>
            )}

            {/* Reviews */}
            <div className="space-y-6">
              {reviews.map((review, index) => (
                <AnimatedSection key={review.id} direction="up" delay={index * 50}>
                  <article className="bg-card border border-border rounded-2xl p-6 hover:border-primary/30 transition-colors">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                          <UserIcon className="w-5 h-5 text-primary" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-medium text-foreground">{review.author}</span>
                            {review.verified && (
                              <span className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full">
                                Compra verificada
                              </span>
                            )}
                          </div>
                          <div className="flex items-center gap-2 text-xs text-muted-foreground">
                            <span>{formatDate(review.date)}</span>
                            {review.skinType && (
                              <>
                                <span>•</span>
                                <span>Piel {review.skinType}</span>
                              </>
                            )}
                          </div>
                        </div>
                      </div>
                      <StarRating rating={review.rating} />
                    </div>

                    <h4 className="font-medium text-foreground mb-2">{review.title}</h4>
                    <p className="text-muted-foreground text-sm leading-relaxed mb-4">{review.content}</p>

                    <button
                      onClick={() => handleHelpful(review.id)}
                      disabled={helpfulClicked.has(review.id)}
                      className={cn(
                        "flex items-center gap-2 text-sm transition-colors",
                        helpfulClicked.has(review.id) ? "text-primary" : "text-muted-foreground hover:text-foreground",
                      )}
                    >
                      <ThumbsUpIcon className="w-4 h-4" />
                      <span>{helpfulClicked.has(review.id) ? "¡Gracias!" : `Útil (${review.helpful})`}</span>
                    </button>
                  </article>
                </AnimatedSection>
              ))}
            </div>
          </div>
        </div>
      </AnimatedSection>
    </section>
  )
}
