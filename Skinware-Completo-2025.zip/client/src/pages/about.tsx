import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Chatbot } from "@/components/chatbot"
import { AnimatedSection } from "@/components/animated-section"
import { AwardIcon, TargetIcon, LightbulbIcon, LinkedinIcon, TwitterIcon, MailIcon, XIcon } from "@/components/icons"
import { useState } from "react"
import javierImg from "@assets/generated_images/young_javier_merlin_2006_professional_headshot.png"
import lucioImg from "@assets/generated_images/lucio_machado_professional_headshot.png"
import sergiImg from "@assets/generated_images/sergi_moreno_navy_suit_diplomatic_stripe.png"
import alexandraImg from "@assets/generated_images/alexandra_leiva_cmo_headshot.png"
import marcImg from "@assets/generated_images/marc_masip_cfo_headshot.png"

const HeartPulseIcon = ({ className }: { className?: string }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
  >
    <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z" />
    <path d="M3.22 12H9.5l.5-1 2 4.5 2-7 1.5 3.5h5.27" />
  </svg>
)

const CogIcon = ({ className }: { className?: string }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
  >
    <path d="M12 20a8 8 0 1 0 0-16 8 8 0 0 0 0 16Z" />
    <path d="M12 14a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z" />
    <path d="M12 2v2" />
    <path d="M12 22v-2" />
    <path d="m17 20.66-1-1.73" />
    <path d="M11 10.27 7 3.34" />
    <path d="m20.66 17-1.73-1" />
    <path d="m3.34 7 1.73 1" />
    <path d="M14 12h8" />
    <path d="M2 12h2" />
    <path d="m20.66 7-1.73 1" />
    <path d="m3.34 17 1.73-1" />
    <path d="m17 3.34-1 1.73" />
    <path d="m11 13.73-4 6.93" />
  </svg>
)

const RecycleIcon = ({ className }: { className?: string }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
  >
    <path d="M7 19H4.815a1.83 1.83 0 0 1-1.57-.881 1.785 1.785 0 0 1-.004-1.784L7.196 9.5" />
    <path d="M11 19h8.203a1.83 1.83 0 0 0 1.556-.89 1.784 1.784 0 0 0 0-1.775l-1.226-2.12" />
    <path d="m14 16-3 3 3 3" />
    <path d="M8.293 13.596 4.875 7.5l3.5-6.062a1.83 1.83 0 0 1 1.557-.881h2.437" />
    <path d="m9.5 7.5 3-3 3 3" />
    <path d="M14.293 13.596 17.711 7.5l3.5 6.062a1.83 1.83 0 0 1-1.557.881H17.227" />
  </svg>
)

const ODS3Icon = ({ className }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="none" className={className}>
    {/* Corazón con pulso - ODS 3 Salud */}
    <path
      d="M32 56C32 56 8 40 8 24C8 16 14 10 22 10C26.5 10 30.5 12 32 16C33.5 12 37.5 10 42 10C50 10 56 16 56 24C56 40 32 56 32 56Z"
      fill="#4C9F38"
      stroke="#3D8030"
      strokeWidth="2"
    />
    {/* Línea de pulso cardíaco */}
    <path
      d="M12 30H22L26 22L32 38L38 26L42 30H52"
      stroke="white"
      strokeWidth="3"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
)

const ODS9Icon = ({ className }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="none" className={className}>
    {/* Industria e Innovación - Engranajes y edificio */}
    <rect x="8" y="32" width="12" height="24" rx="1" fill="#FD6925" />
    <rect x="24" y="24" width="16" height="32" rx="1" fill="#FD6925" />
    <rect x="44" y="36" width="12" height="20" rx="1" fill="#FD6925" />
    {/* Ventanas */}
    <rect x="11" y="38" width="6" height="6" rx="1" fill="white" />
    <rect x="11" y="48" width="6" height="6" rx="1" fill="white" />
    <rect x="28" y="30" width="4" height="4" rx="0.5" fill="white" />
    <rect x="28" y="38" width="4" height="4" rx="0.5" fill="white" />
    <rect x="28" y="46" width="4" height="4" rx="0.5" fill="white" />
    <rect x="36" y="30" width="4" height="4" rx="0.5" fill="white" />
    <rect x="36" y="38" width="4" height="4" rx="0.5" fill="white" />
    <rect x="36" y="46" width="4" height="4" rx="0.5" fill="white" />
    <rect x="47" y="42" width="6" height="6" rx="1" fill="white" />
    {/* Engranaje de innovación */}
    <circle cx="48" cy="16" r="10" fill="#E55A1B" stroke="#FD6925" strokeWidth="2" />
    <circle cx="48" cy="16" r="4" fill="white" />
    <path
      d="M48 4V8M48 24V28M36 16H40M56 16H60M40.3 8.3L43.1 11.1M52.9 20.9L55.7 23.7M55.7 8.3L52.9 11.1M43.1 20.9L40.3 23.7"
      stroke="#FD6925"
      strokeWidth="3"
      strokeLinecap="round"
    />
  </svg>
)

const ODS12Icon = ({ className }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="none" className={className}>
    {/* Símbolo de infinito/reciclaje - Producción Responsable */}
    <path
      d="M16 32C16 32 16 24 24 24C32 24 32 32 32 32C32 32 32 40 40 40C48 40 48 32 40 32C48 32 48 24 40 24C32 24 32 32 32 32C32 32 32 40 24 40C16 40 16 32 16 32Z"
      stroke="#BF8B2E"
      strokeWidth="6"
      strokeLinecap="round"
      fill="none"
    />
    {/* Flechas de ciclo */}
    <path d="M10 32L16 26L22 32" stroke="#BF8B2E" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
    <path d="M54 32L48 38L42 32" stroke="#BF8B2E" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
    {/* Hojas de sostenibilidad */}
    <path d="M28 12C28 12 32 8 38 10C44 12 44 18 44 18C44 18 40 22 34 20C28 18 28 12 28 12Z" fill="#4C9F38" />
    <path d="M32 14C32 14 38 18 36 22" stroke="white" strokeWidth="1.5" strokeLinecap="round" />
    <path d="M20 48C20 48 24 44 30 46C36 48 36 54 36 54C36 54 32 58 26 56C20 54 20 48 20 48Z" fill="#4C9F38" />
    <path d="M24 50C24 50 30 54 28 58" stroke="white" strokeWidth="1.5" strokeLinecap="round" />
  </svg>
)

const coFounders = [
  {
    name: "Lucio Machado",
    role: "Co-Fundador & Director General",
    image: lucioImg,
    description: "Visionario en la fusión de tecnología y cosmética.",
    education: ["Licenciatura en Ingeniería Química - Universitat Rovira i Virgili", "MBA - ESADE Business School"],
    hobbies: ["Senderismo", "Lectura de libros de ciencia", "Fotografía científica"],
    workExperience: "Apasionado por revolucionar la industria cosmética mediante datos e inteligencia artificial. Cree que la belleza debe ser personalizada y basada en ciencia.",
    socials: {
      linkedin: "#",
      twitter: "#",
      email: "lucio@skinware.com",
    },
  },
  {
    name: "Sergi Moreno",
    role: "Co-Fundador & Director General",
    age: 33,
    image: sergiImg,
    description: "Experto en operaciones y estrategia empresarial. Estilo sofisticado y visión disruptiva.",
    education: ["Grado en Administración de Empresas - Universidad de Barcelona", "Especialización en Startups - Y Combinator"],
    hobbies: ["Viajes de negocios internacionales", "Pádel", "Vinos premium"],
    workExperience: "Lidera la estrategia comercial y expansión global de Skinware. Experto en escalabilidad empresarial y creación de ecosistemas de innovación.",
    socials: {
      linkedin: "#",
      twitter: "#",
      email: "sergi@skinware.com",
    },
  },
]

const executives = [
  {
    name: "Alexandra Leiva",
    role: "Directora de Marca y Experiencia",
    title: "CMO",
    image: alexandraImg,
    description: "El alma creativa detrás de la imagen de Skinware.",
    education: ["Grado en Comunicación Audiovisual - Universitat Autònoma de Barcelona", "Máster en Dirección de Marketing - IESE"],
    hobbies: ["Arte contemporáneo", "Diseño gráfico", "Viajes culturales"],
    workExperience: "Dirige la estrategia de marca y la experiencia del cliente. Experta en crear conexiones emocionales entre marcas y consumidores. En Skinware, hace que la belleza personalizada sea inspiradora.",
    socials: {
      linkedin: "#",
      twitter: "#",
      email: "alexandra@skinware.com",
    },
  },
  {
    name: "Marc Masip",
    role: "Director de Negocio y Finanzas",
    title: "CFO",
    image: marcImg,
    description: "Estrategia de crecimiento y expansión global.",
    education: ["Licenciatura en Contabilidad y Finanzas - Universitat de Girona", "Máster en Finanzas Corporativas - IE University"],
    hobbies: ["Golf", "Análisis de datos deportivos", "Cocina"],
    workExperience: "Gestiona las finanzas y estrategia de crecimiento de Skinware. Apasionado por encontrar oportunidades de expansion en mercados emergentes. Cree que los datos bien manejados son el corazón de cualquier empresa.",
    socials: {
      linkedin: "#",
      twitter: "#",
      email: "marc@skinware.com",
    },
  },
  {
    name: "Javier Merlin",
    role: "Director de Innovación Tecnológica",
    title: "CTO",
    image: javierImg,
    description: "Responsable de la integración de datos e I+D.",
    education: ["Ingeniero Superior en Informática - Universitat Politècnica de Catalunya", "Máster en Ciencia de Datos - Universitat de Barcelona"],
    hobbies: ["Machine Learning", "Hackathons", "Gaming competitivo"],
    workExperience: "Lidera la innovación tecnológica de Skinware. Especialista en IA y machine learning. En Skinware, crea los algoritmos que hacen posible la personalización de cosmética basada en datos reales.",
    socials: {
      linkedin: "#",
      twitter: "#",
      email: "javier@skinware.com",
    },
  },
]

const values = [
  {
    icon: TargetIcon,
    title: "Misión",
    description:
      "Revolucionar la industria cosmética a través de la personalización impulsada por datos, ofreciendo productos que se adaptan perfectamente a las necesidades individuales de cada piel.",
  },
  {
    icon: LightbulbIcon,
    title: "Visión",
    description:
      "Ser la marca líder mundial en cosmética personalizada, donde cada producto es tan único como la persona que lo usa.",
  },
  {
    icon: AwardIcon,
    title: "Valores",
    description:
      "Innovación constante, sostenibilidad, transparencia en nuestros ingredientes y un compromiso inquebrantable con la excelencia científica.",
  },
]

const odsItems = [
  {
    number: "3",
    icon: ODS3Icon,
    title: "Salud y Bienestar",
    color: "bg-[#4C9F38]",
    description:
      "Garantizamos productos libres de disruptores endocrinos y tóxicos. Nuestra prioridad es la salud dermatológica a largo plazo, no solo la estética inmediata.",
  },
  {
    number: "9",
    icon: ODS9Icon,
    title: "Industria e Innovación",
    color: "bg-[#FD6925]",
    description:
      "Transformamos la industria química tradicional de Tarragona mediante la digitalización de procesos, reduciendo errores y optimizando recursos con IA.",
  },
  {
    number: "12",
    icon: ODS12Icon,
    title: "Producción Responsable",
    color: "bg-[#BF8B2E]",
    description:
      'Nuestra fabricación "On-Demand" elimina el stock sobrante. Solo producimos lo que tu piel necesita, reduciendo el desperdicio químico en un 40%.',
  },
]

export default function NosotrosPage() {
  const [selectedPerson, setSelectedPerson] = useState<any>(null)

  return (
    <>
      <Navbar />
      {selectedPerson && (
        <div className="fixed inset-0 bg-foreground/40 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={() => setSelectedPerson(null)}>
          <div className="bg-background rounded-2xl border border-border max-w-2xl w-full max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between p-6 border-b border-border sticky top-0 bg-background">
              <h2 className="font-serif text-2xl text-foreground">{selectedPerson.name}</h2>
              <button onClick={() => setSelectedPerson(null)} className="p-2 hover:bg-muted rounded-full transition-colors">
                <XIcon className="w-5 h-5" />
              </button>
            </div>
            <div className="p-6 space-y-6">
              <div>
                <p className="text-sm font-medium text-primary mb-1">{selectedPerson.role}</p>
                <p className="text-muted-foreground">{selectedPerson.description}</p>
              </div>
              <div>
                <h3 className="font-serif text-lg text-foreground mb-3">📚 Estudios</h3>
                <ul className="space-y-2">
                  {selectedPerson.education?.map((edu: string, i: number) => (
                    <li key={i} className="text-sm text-muted-foreground flex gap-2">
                      <span className="text-primary">✓</span> {edu}
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <h3 className="font-serif text-lg text-foreground mb-3">🎯 Aficiones</h3>
                <div className="flex flex-wrap gap-2">
                  {selectedPerson.hobbies?.map((hobby: string, i: number) => (
                    <span key={i} className="px-3 py-1.5 bg-secondary text-secondary-foreground rounded-full text-sm">
                      {hobby}
                    </span>
                  ))}
                </div>
              </div>
              <div>
                <h3 className="font-serif text-lg text-foreground mb-3">💼 En Skinware</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{selectedPerson.workExperience}</p>
              </div>
            </div>
          </div>
        </div>
      )}
      <main className="pt-20">
        {/* Hero Section - Animated */}
        <section className="py-24 bg-gradient-to-b from-secondary/20 to-background">
          <div className="container mx-auto px-6">
            <AnimatedSection className="max-w-3xl mx-auto text-center">
              <span className="inline-block px-4 py-2 rounded-full bg-secondary text-secondary-foreground text-xs font-medium tracking-wider uppercase mb-6">
                Quiénes Somos
              </span>
              <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-foreground mb-6 text-balance">
                Unidos por una visión común
              </h1>
              <p className="text-lg text-muted-foreground text-pretty">
                Desde Tarragona, transformamos digitalmente la excelencia química para ofrecerte productos cosméticos
                personalizados que tu piel realmente necesita.
              </p>
            </AnimatedSection>
          </div>
        </section>

        {/* Mission, Vision, Values - Staggered animations */}
        <section className="py-20">
          <div className="container mx-auto px-6">
            <div className="grid md:grid-cols-3 gap-8">
              {values.map((value, index) => (
                <AnimatedSection key={index} delay={index * 150}>
                  <div className="bg-card p-8 rounded-2xl border border-border hover:shadow-lg transition-shadow h-full flex flex-col items-center text-center">
                    <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mb-6">
                      <value.icon className="h-7 w-7 text-primary" />
                    </div>
                    <h3 className="font-serif text-2xl mb-4 text-foreground">{value.title}</h3>
                    <p className="text-muted-foreground leading-relaxed">{value.description}</p>
                  </div>
                </AnimatedSection>
              ))}
            </div>
          </div>
        </section>

        {/* Our Story - Animated with direction */}
        <section className="py-20 bg-muted">
          <div className="container mx-auto px-6">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <AnimatedSection direction="left" className="relative">
                <div className="aspect-[4/3] rounded-3xl overflow-hidden shadow-xl">
                  <img
                    src="/modern-cosmetics-laboratory-with-high-tech-equipme.jpg"
                    alt="Laboratorio Skinware en Tarragona"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="absolute -bottom-6 -right-6 bg-primary text-primary-foreground p-6 rounded-2xl">
                  <p className="font-serif text-3xl">2023</p>
                  <p className="text-sm opacity-80">Fundación</p>
                </div>
              </AnimatedSection>
              <AnimatedSection direction="right" delay={200}>
                <span className="inline-block px-4 py-2 rounded-full bg-secondary text-secondary-foreground text-xs font-medium tracking-wider uppercase mb-6">
                  Nuestra Historia
                </span>
                <h2 className="font-serif text-3xl md:text-4xl text-foreground mb-6 text-balance">
                  De la Química Industrial a la Revolución Digital
                </h2>
                <div className="space-y-4 text-muted-foreground">
                  <p>
                    La historia de Skinware comienza en 2023, en los laboratorios del{" "}
                    <strong className="text-foreground">Institut Comte de Rius en Tarragona</strong>. Lo que empezó como
                    un proyecto académico de cinco estudiantes de química industrial, pronto reveló una verdad incómoda:
                    la industria cosmética estaba estancada en fórmulas de los años 90.
                  </p>
                  <p>
                    Observamos que, mientras la tecnología avanzaba exponencialmente, el cuidado de la piel seguía
                    basándose en el "ensayo y error". Frustrados por la falta de precisión, decidimos unir dos mundos
                    aparentemente opuestos:{" "}
                    <strong className="text-foreground">
                      la química analítica rigurosa y la inteligencia artificial
                    </strong>
                    .
                  </p>
                  <p>
                    Tras meses de investigación y prototipado, logramos desarrollar nuestro primer algoritmo capaz de
                    traducir datos dermatológicos en fórmulas químicas estables. Así nació Skinware: no como una marca
                    de belleza más, sino como{" "}
                    <strong className="text-foreground">
                      una empresa tecnológica dedicada a reescribir el código de la salud dérmica
                    </strong>
                    .
                  </p>
                </div>
              </AnimatedSection>
            </div>
          </div>
        </section>

        <section className="py-20">
          <div className="container mx-auto px-6">
            <AnimatedSection className="text-center mb-16">
              <span className="inline-block px-4 py-2 rounded-full bg-green-100 text-green-700 text-xs font-medium tracking-wider uppercase mb-4">
                Compromiso Sostenible
              </span>
              <h2 className="font-serif text-3xl md:text-4xl text-foreground mb-4 text-balance">
                Objetivos de Desarrollo Sostenible
              </h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                En Skinware, la tecnología no solo sirve a la belleza, sino al planeta. Alineamos nuestra producción con
                la Agenda 2030.
              </p>
            </AnimatedSection>

            <div className="grid md:grid-cols-3 gap-8">
              {odsItems.map((ods, index) => (
                <AnimatedSection key={index} delay={index * 150}>
                  <div className="bg-card p-8 rounded-2xl border border-border hover:shadow-xl transition-all duration-300 h-full group hover:-translate-y-1">
                    <div className="flex flex-col items-center text-center mb-6">
                      <div className="w-24 h-24 mb-4 group-hover:scale-110 transition-transform duration-300">
                        <ods.icon className="w-full h-full" />
                      </div>
                      <div className={`px-4 py-2 rounded-full ${ods.color} text-white font-bold text-sm shadow-lg`}>
                        ODS {ods.number}
                      </div>
                    </div>
                    <h3 className="font-serif text-xl mb-3 text-foreground text-center">{ods.title}</h3>
                    <p className="text-muted-foreground leading-relaxed text-center">{ods.description}</p>
                  </div>
                </AnimatedSection>
              ))}
            </div>
          </div>
        </section>

        {/* Leadership - Co-Founders - Animated sections */}
        <section className="py-20 bg-muted">
          <div className="container mx-auto px-6">
            <AnimatedSection className="text-center mb-16">
              <span className="inline-block px-4 py-2 rounded-full bg-secondary text-secondary-foreground text-xs font-medium tracking-wider uppercase mb-4">
                Liderazgo
              </span>
              <h2 className="font-serif text-3xl md:text-4xl text-foreground text-balance">Dirección Ejecutiva</h2>
              <p className="mt-4 text-muted-foreground max-w-2xl mx-auto">
                Liderazgo compartido de la visión y las operaciones de Skinware.
              </p>
            </AnimatedSection>

            {/* Co-Founders - Same Level */}
            <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto mb-16">
              {coFounders.map((founder, index) => (
                <AnimatedSection key={index} delay={index * 150} className="h-full">
                  <div className="group bg-card rounded-2xl overflow-hidden border border-border hover:shadow-xl transition-all duration-300 cursor-pointer h-full flex flex-col" onClick={() => setSelectedPerson(founder)}>
                    <div className="aspect-[3/4] overflow-hidden relative">
                      <img
                        src={founder.image || "/placeholder.svg"}
                        alt={founder.name}
                        className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-500"
                      />
                    </div>
                    <div className="p-6 text-center flex flex-col items-center">
                      <span className="inline-block px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-medium mb-3">
                        Co-CEO
                      </span>
                      <h3 className="font-serif text-2xl text-foreground mb-1">{founder.name}</h3>
                      <p className="text-sm text-primary mb-3">{founder.role}</p>
                      <p className="text-sm text-muted-foreground line-clamp-3">{founder.description}</p>
                    </div>
                  </div>
                </AnimatedSection>
              ))}
            </div>

            {/* Executive Team */}
            <AnimatedSection className="text-center mb-12">
              <h3 className="font-serif text-2xl text-foreground">Equipo Directivo Especializado</h3>
            </AnimatedSection>
            <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
              {executives.map((exec, index) => (
                <AnimatedSection key={index} delay={index * 100}>
                  <div className="group bg-card rounded-2xl overflow-hidden border border-border hover:shadow-lg transition-all duration-300 cursor-pointer" onClick={() => setSelectedPerson(exec)}>
                    <div className="aspect-[3/4] overflow-hidden bg-muted relative">
                      <img
                        src={exec.image || "/placeholder.svg"}
                        alt={exec.name}
                        className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-500"
                      />
                    </div>
                    <div className="p-6 text-center flex flex-col items-center">
                      <span className="inline-block px-3 py-1 rounded-full bg-secondary text-secondary-foreground text-xs font-medium mb-3">
                        {exec.title}
                      </span>
                      <h4 className="font-serif text-xl text-foreground mb-1">{exec.name}</h4>
                      <p className="text-sm text-primary mb-2">{exec.role}</p>
                      <p className="text-sm text-muted-foreground">{exec.description}</p>
                    </div>
                  </div>
                </AnimatedSection>
              ))}
            </div>
          </div>
        </section>
      </main>
      <Footer />
      <Chatbot />
    </>
  )
}
