import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Chatbot } from "@/components/chatbot"
import { AnimatedSection } from "@/components/animated-section"
import { useState } from "react"

const faqData = {
  serums: [
    { q: "¿Con qué frecuencia debo usar sérums?", a: "Normalmente 1-2 veces al día, mañana y/o noche según tu tipo de piel." },
    { q: "¿Puedo combinar varios sérums?", a: "Sí, pero espera 1-2 minutos entre cada aplicación." },
  ],
  limpiadores: [
    { q: "¿Es necesario limpiar 2 veces?", a: "Para piel grasa sí. Elimina maquillaje y impurezas completamente." },
    { q: "¿Puedo usar limpiador en seco?", a: "Sí, muchos son diseñados para piel deshidratada." },
  ],
  hidratantes: [
    { q: "¿Qué hidratante para piel grasa?", a: "Busca texturas ligeras, tipo gel o fluidos absorbentes." },
    { q: "¿Hidratante + sérum?", a: "Sí, el sérum primero (cuando está húmeda la piel), luego crema." },
  ],
}

export default function FAQCategoriesPage() {
  const [openCategory, setOpenCategory] = useState<string | null>("serums")
  const [openFaq, setOpenFaq] = useState<number | null>(null)

  return (
    <>
      <Navbar />
      <main className="pt-20">
        <section className="py-24 bg-gradient-to-b from-primary/10 to-background">
          <div className="container mx-auto px-6">
            <AnimatedSection className="text-center max-w-3xl mx-auto">
              <h1 className="font-serif text-5xl text-foreground mb-4">Preguntas Frecuentes</h1>
              <p className="text-lg text-muted-foreground">Soluciona tus dudas por categoría</p>
            </AnimatedSection>
          </div>
        </section>

        <section className="py-20">
          <div className="container mx-auto px-6 max-w-2xl">
            <div className="space-y-4 mb-8">
              {Object.keys(faqData).map((cat) => (
                <button
                  key={cat}
                  onClick={() => { setOpenCategory(openCategory === cat ? null : cat); setOpenFaq(null) }}
                  className={`w-full p-4 text-left font-medium rounded-lg border transition-all ${openCategory === cat ? 'border-primary bg-primary/5' : 'border-border'}`}
                >
                  {cat.charAt(0).toUpperCase() + cat.slice(1)}
                </button>
              ))}
            </div>

            {openCategory && (
              <AnimatedSection direction="up" className="space-y-3">
                {faqData[openCategory as keyof typeof faqData].map((faq, i) => (
                  <div key={i} className="bg-card border border-border rounded-lg overflow-hidden">
                    <button
                      onClick={() => setOpenFaq(openFaq === i ? null : i)}
                      className="w-full p-4 text-left font-medium hover:bg-muted/50 transition-colors"
                    >
                      <div className="flex justify-between items-center">
                        <span className="text-foreground">{faq.q}</span>
                        <span className="text-primary">{openFaq === i ? '−' : '+'}</span>
                      </div>
                    </button>
                    {openFaq === i && (
                      <div className="p-4 bg-muted/30 border-t border-border">
                        <p className="text-muted-foreground">{faq.a}</p>
                      </div>
                    )}
                  </div>
                ))}
              </AnimatedSection>
            )}
          </div>
        </section>
      </main>
      <Footer />
      <Chatbot />
    </>
  )
}
