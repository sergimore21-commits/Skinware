import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Chatbot } from "@/components/chatbot"
import { AnimatedSection } from "@/components/animated-section"

const tiers = [
  { name: "Bronze", points: "0-999", perks: ["5% descuento", "Envío gratis", "Acceso a blog exclusivo"] },
  { name: "Silver", points: "1000-4999", perks: ["10% descuento", "Envío prioritario", "Asesoramiento gratis", "Productos muestrarios"] },
  { name: "Gold", points: "5000+", perks: ["15% descuento", "Envío express", "VIP support", "Acceso a lanzamientos", "Descuentos especiales"] },
]

export default function LoyaltyPage() {
  return (
    <>
      <Navbar />
      <main className="pt-20">
        <section className="py-24 bg-gradient-to-b from-primary/10 to-background">
          <div className="container mx-auto px-6">
            <AnimatedSection className="text-center max-w-3xl mx-auto">
              <h1 className="font-serif text-5xl text-foreground mb-4">Programa de Fidelización</h1>
              <p className="text-lg text-muted-foreground">Gana puntos en cada compra y disfruta de beneficios exclusivos</p>
            </AnimatedSection>
          </div>
        </section>

        <section className="py-20">
          <div className="container mx-auto px-6">
            <div className="grid md:grid-cols-3 gap-8 mb-16">
              {tiers.map((tier, i) => (
                <AnimatedSection key={i} delay={i * 100}>
                  <div className={`rounded-2xl border p-8 h-full ${i === 2 ? 'bg-primary/5 border-primary' : 'bg-card border-border'}`}>
                    <h3 className={`font-serif text-2xl mb-2 ${i === 2 ? 'text-primary' : 'text-foreground'}`}>{tier.name}</h3>
                    <p className="text-sm text-muted-foreground mb-6">{tier.points} puntos</p>
                    <ul className="space-y-3">
                      {tier.perks.map((perk, j) => (
                        <li key={j} className="text-sm text-foreground flex gap-2">
                          <span className="text-primary">✓</span> {perk}
                        </li>
                      ))}
                    </ul>
                  </div>
                </AnimatedSection>
              ))}
            </div>

            <AnimatedSection direction="up" className="bg-card border border-border rounded-2xl p-8 text-center">
              <h2 className="font-serif text-2xl text-foreground mb-4">¿Cómo funciona?</h2>
              <div className="grid md:grid-cols-4 gap-4 text-sm">
                <div><p className="text-primary font-bold">1 punto</p><p className="text-muted-foreground">por cada 1€</p></div>
                <div><p className="text-primary font-bold">Acumula</p><p className="text-muted-foreground">sin límite de tiempo</p></div>
                <div><p className="text-primary font-bold">Canjea</p><p className="text-muted-foreground">por descuentos</p></div>
                <div><p className="text-primary font-bold">Sube niveles</p><p className="text-muted-foreground">con cada compra</p></div>
              </div>
            </AnimatedSection>
          </div>
        </section>
      </main>
      <Footer />
      <Chatbot />
    </>
  )
}
